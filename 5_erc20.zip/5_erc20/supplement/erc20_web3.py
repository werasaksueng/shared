## Using web3.py to work with Erc20.

## Start Ganache.
from web3.auto import w3
# print(w3.is_connected())

## Account Setting:
me = w3.eth.accounts[0]
john = w3.eth.accounts[1]
jack = w3.eth.accounts[2]

def eth_balances():
    print('me:', w3.eth.get_balance(me))
    print('john:', w3.eth.get_balance(john))
    print('jack:', w3.eth.get_balance(jack))
# eth_balances()
#------------------------------------------------


def read_file(fname):
    fname = 'contracts/' + fname
    with open(fname, 'r') as f:
        return f.read()

abi = read_file('Erc20_Z.abi')
bin = read_file('Erc20_Z.bin')
# print(abi); print(bin)

def test_abi_bin(abi, bin):
    cobj = w3.eth.contract(abi=abi, bytecode=bin)
    [ print(f.fn_name) for f in cobj.all_functions()]
# test_abi_bin(abi, bin)

#---------------------------------------

## Deploy the erc20 from 'me':
def deploy(sender_addr, abi, bin):
    cobj = w3.eth.contract(abi=abi, bytecode=bin)
    tx_hash = cobj.constructor(sender_addr).transact({
         'from': sender_addr, 'gas': 2000000, })
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_receipt['contractAddress']
caddr = deploy(me, abi, bin)
print(caddr)
# ct_addr = '0x027e3e0Cd0ab688CB8081821A138FcD8fD1e7418'

## Check the contract address has bytecode (if it is deployed correctly).
# print(w3.eth.get_code(ct_addr))

## Check 'me' had paid gas for deploying the contract.
# eth_balances()

## To work with a deployed contract we need the contract reference.
## Getting the contract reference using the contract address and abi.
def get_ct(caddr, abi):
    return w3.eth.contract(address=caddr, abi=abi)
# ct = get_ct(ct_addr, abi)

## Call read only functions:
# print(ct.functions.name().call())
# print(ct.functions.symbol().call())
# print(ct.functions.totalSupply().call())

## Check MTK balances:  Initially no MTK yet.
def mtk_balances():
    print('MTK')
    print('me: ', ct.functions.balanceOf(me).call())
    print('john: ', ct.functions.balanceOf(john).call())
    print('jack: ', ct.functions.balanceOf(jack).call())
# mtk_balances()

''' Deploying a token does not create any tokens yet.
'Mint' is the process of creating tokens.
Only the contract owner can mint tokens.
This Erc20 was written so that the tokens can be minited as needed.

'me' mints 1_000_000 MTK and send to its address. '''
# print(ct.functions.mint(me, 1_000_000).transact({'from': me}).hex())
# mtk_balances()

## The contract address does own any tokens.
# print(ct.functions.balanceOf(ct_addr).call())

## 'me' transfers 100 MTK to 'john'.
# print(ct.functions.transfer(john, 100).transact({'from': me}).hex())
# mtk_balances()

## 'john' transfers 10 MTK to 'jack'.
# print(ct.functions.transfer(jack, 10).transact({'from': john}).hex())
# mtk_balances()

##################################################################

''' Supppse 'me' is the MTK token owner.
        'john' is a distributor of MTK.
        'jack' is a customer.
transferForm(owner, receiver. mtk) is used in Token Distributor environment. 
Suppose 'john' transfers me's tokens to 'jack'.  '''
# print(ct.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
	## Error: Without allowance john cannot transfer any MTK to anyone.

## me must approve john to transfer some amount of tokens.
# print(ct.functions.approve(john, 50).transact({'from': me}).hex())

## Check the amount that me allows john to transfer.
# print(ct.functions.allowance(me, john).call())

''' Now john can transfer me's tokens to jack.
John must own enough tokens and gas(for sending tx).
The transferred tokens must not excess the allowance. '''
# print(ct.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
# eth_balances()
# mtk_balances()
