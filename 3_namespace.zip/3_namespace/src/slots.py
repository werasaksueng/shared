class Student:
    __slots__ = ('name', 'age')

s = Student()
s.name = "John"
s.age = 20
print(s.name, s.age)
print(s.id)
