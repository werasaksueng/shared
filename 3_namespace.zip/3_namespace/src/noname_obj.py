def f(self):
    print("Hello")
from types import SimpleNamespace, MethodType
o = SimpleNamespace()	## Create an object.
o.f = MethodType(f, o)	## Attach f() to the object.
o.x = 1			## add x to the object.

o.f()			## Hello
print(o.x)		## 1
