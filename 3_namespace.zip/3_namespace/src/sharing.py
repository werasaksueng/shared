## sharing.py
class A:
    def f(self):
        return 'A.f'
class B:
    def g(self):
        return 'B.g'
class C:
    f = A.f
    g = B.g
c = C()
print(c.f(), c.g())	## A.f  B.g 

