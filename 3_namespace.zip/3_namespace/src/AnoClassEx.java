// AnoClass.java	Anonymous Class
class A {
	int x = 0;
	A(int x) { this.x = x; }
	void f() { System.out.println(x); }
}
class AnoClass {
	static void test(A a) { a.f(); }
	public static void main(String args[]) {
		test(new A(1) { });
	}
}
