def greet():
    _hello()
def _hello():
    print('Hello')

