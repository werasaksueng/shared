// Using A.java
class DefCons {
    public static void main(String args[]) {
	A a = new A();
    }
}
