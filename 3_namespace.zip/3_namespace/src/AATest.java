class AATest {
    public static void main(String args[]) {
	System.out.println(new mypack.A().f());
	System.out.println(new yourpack.A().f());
    }
}