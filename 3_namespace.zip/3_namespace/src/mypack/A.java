package mypack;
public class A {
    public String f() {return "mypack.A"; }
}
