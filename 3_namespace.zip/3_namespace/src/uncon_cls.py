## uncon_cls.py
def f():
    return 'Hello'
class A: pass
A.x = 1
A.f = f
print(A.x, A.f())  ## 1 Hello

a = A()
a.y = 2
print(a.x, a.y)