// StaticEx.java
class Point {
	// .... skip detail
	static class Int extends Point{
		private int x, y;
		Int(int x, int y) { }
		// ....
	}

	static class Double extends Point {
		private double x, y;
		Double(double x, double y) { }
		// ....
	}
}
class StaticEx {
	public static void main(String args[]) {
		Point p1 = new Point.Int(1,2);
		Point p2 = new Point.Double(1.0,2.0);
	}
}
	