class A:
    def f(self):
        print('Hello')
    def g(self):
        print('Hi')
a = A()
a.f = a.g
a.f() 			## Hi
A().f() 		## Hello

