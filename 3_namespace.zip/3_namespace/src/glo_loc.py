x = 1
def f():
    y = 2
    print(globals())	## ['x', .....]
    print(locals())	## ['y']
f()
