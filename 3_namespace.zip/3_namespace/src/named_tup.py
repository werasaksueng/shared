from typing import NamedTuple
class Point(NamedTuple): ## NamedTuple is parent class.
    x: float             ## Type annotation
    y: float
p = Point(1, 2)
print(p.x, p.y)   ## 1 2
print(p.z)
