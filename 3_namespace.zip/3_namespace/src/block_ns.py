def f():
    x = 1
    if x == 1:
        y = 1
        print(dir())  ## ['x', 'y']
    print(dir())      ## ['x', 'y']
f()