// MathTest.java
import java.math.BigInteger;
class MathSq {
    public static void main(String args[]) {
	// The class java.lang.Math contains sqrt().
	System.out.println(Math.sqrt(2));
	BigInteger x = new BigInteger("1234567890");
	System.out.println(x);
    }
}