// MemberVis.java
class A {
	private int x = 1;
	A.B b = new A.B();
	void print() { System.out.println(b.y); }
	// the outer class can access private members
	// of the member class

	class B {
		private int y = 2;
		void print() { System.out.println(x); }
		// the member class can access private members
		// of the outter class
	}
	class C {
		A.B b = new A.B();
		void print () { System.out.println(b.y); }
		// a member class can access private members
		// of another member class
	}
}
