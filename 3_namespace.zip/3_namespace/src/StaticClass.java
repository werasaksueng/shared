// StaticClass.java
class A {
	static int x = 1;
	static class B {
		void print() { 
			System.out.println(x);
		}
	}
}
class StaticClass {
	public static void main(String args[]) {
		A.B b = new A.B();
		b.print();

		// new A$B();
	}
}
