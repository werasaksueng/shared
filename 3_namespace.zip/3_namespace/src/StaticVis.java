// StaticVis.java
class A {
	int x = 1;
	static private int y = 2;
	static class B {
		void print() {
			System.out.println(x);
			System.out.println(y + C.z);
		}
	}
	static class C {
		static private int z = 3;
	}
}
