import hide
hide.greet()	  ## Hello
# hide._hello()	  ## Error

