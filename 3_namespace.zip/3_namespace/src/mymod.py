x = 1
def f():
    print('Hello')
class A:
    pass