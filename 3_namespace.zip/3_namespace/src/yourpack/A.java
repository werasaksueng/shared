package yourpack;
public class A {
    public String f() {return "yourpack.A"; }
}
