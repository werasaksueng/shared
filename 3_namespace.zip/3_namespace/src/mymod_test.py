import mymod
print(mymod.x)	     ## 1 ['John', 'Jack', 'Joe']
mymod.f() 			## Hello
mymod.A()
print(dir(mymod))