// AnoClass.java
class A { void f() { System.out.print("Hello"); } }
class AnoClass {
	public static void main(String args[]) {
		A a = new A() {
			void f() { System.out.print("Hi");}
		};
		a.f();
	}
}
