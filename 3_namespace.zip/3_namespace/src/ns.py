## ns.py
x = 1
def f():
    y = 1;
    def g():
        z = 1
        print(dir())  ## ['z']
    g()
    print(dir())      ## ['g', 'y']
f()
print(dir())    ## ['f', 'x', ....]