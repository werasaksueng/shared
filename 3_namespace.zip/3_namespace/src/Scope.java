class A {
    int x = 1;
    void f() {
	++x;
        System.out.print(x);
    }
}
class Scope {
    public static void main(String args[]) {
	A a = new A();
	a.f();
   }
}