## share_mem.py
class A:
    x = 1  
class B:
    x = A.x
print(A.x, B.x)		  ## (1, 1)
print(A.x is B.x) ## True
A.x = 2
print(A.x is B.x) 
