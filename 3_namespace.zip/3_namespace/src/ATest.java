class ATest {
    public static void main(String args[]) {
	new mypack.A();
    }
}