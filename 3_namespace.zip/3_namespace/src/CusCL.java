import java.net.URL;
import java.net.URLClassLoader;
class CusCL {
    public static void main(String[] args) throws Exception {
        URL location = new java.io.File(".").toURI().toURL();

        // Two independent class loaders
        try (URLClassLoader loaderA =
                 new URLClassLoader(new URL[]{location}, null);
             URLClassLoader loaderB =
                 new URLClassLoader(new URL[]{location}, null)) {

            Class<?> c1 = loaderA.loadClass("A");
            Class<?> c2 = loaderB.loadClass("A");

            System.out.println(c1.getName() + "," +c2.getName());

            System.out.println(c1 == c2);
            System.out.println(c1.getClassLoader());
            System.out.println(c2.getClassLoader());
        }
    }
}
