// Import.java
import mypack.A;
class Import {
	public static void main(String args[]) {
		new A();
	}
}
