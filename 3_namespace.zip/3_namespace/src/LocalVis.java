// LocalVis.java
class A {
	private int a = 0;
	void f(final int w, int x) {
		int y = 3;
		final int z = 4;
		class B {
			void f() { System.out.println(a+","+w+","+z); }
		}
		new B();
	}
}
