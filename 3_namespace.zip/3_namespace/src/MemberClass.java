// MemberClass.java
class A {
	private int x;
	A(int x) { this.x = x; }
	class B {
		void print() { 
			System.out.println(x);
		}
	}
}
class MemberClass {
	public static void main(String args[]) {
		A a = new A(1);
		A.B b = a.new B();
		b.print();
	}
}
