// LocalClass.java
class LocalClass {
	public static void main(String args[]) {
		// A is not visible here.
		class A { } // no duplicate name in the same scope.
		new A();
		for(int i = 0; i < 10; i++) {
			class B { }  // cannot shadow A.
			new B();
		}
	}
        void f() {
		class A { }
	}
}
