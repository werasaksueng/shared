x = 1
def f():
    x = 2
    print(x, dir())   ## 2 ['x']
f()
print(x, dir())  ## 1 ['x', 'f', ....]