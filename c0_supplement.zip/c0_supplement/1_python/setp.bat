set PATH=%C:\python311;C:\python311\Scripts

