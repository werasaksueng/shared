''' Json(JavaScript Object Notation) is a representation
  for a hierarchical tree of items in the form of <key>:<value>.
It is equally expressive as XML, but using less characters.
It is suitable for structured data such records (of tables). 
  Ex.    { "id": 1, "name": "john", "gpa": 4.0 }

The Python 'dict' syntax is almost the same as Json. 
A 'dict' literal is an object of type 'dict'.
type(<obj>) returns the type of <obj>.
'''
d = { "id": 1, "name": "john", "gpa": 4.0 }
# print(type(d))			## <class 'dict'>

## 'dict' items can be accessed using [<key>].
# print(d["id"], d["name"], d["gpa"])	## 1 john 4.0

## Accessing non-exist key would cause KeyError.
# print(d["dept"])		## KeyError

## Using get() for non-exist key results None.
# print(d.get("dept"))		## None

''' There is no 'json' type in Python, a json is represented 
 as a str (string).
A Python dict can be converted to a string.
str(<obj>) returns the string representation of <obj>. '''
s = str(d)
# print(type(s))   ## <class 'str'>
# print(s)         ## {'id': 1, 'name': 'john', 'gpa': 4.0}

## 'json' lib allows conversion between string and dict.
import json
s = '{ "id": 1, "name": "john", "gpa": 4.0 }'

## str -> dict:  json.loads(<str>)
d = json.loads(s)
# print(type(d))			## <class 'dict'>
# print(d["id"], d["name"], d["gpa"])	## 1 john 4.0

## dict -> str:  json.dumps(<dict>)
s = json.dumps(d)
# print(type(s))			## <class 'string'>
# print(s)	## {"id": 1, "name": "john", "gpa": 4.0}

## 'pprint' allows pretty-print json.
##  Useful for printing large or deeply nested json.
from pprint import pprint
d = json.loads('{"id": 1, "name": "john", "gpa": 4.0, "department": "cs", \
	"enroll": {"math": "2021spr", "java": "2022sum", "oop": "2023fall"} }')
# pprint(d)

## pprint options:
# pprint(d, indent=5, width=20)
# pprint(d, sort_dicts=False)   ## True is default.