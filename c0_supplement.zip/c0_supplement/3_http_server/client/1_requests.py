import requests		## pip install requests
url = 'http://127.0.0.1:8080'

res = requests.get(url)
# res = requests.get(url + '/pages/hello.html')

print(res.text)



