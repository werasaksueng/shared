# pip install eth-keys
# pip install eth_utils
from eth_keys import keys
from eth_utils import keccak

## Create Off Wallet Account(owa) and offline, using keys.PrivateKey().
seed = '1234'
def create_keys():
## Create private key:
## 1. From 32 bytes of string seed. A seed is a fixed 4 bytes.
    b32 = (seed*8).encode()
    priv = keys.PrivateKey(b32)
    print(priv)
    # 0x3132333431323334313233343132333431323334313233343132333431323334

## 2. From keccak() that always return a 32 bytes.
    priv = keys.PrivateKey(keccak(seed.encode()))
    print(priv)
    # 0x387a8233c96e1fc0ad5e284353276177af2186e7afa85296f106336e376669f7

## A private key can be used to compute public key and address.
    pub = priv.public_key
    print(pub)
    # 0x8735526a6028e716da0ec15d1b991d71ce0b156ef4c79f208175f9305fa03a27cb618dbd4d19eddcd6671c3add3f61fcc96ba692e3fb3f271dda5d2251d53115

## public key -> address.
    print(pub.to_address())
    # 0xb8c059e31bcfa20b961d3f5a021b5c44d7da57ae
## Ethereum allows Checksum Address.
    print(pub.to_checksum_address())
    # 0xb8C059E31BcFa20B961d3F5A021b5C44d7DA57AE
# create_keys()

## Alternatvely using 'eth_account'.
## pip install eth_account
from eth_account import Account
def create_account():
    a = Account.create()        # randomly
    print(a.key.hex())          # hex str private key
    print(a.address)            # checksum address
# create_account()

## Most providers: Geth, Openethereum, Infura, Anvil and Ganache
##  provide service for creating Off wallet accounts.
from web3 import Web3
URL = 'http://127.0.0.1:8545'
# URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3 = Web3(Web3.HTTPProvider(URL))
def create_owa():
    a = w3.eth.account.create(seed)
    print(a._private_key.hex())
    print(a._address)
# create_owa()

#--------------------------------------------------------

## Pickling is a convenient saving python objects in file.
## Pickle Private Keys: unsafe and discourage.
import pickle
def pickle_priv():
    john_priv = '0xadbbab5c9f62b10d4bcdb3b102f29fe3fa644389e796f60155bf809cd84d9f9b'
    jack_priv = '0x5273729e45021f0b2545678e300792381a6878e1f4de94ddb8e6fd02a8427462'
    d = {'john': john_priv, 'jack': jack_priv}

## Write to file.
    with open('key', 'wb') as f:
        pickle.dump(d, f)

## Read from file.
    with open('key', 'rb') as f:
        rd = pickle.load(f)

    print('john_priv:', rd['john'])
    print('jack_priv:', rd['jack'])
# pickle_priv()

# Instead of encrypt account manually, Account provides account encrypt().
def encrypt_account():
    john_acc = Account.create('john')  # 'john' is not the account password.
    print(john_acc.key.hex())
    print(john_acc.address)

# Encrypt an account to a json(dict).
    enc_john_acc = john_acc.encrypt('hello')   # 'hello' is the password.
    # pp.pprint(enc_john_acc)

# Decrypt an encrypted account to private key
    john_priv = Account.decrypt(enc_john_acc, 'hello')
    print(john_priv.hex())

# Retrieve account from private key.
    ja = Account.from_key(john_priv)
    print(ja.address)
# encrypt_account()
