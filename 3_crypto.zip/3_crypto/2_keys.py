''' An account is generated as a key suit that consist of:
         private key, public key and addresse.

Pybitcoin provides convenient apis. 
pip install pybitcoin
'''
import bitcoin as bc
def keys_suit():
    ## Create a random private key.
    prikey = bc.random_key()
    print('private:', prikey)

    ## Compute public key from the private key.
    pubkey = bc.privkey_to_pubkey(prikey)
    print('public:', pubkey)

    ## Compute address from publice key or private key.
    addr = bc.pubkey_to_address(pubkey)
    # addr = bc.privkey_to_address(prikey)
    print('address:', addr)
# keys_suit()    ## Try: Compare to results with bitaddress.org

#--------------------------------------------------------

''' Encoding:
Keys are very big values that are clumsy an error prone for human.
The purpose of encoding is to make big values to be more manageable.
All encodings can be decoded to the same value.  '''

data = 'Hello'

def encodings():
    print('Binary:')
    ## Converts each byte to sequence of 0 and 1.
    ## Resulting too many digits of 0 and 1, not suitable for human.
    a = [bin(x)[2:] for x in data.encode()]  ## To exclude '0b' prefix
    print(a)          ## ['1001000', '1100101', '1101100', '1101100', '1101111']
    print(''.join(a)) ## 10010001100101110110011011001101111

    print('\nDecimal:')
    ## A byte may be two or three digits of 0-9. 
    ## Without separators, we cannot decode back to original value.
    a = [str(ord(x)) for x in data]
    print(a)            ## ['72', '101', '108', '108', '111']
    print(''.join(a))   ## 72101108108111

    print('\nHexadecimal:')
    ## All bytes are two hex digits of (0-9 and a-f).
    ## Too few the symbols, longer the results.
    a = [hex(ord(x))[2:] for x in data]   ## To exclude '0x' prefix
    print(a)            ## ['48', '65', '6c', '6c', '6f']
    print(''.join(a))   ## 48656c6c6f

    print('\nBase64:')
    ## More symbols (a-z, A-Z, 0-9, =, /), shorter the results.
    ## Commonly used for attachment in emails (not handled by human).  '''
    import base64       ## A standard Python lib.
    b64 = base64.b64encode(data.encode())   ## Input must be bytes.
    print(b64.decode())                     ## SGVsbG8=
    print(base64.b64decode(b64).decode())   ## Hello

    print('\nBase58:')
    ## It is base64 that excludes error prone symbols (0, o, O, I, =, /)
    ## The result are slightly longer than equivalent base64.
    ## pip install base58    '''
    import base58
    b58 = base58.b58encode(data)    ## str -> bytes.
    print(b58.decode())                     ## 9Ajdvzr
    print(base58.b58decode(b58).decode())   ## Hello

    print('\nBase58Check(WIF)')  ## (base58 + Checksum)
    ## Wallets Imported Format(WIF) is suitable to human and allows error-checking.
    ## A lot longer than equivalent base58.
    b58c = base58.b58encode_check(data)
    print(b58c.decode())                         ## vSxRbq6XzDhP
    print(base58.b58decode_check(b58c).decode()) ## Hello
# encodings()

## Python provides functions for string, binary and hex encoding. 
def str_encode():
    s = 'Hello'
    print(type(s), s)   ## <class 'str'> Hello

    ## encode(): str -> bytes (an array of bytes).
    b = s.encode()      ## A 'b' prefix string is a bytes literal.
    print(type(b), b)   ## <class 'bytes'> b'Hello'

    ## decode(): bytes -> str
    t = b.decode()
    print(type(t), t)   ## <class 'str'> Hello
#--------------------------------------------------

    ## hex(): bytes -> hex_str
    h = b.hex()	    
    print(type(h), h)   ## <class 'str'> 48656c6c6f

    ## bytes.fromhex(): hex_str -> bytes
    x = bytes.fromhex(h)
    print(type(x), x)   ## <class 'bytes'> b'Hello'
# str_encode()

################################################################

## Bitcon keys:
def bcn():
    print(bc.N)
    ## 115792089237316195423570985008687907852837564279074904382605163141518161494337

    ## To present the value in hex.
    n_hex = hex(bc.N)[2:]    ## exclude prefix '0x'.
    print(len(n_hex), n_hex)
    ## 64 fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
# bcn()   ## A slightly less than 16**64 (or 2**256).

## Generating Bitcoin private keys:
seed = 'This is a seed.'   ## Fixing seed to regenerate the same result.
def gen_prikey():
    ## 1. Random an integer within the range.
    import random
    for _ in range(3):
        print(hex(random.randint(1, bc.N))[2:])
    print()

    ## 2 Hashing bc.sha256(<seed>) returns a 32 bytes integer.
    ## There is a slim chance of overflow, but allows repeatedly generated.
    for _ in range(3):
        print(bc.sha256(seed))
    print()

    ## 3. bc.random_key() returns a random valid private key as hex_str.
    for _ in range(3):
        print(bc.random_key())
# gen_prikey()

def raw_decimal():
    hex_prikey = bc.random_key()
    print(hex_prikey)
    
    ## Hex keys -> raw decimal.
    raw_prikey = bc.decode_privkey(hex_prikey, 'hex') ## Decode from 'hex'
    print(raw_prikey)

    ## 'raw decimal' can be computed as a Python int.
    print(type(raw_prikey), 0 < raw_prikey < bc.N)
# raw_decimal()

def wif_prikey():
    hex_prikey = bc.sha256(seed)
    print(hex_prikey)
       ## 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86
   
    ## WIF private key can be computed from raw.
    raw_prikey = bc.decode_privkey(hex_prikey, 'hex')
    wif_prikey = bc.encode_privkey(raw_prikey, 'wif')
    print(wif_prikey)
       ## 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7
       ## WIF private keys begin with 5.

    ## WIF private key can be converted to hex. 
    hex_prikey = bc.encode_privkey(wif_prikey, 'hex')
    print(hex_prikey)
# wif_prikey()

## Compressed private key.
def compress_prikey(): 
    ## Uncompressed private key
    hex_prikey = bc.sha256(seed)
    print(hex_prikey)

    ## A compressed private key is the uncompressed private key appended with '01'
    comp_prikey = hex_prikey + '01'
    print(comp_prikey)

    ## Compute WIFC private key from raw compressed private key.
    ## WIFC signifies Wallets to compute public key and address as compressed.
    raw_comp_prikey = bc.decode_privkey(comp_prikey, 'hex')
    wif_comp_prikey = bc.encode_privkey(raw_comp_prikey, 'wif')
    print(wif_comp_prikey)    ## WIFC private keys begin with K or L.
    ## Uncompute WIFC private key can be computed as in the previous example.
# compress_prikey()

#------------------------------------------------------------------

''' Public keys: 
G is a tuple of point(x, y) on Elliptic Curve(EC). '''
# print(bc.G)

## Compute public key using EC generator.''' 
def gen_pubkey():
    ## Hex Private Key 
    hex_prikey = bc.sha256(seed)
    print(hex_prikey)

    ## Raw Private Key
    raw_prikey = bc.decode_privkey(hex_prikey, 'hex')
    print(raw_prikey)

    ## Raw Public Key 
    ## Fast multiply raw private key with G.
    raw_pubkey = bc.fast_multiply(bc.G, raw_prikey)
    print(raw_pubkey) ## a tuple of x and y

    ## Hex Public Key 
    ## Encode raw public key into hex.
    hex_pubkey = bc.encode_pubkey(raw_pubkey, 'hex')
    print(hex_pubkey)       ## 130 hex digits and prefix with '04'

    ## 'pybitcoin' offers privkey_to_pubkey() and privtopub().
    print(bc.privkey_to_pubkey(hex_prikey))
    print(bc.privtopub(hex_prikey))
# gen_pubkey()

''' Initially public keys contains a tuple(X, Y) both X and Y are 32-bytes.
A compressed public key contains only the X part. '''
def gen_comp_pubkey():
    hex_prikey = bc.sha256(seed)
    print('hex private key:', hex_prikey)

    hex_pubkey = bc.privkey_to_pubkey(hex_prikey)
    print('hex public key:', hex_pubkey)

    ## A raw public key is a tuple of (int, int) 
    raw_pubkey = bc.decode_pubkey(hex_pubkey, 'hex')
    print('raw public key:', raw_pubkey)

    ## Unpack the raw public key into X and Y.
    x, y = raw_pubkey
    print('X:', x)
    print('Y:', y)
    
    ## Compressed public key prefix is depend on whether y is even or odd, 
    ##   if y is even prefixed with '02' else '03'.
    if (y % 2) == 0:
        prefix = '02'
    else:
        prefix = '03'

    comp_pubkey = prefix + bc.encode(x, 16)
    print('compressed public key:', comp_pubkey, '\n')

    ## Using method to compute compressed public key from compressed private key.
    comp_hex_prikey = hex_prikey + '01'
    print('compressed private key:', comp_hex_prikey)
    print('compressed public key:', bc.privkey_to_pubkey(comp_hex_prikey))
# gen_comp_pubkey()
#------------------------------------------------------------------------

''' Bitcoin Addresses:
Bitcoin addresses are encoded with WIF(base58check) and begin with 1.
'''
def gen_address():
    hex_prikey = bc.sha256(seed)
    print('hex private key:\t', hex_prikey)
    comp_hex_prikey = hex_prikey+ '01'		
    print('compressed private key:\t', comp_hex_prikey)
      
    ## Uncompressed private key -> address
    print('address:\t\t', bc.privkey_to_address(hex_prikey))

    ## Compressed private key -> compressed address
    print('compressed address:\t', bc.privkey_to_address(comp_hex_prikey))
    
    ## It is possible to compute: private key -> public key -> address.
# gen_address()

## Manually compute address from public key.
def public_to_address():
    hex_prikey = bc.sha256(seed)
    hex_pubkey = bc.privkey_to_pubkey(hex_prikey)
    byt_pubkey = bytes.fromhex(hex_pubkey)

    sha256_hash = hashlib.sha256(byt_pubkey).digest()
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(sha256_hash)
    hash_pubkey = ripemd160.digest()
    prefix = b'\x00'          ## Prefix for mainnet
    extended_key = prefix + hash_pubkey
    checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
    addr = base58.b58encode(extended_key + checksum).decode('utf-8')
    print("address:", addr)
# public_to_address()
#----------------------------------------------------------------

''' Alternatively:
'bitcoinlib' is a library which is high-level and user-friendly
 but less flexible. It comes with built-in wallet management
 and Blockchain interaction.
    https://bitcoinlib.readthedocs.io/en/latest/

pip install bitcoinlib   '''
from bitcoinlib.keys import Key
import json
def create_keys():      ## Create a random key
    k = Key()           ## Try: Key(network='testnet')
    print('Privatekey:', k.private_hex)
    print('Compressed Wif Privatekey:', k.wif())
    print('Compressed Publickey:', k.public())
    print('Compressed Address:', k.address())
    # print(json.dumps(k.info(), indent=4, sort_keys=True))
# create_keys()

## Working with already exsit private keys.
def import_keys():
    ## Import hex Private key
    k1 = Key('6c16208a64f0aa2f09df5a0380ce939c854578c3ca3d9e9f648f232dadd26040')
    print('Publickey:', k1.public())

    ## Import wif private key
    k2 = Key('KzqpKvCDWMeAqCtVkjGX389rwFyXK1dCFtY3n8nF98mcB2DoV2UF')
    print('Publickey:', k2.public())
# import_keys()

#####################################################################

''' Ethereum Keys:
pip install eth-keys
pip install eth_utils  '''
from eth_keys import keys
from eth_utils import keccak

## Create Off Wallet Account(owa) and offline, using keys.PrivateKey().
seed = '1234'
def create_keys():
    ## Create private key:
    ## 1. From 32 bytes of string seed. A seed is a fixed 4 bytes.
    b32 = (seed*8).encode()
    priv = keys.PrivateKey(b32)
    print(priv)
    # 0x3132333431323334313233343132333431323334313233343132333431323334

    ## 2. From keccak() that always return a 32 bytes.
    priv = keys.PrivateKey(keccak(seed.encode()))
    print(priv)
    # 0x387a8233c96e1fc0ad5e284353276177af2186e7afa85296f106336e376669f7

    ## A private key can be used to compute public key and address.
    pub = priv.public_key
    print(pub)
    # 0x8735526a6028e716da0ec15d1b991d71ce0b156ef4c79f208175f9305fa03a27cb618dbd4d19eddcd6671c3add3f61fcc96ba692e3fb3f271dda5d2251d53115

    ## public key -> address.
    print(pub.to_address())
    # 0xb8c059e31bcfa20b961d3f5a021b5c44d7da57ae

    ## Ethereum Checksum Address.
    print(pub.to_checksum_address())
    # 0xb8C059E31BcFa20B961d3F5A021b5C44d7DA57AE
# create_keys()

## Alternatively using 'eth_account'.
## pip install eth_account
from eth_account import Account
def create_account():
    a = Account.create()        ## randomly
    print(a.key.hex())          ## private key hex str 
    print(a.address)            ## checksum address
# create_account()

## Most providers: Geth, Infura, Anvil and Ganache
## provide service for creating Off wallet accounts.
from web3 import Web3
# URL = 'http://127.0.0.1:8545'
URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3 = Web3(Web3.HTTPProvider(URL))
def create_owa():
    a = w3.eth.account.create(seed)
    print(a._private_key.hex())
    print(a._address)
# create_owa()

## Pickling is a process of saving python objects to file.
## Pickle Private Keys: convenient but unsafe.
import pickle
def pickle_priv():
    john_priv = '0xadbbab5c9f62b10d4bcdb3b102f29fe3fa644389e796f60155bf809cd84d9f9b'
    jack_priv = '0x5273729e45021f0b2545678e300792381a6878e1f4de94ddb8e6fd02a8427462'
    d = {'john': john_priv, 'jack': jack_priv}

    ## Write to file.
    with open('key', 'wb') as f:
        pickle.dump(d, f)

    ## Read from file.
    with open('key', 'rb') as f:
        rd = pickle.load(f)

    print('john_priv:', rd['john'])
    print('jack_priv:', rd['jack'])
# pickle_priv()

''' Saved accounts should be encrypted. 
'eth_account' Account provides account encryption. '''
def encrypt_account():
    john_acc = Account.create('john')  # 'john' is not the account password.
    print(john_acc.key.hex())
    print(john_acc.address)

    ## Encrypt an account to a json(dict) which may be pickled. 
    enc_john_acc = john_acc.encrypt('hello')   # 'hello' is the password.

    ## Decrypt an encrypted account to private key
    john_priv = Account.decrypt(enc_john_acc, 'hello')
    print(john_priv.hex())

    ## Retrieve account from private key.
    ja = Account.from_key(john_priv)
    print(ja.address)
# encrypt_account()

