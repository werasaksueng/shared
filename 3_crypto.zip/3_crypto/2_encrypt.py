''' Using paaword as key for encryption.
Generate password: Restriction.
   Exclude Symbols: 1, 0, I, l, o, O.
   Length: 5 to 8 characters.      '''
MIN, MAX = 4, 7
SYM = '23456789aAbBcCdDeEfFgGhHijJkKLmMnNpPqQrRsStTuUvVwWxXyYzZ'
import random
def gen_pwd():
    pwd = [random.choice(SYM) for _ in range(random.randint(MIN, MAX))]
    return ''.join(pwd)
# print(gen_pwd())
# print([gen_pwd() for _ in range(10)])

def is_valid_pwd(pwd):
   if type(pwd) is str:
      if MIN <= len(pwd) <= MAX:
         for c in pwd:
            if c not in SYM:
               return False
         return True
   return False
# print([is_valid_pwd(gen_pwd()) for _ in range(10)])

#------------------------------------------------------

def key_pwd():
## XOR Encrypting a msg(str) with a password(str).
   def encode(msg, pwd):
      if not is_valid_pwd(pwd):
         return 'Invalid password'
      key = int.from_bytes(pwd.encode(), 'big')
      msg_int = int.from_bytes(msg.encode(), 'big')
      return key ^ msg_int         ## int

   def decode(enc, pwd):
      if not is_valid_pwd(pwd):
         return 'Invalid password'
      key = int.from_bytes(pwd.encode(), 'big')
      msg_int = key ^ enc     # int
      length = msg_int.bit_length()
      msg = msg_int.to_bytes((length+ 7) // 8, 'big')
      return msg.decode()

   private_key = '981e355811ee4b29aaac91d41ac37e1d6679b38a1631b95b07f1f31d9c7186a8'
   pwd = 'hi234'
   enc = encode(private_key, pwd)
   print(enc)
   dec = decode(enc, pwd)
   print(dec)
   print(dec == private_key)
# key_pwd()

#------------------------------------------------------------

# pip install redis
import redis
##  mybat\start_redis.bat

def redis_test():
    rd = redis.Redis() # host='localhost', port=6379, db=0, 
                  # password=None, socket_timeout=None,...
    # print(rd.ping())

    rd.set('john', 'john@rambo.com')
    rd.set('jack', 'jack@ripper.com')

    print(rd.get('john'))  ## byte str
    # print(rd.get('jack').decode()) 

# Delete all
    rd.flushall()
# redis_test()

## User passwords should never be saved in any machines.
## So how can we verify a password of a user.
## Password Hashing: Store the hash of user+pwd.
import bitcoin as bc
def pw_hash():
    rd = redis.Redis() 

    def my_hash(name, pwd):
        return bc.sha256((name+pwd))

    def register(name, pwd):
        if rd.get(name):
            return "The name is already registered."
        rd.set(name, my_hash(name, pwd))
        return 'Register success'
        
    def login(name, pwd):
        hash = rd.get(name)
        if hash.decode() == my_hash(name, pwd):
            return 'Valid'
        return 'Invalid'

    print(register('John', 'hello123'))
    print(login('John', 'hello123'))
    # rd.flushall()
# pw_hash()

## Data are dumped into 'dump.rdb' in working directory 
##   when the server is closed. C:\mycrypto\etc\redis_
## del C:\mycrypto\etc\redis_\dump.rdb