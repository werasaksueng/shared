''' To participate in a Blockchain System.
  - Users must create their own private key then the corresponding
     public key and address can be computed.
  - The private key must be kept private, the public key and address
     can be exposed publicly.
  - The owner identity of public key and address may or may not be declared.
  - A transaction(tx) is a record of transferring asset from sender to receiver.
    txs are strictly verified, e.g. the sender has enough to spend. 
    txs must be signed with the sender private key.
    txs are stored, un-encrypt in Blockchain, so that anyone can verify.
        Check: https://etherscan.io/
  - Abstractly a tx is.
            <sender pub_key> <amount> <receiver addr> <sig>

Suppose 'john' is a sender and 'jack'is a receiver.
  - Ex. 'john' send 10 BTC to 'jack', 'john' creates a tx:
            <john pub_key> 10 <jack addr> <sig>
    'john' is the asset owner, spender or sender depended on the context.
    'john' must sign the tx with his private key, resulting 
        a signature <sig> which is sent with the tx.
          <tx content> sign with <john private key> -> <sig>
    The tx can be publicly verified by anyone:
            <tx content> + <sig> + <john public key> -> boolean
    if the result is 'true' then the tx is:
        -- not tampered (during transferred and stored in Blockchain).
        -- created and signed by <sender private key>. 
    <jack addr> specifies that 'jack' is the asset receiver, when the tx
      is confirmed 'jack' will be the asset owner and can spend the asset.

Suppose 'jack' spend his asset by send 5 BTC to 'joe'
    'jack' creates and signs a tx:
        	<jack pub_key> 5 <joe addr> <sig>
    <jack pub_key> is used to proof that he is the owner of <jack addr>
        which is the receiver in the tx that sent from 'john'.
    The tx must be signed with 'jack' private key which is a stronger proof
        that he is the owner of the transferred asset.

We must mutually agreed that:
 - All verified and confirmed txs are final and cannot be removed or denied.
 - It is the responsibility of asset owners to keep their private key secret and secure.
 - A private key is the evident of the rightful owner of the asset.
	If it is stolen the asset can be stolen.
	If it is lost the asset is gone forever. 
'''
import bitcoin as bc
pri = bc.random_key()
pub = bc.privkey_to_pubkey(pri)
addr = bc.pubkey_to_address(pub)

''' To proof that 'jack' is the owner of <jack addr> which is the receiver of the tx,
 he creates a tx to spend the asset with <jack public key> as the sender: '''
# print( addr == bc.pubkey_to_address(pub) )      # True

def tx_authen():
# For simplicity, suppose 'msg' is a tx.
    msg = 'Hello how do you do?'

# Sign: 'msg' + private key --> signature
    sig = bc.ecdsa_sign(msg, pri)
    # print(sig)

# Try: 'msg' is modified.
    # msg = 'Hello how do you do.'
    
# Try: Invalid public key
    # pub = bc.privkey_to_pubkey(bc.random_key())

# Verify: 'msg' + signature + public key --> result(boolean)
    print(bc.ecdsa_verify(msg, sig, pub))
# tx_authen()
