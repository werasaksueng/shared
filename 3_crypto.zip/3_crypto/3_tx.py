from bitcoinlib.keys import Key
def gen_account():
   k = Key()   
   return k.wif(), k.public_hex, k.hash160.hex(), k.address()
# wifc_prikey, c_pubkey, pkh, addr = gen_account()
wifc_prikey = 'L1BnCzdRNQQvLDofsV6jDGEkmBcVkPknCFrkKJ7woxFThdnJZDwb'
c_pubkey = '032a819ce7226d4d7e8a9c77f663bb17b111d4144b15cb7191fe15de585f9b08e8'
pkh = '5f0f183d2afc782e92c3999296e575019c33315b'   ## 20 bytes
addr = '19fdH2DE5722Gqbb7rEKora4GwACr9TXZH'

## To compute address from public key hash (pkh).
## hash160() is ripemd-160(sha256) 
import hashlib, base58
def pkh_to_addr(pkh):
    ## Convert str to bytes
    pkh_en = bytes.fromhex(pkh)

    ## Append the version code
    vc = b'\x00'
    vpkh = vc + pkh_en

    ## Compute the checksum (first 4 bytes of double SHA-256)
    checksum = hashlib.sha256(hashlib.sha256(vpkh).digest()).digest()[:4]

    ## Append the checksum to vh160
    vpkh_cs = vpkh + checksum
 
    ## Encode with Base58
    return base58.b58encode(vpkh_cs).decode('utf-8')
# print(pkh_to_addr(pkh))

def receiver_proof(pkh, addr):
    print(pkh_to_addr(pkh) == addr) 
# receiver_proof(pkh, addr)

def tx_authen():
    prikey, pubkey, addr = gen_account()

    ## For simplicity, suppose 'msg' is a tx.
    msg = 'Hello how do you do?'

    ## Sign: 'msg' + private key --> signature
    sig = bc.ecdsa_sign(msg, prikey)
    # print(sig)

    ## Try: 'msg' is modified.
    # msg = 'Hello how do you do.'

    ## Try: Invalid public key
    # pubkey = bc.privkey_to_pubkey(bc.random_key())

    ## Verify: 'msg' + signature + public key --> result(boolean)
    print(bc.ecdsa_verify(msg, sig, pubkey))
# tx_authen()
#---------------------------------------------------
