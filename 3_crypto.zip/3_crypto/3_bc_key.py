# Check:   bitaddress.org

# https://bitcoinlib.readthedocs.io/en/latest/
# pip install bitcoinlib
from bitcoinlib.keys import Key
import json
def create_key():
# Create random key
    k = Key()           # Try: Key(network='testnet')
    print(k.private_hex)
    print('Compressed Publickey:', k.public())
    print('Compressed Address:', k.address())
    print('Compressed Wif Privatekey:', k.wif())
    # print(json.dumps(k.info(), indent=4, sort_keys=True))

# Import hex Private key
    # k = Key('6c16208a64f0aa2f09df5a0380ce939c854578c3ca3d9e9f648f232dadd26040')

# Import wif private key
    # k = Key('KzqpKvCDWMeAqCtVkjGX389rwFyXK1dCFtY3n8nF98mcB2DoV2UF')
# create_key()

# Bip38:
def bip38():
    k = Key('KzqpKvCDWMeAqCtVkjGX389rwFyXK1dCFtY3n8nF98mcB2DoV2UF')
    print(k.private_hex)

    enc = k.bip38_encrypt('hello123')
    print(enc)

    ek = Key(enc, password='hello123')
    print(ek.private_hex)
# bip38()

# Try: bitaddress.org Wallet Details
##    Private Key:       6c16208a64f0aa2f09df5a0380ce939c854578c3ca3d9e9f648f232dadd26040
##    BIP38 Encrypt?     true
##    Passphrase:        hello123
##    Private Key BIP38: 6PRQD3weGpFMnL1xCUdkjsMTShiqh5T5ZPwFDRqLJtg65UNQrysaqKQjow
## Then Try: Decrypt BIP38

