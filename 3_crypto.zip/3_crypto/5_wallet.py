''' Private keys are so large and not comfortable for mortal humans.
Large organization or just a person may possess a lot of private keys.
Saving private keys in storage surely need heavy protection.
'Wallet' handles a set of accounts.

## Deterministic Wallet (D Wallet):
Compute a private key from a password and index. '''
import bitcoin as bc
pwd = 'hello123'
## To Compute the private key of index 3.
# print(bc.sha256(pwd + str(3)))

''' 
Having a password per private key is proofed to be a nightmare.
Having a password for the whole wallet does not make a good night sleep.
Bitcoin sugests BIP32 'mnemonic' which is a stronger password, that 
  compose of a list of words. '''
# pip install mnemonic
from mnemonic import Mnemonic

## Languages List:
# print(Mnemonic.list_languages())

## English Words List:
# print(Mnemonic('english').wordlist)

## Create entropy from an randomness:
# An entropy must be a 16, 20, 24, 28, or 32 hexadecimal digits string.
import random
def gen_entropy():
    r = ''
    for i in range(random.choice([16, 20, 24, 28, 32])):
        r += '{:x}'.format(random.randint(0, 15))
    return r.encode()   ## bytes array

def gen_mnemonic():
    ent = gen_entropy()
    print("Entropy:", ent.decode())
    print("Mnemonic:", Mnemonic('english').to_mnemonic(ent))
# gen_mnemonic()

''' Normally a wallet is created from a seed which is a very big number.
To prevent easy recreating a wallet we use a mnemonic to compute a seed.
It is a good practice to have another password to protect the seed. '''
def gen_seed():
    my_mnemonic = 'corn coyote snow hockey great rain system educate good arch escape shift'
    my_password = 'hello123'
    my_seed = Mnemonic.to_seed(my_mnemonic, passphrase=my_password)
    return my_seed.hex()
seed = gen_seed()
# print(seed)

## 'Account' allows creating wallet with mnemonic. 
from eth_account import Account
import pickle
def  account_mnemonic():
## Enable HD wallet
    Account.enable_unaudited_hdwallet_features()

## Create an account with mnemonic.
    acc, mm = Account.create_with_mnemonic()
    print(acc.address)
    print(mm)

## Pickle mnemonic. 
    with open('mnemonic', 'wb') as f:
        pickle.dump(mm, f)
## Retrieve account and mnemonic.
    with open('mnemonic', 'rb') as f:
        m = pickle.load(f)

## Recreate the account from mnemonic.
    print(Account.from_mnemonic(m).address)
# account_mnemonic()

#-------------------------------------------------------------

''' Hierarchical Deterministic Wallets (HD Wallet, BIP32)
Accounts are organized as a tree.
A seed is used for creating a root account.   '''
# pip install bip32utils
from bip32utils import BIP32Key
root = BIP32Key.fromEntropy(seed.encode(), public=False)

def hd_wallet():
## An account has a private key so public key and address are available.
    print(root.PrivateKey().hex())
    print(root.PublicKey().hex())
    print(root.Address())

## Create 3 child account of the root.
    for i in range(3):
        print(i, root.CKDpriv(i).Address())
    print()

## Create 2 child account of of the first child account(index 0).
    c0 = root.CKDpriv(0)
    for j in range(2):
        print(j, c0.CKDpriv(j).Address())
## hd_wallet()

def get_addr(i, j):
    return root.CKDpriv(i).CKDpriv(j).Address()
# print(get_addr(0, 1))

#-------------------------------------------------------

API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

## Create Ethereum Wallet with tatum.io.
def create_wallet():
   URL = "https://api.tatum.io/v3/ethereum/wallet"
   print_json(requests.get(URL, headers=HEADERS))
# create_wallet()
mnemonic = "remove ivory roof endless meadow carpet ask meat also pause vacant call grass slot wagon silver museum talk occur safe wild vocal spread left"
xpub = "xpub6FBhDhUz1VHNhtcQb47fWN2W9HVkPkNHzJniAYwK8RpuCbUJFWiSuFDks74xqypD5UKgCboXRjfbx832AaxoUg2UKB2djkXqmYRgJRWwmps"

def create_priv(index):
   URL = "https://api.tatum.io/v3/ethereum/wallet/priv"
   DATA = {
      "index": index,
      "mnemonic": mnemonic
   }
   print_json(requests.post(URL, headers=HEADERS, json=DATA))
# create_priv(1)
key = "0xee22c9cfb0f47c40dc81e4b3888327b3020354e15fa8ef42ca0a395624a330ee"

## Generate a Bitcoin address from the extended public key*xpub) of the wallet.
## An address is generated for the specific index (0 up to 2^31 - 1).
def create_addr(index):
   URL = "https://api.tatum.io/v3/ethereum/address/" + xpub + "/" + str(index)
   print_json(requests.get(URL, headers=HEADERS))
# create_addr(1)   
address = "0x0be204528fbc6636edf3e9eb7805f3d91b0b0d22"
