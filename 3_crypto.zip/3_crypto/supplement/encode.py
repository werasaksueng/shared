''' Keys and addreses are very big integers.
We need encodings to handle the value by human. '''

## Binary Encoding: (0-1) Too many digits.
data = 'Hello'
## Convert each byte to binary.
def bin_encode():
    a = [bin(x)[2:] for x in data.encode()] # exclude '0b' prefix
    print(a)    # ['1001000', '1100101', '1101100', '1101100', '1101111']
    print(''.join(a)) # 10010001100101110110011011001101111
# bin_encode()

## Decimal: (0-9) A byte may be two or three digits.
## Without separators, we cannot decode back to original value.
def dec_encode():
    a = [str(ord(x)) for x in data]
    print(a)            # ['72', '101', '108', '108', '111']
    print(''.join(a))   # 72101108108111
# dec_encode()

## Hexadecimal: (0-9 and a-f) All bytes are two hex digits.
def hex_encode():
    a = [hex(ord(x))[2:] for x in data]   # exclude '0x' prefix
    print(a)            # ['48', '65', '6c', '6c', '6f']
    print(''.join(a))   # 48656c6c6f

##Python supports encoding str -> hex_str
## hex() encodes bytes to hex_string.
    h = data.encode().hex()
    print(h)             # 48656c6c6f

## hex_str -> str
    s = bytes.fromhex(h).decode()
    print(s)             # Hello
# hex_encode()

## Base64:  (a-z, A-Z, 0-9, =, /)
## Using more symbols, resulting shorter result than equivalent hexadecimal.
## Commonly used for attachment in emails (not handled by human).
import base64       ## A standard Python lib.
def base64_encode():
    b64 = base64.b64encode(data.encode())
    print(b64.decode())                     # SGVsbG8=
    print(base64.b64decode(b64).decode())   # Hello
# base64_encode()

## Base58: (base64, exclude 0, o, O, I, =, /)
## Less error prone but slightly longer than equivalent base64.
## More suitable to human than base64.
## pip install base58
import base58
def base58_encode():
    b58 = base58.b58encode(data)    # accepts str, returns bytes.
    print(b58.decode())                     # 9Ajdvzr
    print(base58.b58decode(b58).decode())   # Hello
# base58_encode()

## Base58Check(WIF): (base58 + Checksum)
# WIF is Wallets Imported Format. Suitable to human and allows error-checking.
# Prefix with version code and suffix with checksum then encoded with base85.
def base58check_encode():
   b58c = base58.b58encode_check(data)
   print(b58c.decode())                         # vSxRbq6XzDhP
   print(base58.b58decode_check(b58c).decode()) # Hello
# base58check_encode()

#################################################################

''' Python String Handling:
Most programs handle data by bytes or characters.
Python str is a sequence of Unicode characters,
A Unicode character may be one to four bytes. '''
s1 = 'ABC'
s2 = 'กขค'
def str_iterate():
    # len() returns number of characters, not bytes.
    print(len(s1), len(s2))     # 3 3

    # By default, strs are iterated by character.
    for c in s1:
        print(c, end=',')       # A,B,C,
    print()

    for c in s2:
        print(c, end=',')       # ก,ข,ค,
# str_iterate()

##  <str>.encode()  converts str to bytes (byte array).
##  <str>.decode()  converts bytes to str.
def enc_dec():
    se = s1.encode()
    print(se)           # b'ABC'    (Bytes literals)
    print(se.decode())  # ABC

    ## Bytes are iteratred by bytes.
    for c in s1.encode():       ## 65,66,67,
        print(c, end=',')
    print()
    for c in s2.encode():
        print(c, end=',')       ## 224,184,129,224,184,130,224,184,132,
# enc_dec()

''' A plain English string is represented as ASCII codes of Unicodes
which is 7 bits of a byte. '''

data = 'Hello'      # 5 bytes(characters).
def binary():
    # int -> binary
    print(bin(3))           # 0b11
    # Binary base int literals begin with '0b'.

    # Python does not support 'char' type, but single character str.
    # ord(<character>) returns Unicode value(as int) of the character.
    print(ord('A'))         # 65
    # char -> binary
    print(bin(ord('A')))    # 0b1000001
# binary()
