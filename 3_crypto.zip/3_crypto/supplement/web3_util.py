## pip install web3

## Online web3 utilities:
from web3 import Web3
# w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

## Off-online web3 utilities:
from web3.auto import w3
# print(w3.is_connected())

def to_hex_test():
    print(w3.to_hex(False), w3.to_hex(True))  # 0x0 0x1
    print(w3.to_hex(0), w3.to_hex(1))         # 0x0 0x1
    print(w3.to_hex(0x000f))                 # 0xf.

    print(w3.to_hex(b'\x00\x0f'))            # 0x000f
    print(w3.to_hex(text='abc'))             # 0x616263
    print(w3.to_hex(hexstr='616263'))        # 0x616263

    a = "0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266"
    print(w3.to_hex(hexstr=a))
# to_hex_test()

def to_bytes_test():
    print(w3.to_bytes(False), w3.to_bytes(True))  # b'\x00' b'\x01'
    print(w3.to_bytes(0), w3.to_bytes(1))         # b'\x00' b'\x01'
    print(w3.to_bytes(0x000f))                   # b'\x0f'
    print(w3.to_bytes(b'\x00\x0f'))              # b'\x00\x0f'
    print(w3.to_bytes(text='abc'))               # b'abc'
    print(w3.to_bytes(hexstr='616263'))          # b'abc'
# to_bytes_test()

def to_text_test():  # decoded as UTF-8
    print(w3.to_text(b'abc'))                # abc
    print(w3.to_text(hexstr='616263'))       # abc
# to_text_test()

def to_int_test():
    print(w3.to_int(False), w3.to_int(True))          # 0 1
    print(w3.to_int(0x000F), w3.to_int(b'\x00\x0F'))  # 15 15
    print(w3.to_int(hexstr='000F'))                  # 15
# to_int_test()

def to_json_test():
    print(w3.to_json(1))                 # 1
    d = {'one': 1}
    print(type(d), w3.to_json(d))        # <class 'dict'> {"one": 1}
    print(w3.to_json([{'one': 1}]))      # [{"one": 1}]
# to_json_test()

from decimal import Decimal
def wei_test():   # 1 eth = 10**18 wei
    # eth -> wei
    print(w3.to_wei(1, 'ether'))         # 1000000000000000000
    # wei -> eth
    print(w3.from_wei(1000000000000000000, 'ether'))   # 1

    # 1 gwei = 10**9 wei
    print(w3.to_wei(Decimal('0.000000001'), 'ether')) # 1000000000
    print(w3.from_wei(1000000000, 'gwei'))            # 1

    print(w3.from_wei(12345678900000000001, 'ether')) # 12.345678900000000001
    print(w3.to_wei(Decimal('12.345678900000000001'), 'ether')) # 12345678900000000001
# wei_test()
