## pip install web3

## Online web3 utilities:
from web3 import Web3
# w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

## Off-online web3 utilities:
from web3.auto import w3
# print(w3.isConnected())

def toHex_test():
    print(w3.toHex(False), w3.toHex(True))  # 0x0 0x1
    print(w3.toHex(0), w3.toHex(1))         # 0x0 0x1
    print(w3.toHex(0x000f))                 # 0xf.

    print(w3.toHex(b'\x00\x0f'))            # 0x000f
    print(w3.toHex(text='abc'))             # 0x616263
    print(w3.toHex(hexstr='616263'))        # 0x616263

    a = "0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266"
    print(w3.toHex(hexstr=a))
toHex_test()

def toBytes():
    print(w3.toBytes(False), w3.toBytes(True))  # b'\x00' b'\x01'
    print(w3.toBytes(0), w3.toBytes(1))         # b'\x00' b'\x01'
    print(w3.toBytes(0x000f))                   # b'\x0f'
    print(w3.toBytes(b'\x00\x0f'))              # b'\x00\x0f'
    print(w3.toBytes(text='abc'))               # b'abc'
    print(w3.toBytes(hexstr='616263'))          # b'abc'
toBytes()

def to_text():  # decoded as UTF-8
    print(w3.toText(b'abc'))                # abc
    print(w3.toText(hexstr='616263'))       # abc
to_text()

def to_int():
    print(w3.toInt(False), w3.toInt(True))          # 0 1
    print(w3.toInt(0x000F), w3.toInt(b'\x00\x0F'))  # 15 15
    print(w3.toInt(hexstr='000F'))                  # 15
to_int()

def to_json():
    print(w3.toJSON(1))                 # 1
    d = {'one': 1}
    print(type(d), w3.toJSON(d))        # <class 'dict'> {"one": 1}
    print(w3.toJSON([{'one': 1}]))      # [{"one": 1}]
to_json()

from decimal import Decimal
def wei():   # 1 eth = 10**18 wei
    # eth -> wei
    print(w3.toWei(1, 'ether'))         # 1000000000000000000
    # wei -> eth
    print(w3.fromWei(1000000000000000000, 'ether'))   # 1

    # 1 gwei = 10**9 wei
    print(w3.toWei(Decimal('0.000000001'), 'ether')) # 1000000000
    print(w3.fromWei(1000000000, 'gwei'))            # 1

    print(w3.fromWei(12345678900000000001, 'ether')) # 12.345678900000000001
    print(w3.toWei(Decimal('12.345678900000000001'), 'ether')) # 12345678900000000001
wei()
