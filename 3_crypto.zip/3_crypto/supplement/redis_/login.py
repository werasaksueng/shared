''' Password Hashing:
The user passwords should never be directly saved or even encrypted.
A more practical solution is saving hash of passwords. '''

## pip install redis
import redis
r = redis.Redis()
# print(r.ping())

import bitcoin as bc
def register(name, pwd):
    r.set(name, bc.sha256(name+pwd))

# register('John', 'hello')
# print(r.get('John'))   ## bytes

def login(name, pwd):
    if r.get(name).decode() == bc.sha256(name+pwd):
        return 'Valid'
    return 'Invalid'

print(login('John', 'hellox'))
