set PATH=C:\mycrypto\etc\Redis
cd C:\mycrypto\3_crypto\supplement\redis_
redis-server