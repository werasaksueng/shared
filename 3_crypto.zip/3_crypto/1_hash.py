import hashlib    ## A standard Python's lib
# print(hashlib.algorithms_available)

## pip install pybitcoin
import bitcoin as bc

msg = 'Hello! how are you today?'
## Bitcoin uses Sha256: 64 chars (32 bytes)
def bitcoin_hash():
    sha256 = hashlib.sha256(msg.encode())
    sha256_str = sha256.hexdigest()
    print(len(sha256_str), sha256_str)

    bc_sha256 = bc.sha256(msg)
    print(len(bc_sha256), bc_sha256)
# bitcoin_hash()
## Try: Md5: (16 bytes), Sha1: (20 bytes)

## pip install eth-utils
from eth_utils import keccak, encode_hex
## Ethereum uses Keccak-256 hashing (32 bytes).
def ethereum_hash():
    me = keccak(msg.encode())   # byte array
    print(encode_hex(me))
    # 0x1613f1e3375bc66e4a4f79f174bee9adcc54312c206b8a9ba3fc4a06d58dcfe6
# ethereum_hash()
#------------------------------------------------------------

## Tamper Proof: is a verification that data had been tamperred.
from myutil import *
def gen_hash(file_name, hash_file):
    msg = read_file(file_name)
    write_file(hash_file, bc.sha256(msg))
# gen_hash('hello.txt', 'myhash')

def verify_hash(file_name, hash_file):
    msg = read_file(file_name)
    hash = read_file(hash_file)
    if hash == bc.sha256(msg):
        print('Valid')
    else:
        print('Invalid')
# verify_hash('hello.txt', 'myhash')
## Try: Modify hello.txt.
#------------------------------------------------------------

## Hash References: Allows using dict(hash table) to store items
##  that can be verified if an item had been modified.
def hash_ref():
    d = dict()  ## A collection of items of <key>:<value>.

# Storing an item with the hash of value as the key.
    value = 'Hello'
    key = bc.sha256(value)
    d[key] = value

# Get value by the key.
    print(d[key])             #  Hello

## Try: If the value is modified.
    # d[key] = 'Hello!'

## Try: If the key is modified.
    # key = bc.sha256("Hi")

## Verify the item is valid.
    v = d.get(key)
    if v != None and key == bc.sha256(v):
        print(v)
    else:
        print('Invalid')
# hash_ref()
#----------------------------------------------------------

''' Blockchain is a chain of blocks using hash references.
Ex. Poorman Blcokchain: For simplicity assume that:
    A block is a str(of name).
    A block id is its hash.
    A blockchain is implemented as a dict.
    A blockchain item(or tx) is a tuple of (<previous_hash>, <block>)
'''
def poorman_blockchain():
# Initially the blockchain is empty.
    blockchain = dict()
    last_block = None

    def add_tx():
        data0 = 'John'
        id0 = bc.sha256(data0)
        blockchain[id0] = [None, data0]   # genesis block

        data1 = 'Jack'
        id1 = bc.sha256(data1)
        blockchain[id1] = [id0, data1]

        data2 = 'Joe'
        id2 = bc.sha256(data2)
        blockchain[id2] = [id1, data2]
        nonlocal last_block
        last_block = id2

    def print_blockchain():
        for i in blockchain:
            print(i, blockchain[i])

    def verify_blockchain():
        i = last_block
        if i != bc.sha256(blockchain[i][1]):
            print('Last block error')
            return
        while i != None:
            phash = blockchain[i][0]
            if phash != None and phash != bc.sha256(blockchain[phash][1]):
                print('Error')
                return
            i = blockchain[i][0]
        print('valid')

    add_tx()
## Try: modify tx2, 'Jack' -> 'jack'
    # blockchain[blockchain[last_block][0]][1] = 'jack'
    print_blockchain()
    verify_blockchain()
# poorman_blockchain()
#------------------------------------------------------------------

''' 'nonce' is an integer to be included in the block, to effect the hash result.
'Mining' is the process of finding a 'nonce' such that the block hash 
  has the number of preceeding zeros more than a certain value, defined by 'diff'. '''
def mine(diff):
## Suppose a block is just a string.
    block = 'Hello how do you do?'

## 'Target' is a string of diff zeros.
    target = '0'*diff
    print(target)

## Normally 'nonce' is searched sequentially.
    nonce = 0
    while True:
        # Suppose 'nonce' is just appended to a block.
        h = bc.sha256(block + str(nonce))
        if h.startswith(target):
            print('%d\t%s\n' % (nonce, h))
            break
        nonce += 1

def mining():
    for i in range(1, 6):
        mine(i)
# mining()