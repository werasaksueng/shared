import hashlib  ## A standard Python's lib.
# print(hashlib.algorithms_available)

msg = 'Hello! how are you today.'
msg_en = msg.encode()                 ## bytes

def hash_ex():
    ## MD5 and Sha1 are very popular since 1980s.
    ## Md5:  32 chars (16 bytes) 
    s = hashlib.md5(msg_en).hexdigest()
    print(s, '\t', len(s))

    ## Sha1:  40 chars (20 bytes) 
    s = hashlib.sha1(msg_en).hexdigest()
    print(s, '\t', len(s))

    ## Sha256:  64 chars (32 bytes, 256 bits)
    s = hashlib.sha256(msg_en).hexdigest()
    print(s, '\t', len(s))
# hash_ex()

def sha256(msg):
   return hashlib.sha256(msg.encode()).hexdigest()

## Little bit modification results unrecognizable hash.
def mod_input():
   msg = 'Hello! how are you today.'
   print(sha256(msg))
   msgx = 'Hello! how are you today?'
   print(sha256(msgx))
# mod_input()

#--------------------------------------------------------

## There are a lot of Bitcoin and Ethereum support libs.

''' Using Bitcoin support libs:
pip install bitcoinlib 
  - Supports Bitcoin and other blockchains (Litecoin, Dogecoin, etc.)
  - Wallet management (create, import, and manage HD wallets)
  - Transaction building & signing
  - Blockchain query (get balance, transactions, UTXOs, etc.)
'''
import bitcoinlib.encoding as bce
# print(bce.sha256(msg_en).hex())

#--------------------------------------------------------

''' Using Ethereum support libs:
pip install eth-utils
  - Conversion: integer, bytes, string and hex .
  - Support encoding, decoding and hashing(Keccak-256).
  - Address Manipulation: normalize, checksum, and validation.
'''
from eth_utils import keccak
# print(keccak(msg_en).hex())

#--------------------------------------------------------------------

## Tamper Proof is a process to verify if a data had been modified.
def read_file(name):
    with open(name, 'r') as f:
       msg = f.read()
    return msg

def gen_hash(input_file, hash_file):
    input = read_file(input_file)
    hash = sha256(input)

    ## Save the hash into a file.
    with open(hash_file, 'w') as f:
        f.write(hash)
    print('Success')
# gen_hash('hello.txt', 'myhash')

def tamper_proof(file_name, hash_file):
    input = read_file(file_name)
    hash = read_file(hash_file)
    if hash == sha256(input):
        print('Valid')
    else:
        print('Invalid')
# tamper_proof('hello.txt', 'myhash')    ## Try: Modify hello.txt.
#----------------------------------------------------------------

## For simplicity diff defined the number of preceding zeros.
def mining(diff):
    ## Suppose a block is just a string.
    block = 'Hello how do you do?'

    ## A 'target' is a string of 'diff' zeros.
    target = '0'*diff
    print('\nTarget:', target)

    ## A simple 'nonce' searching.
    nonce = 0
    while True:
        ## 'nonce' is appended to a block before hashing.
        h = sha256(block + str(nonce))
        if h.startswith(target):
            print('noune: %d\t hash: %s' % (nonce, h))
            break
        nonce += 1

## The larager 'diff', the longer searching time.
def pow():
    for i in range(1, 6):   ## Try: 7
        mining(i)
# pow()
#--------------------------------------------------------

def bits(exp, cof):
    t = cof * (2**(8 * (exp -3)))   ## int
    h = '{:x}'.format(t)            ## int to hex string
    # print(len(h), h)
    
    ## Fill left zero until its length is 64 digits.
    while len(h) < 64:
        h = '0' + h
    print(len(h), h)
# bits(0x19, 0x03a30c)  ## "bits": "1903a30c"
## 64 0000000000000003a30c00000000000000000000000000000000000000000000
#---------------------------------------------------------------

## Alternatively target can be computed from difficulty.
## 'max_target' is a Bitcoin pre-defined value.
max_target = 0x00000000FFFF0000000000000000000000000000000000000000000000000000

## A target can be computed as:
##		target = max_target/difficulty

def difficulty(d):
    target = max_target / d         ## float
    t = str(hex(int(target))[2:])   ## Remove '0x' prefix
    # print(len(t), t)

    ## Fill left zero until its length is 64 digits.
    while len(t) < 64:
        t = '0' + t
    print(len(t), t)
# difficulty(1180923195.25802612)
## 64 0000000000000003a30c00000000000000000000000000000000000000000000
#------------------------------------------------------

def hash_ref():
    d = dict()      ## To store items of <key>: <value>.

    ## Add an item with its key is the hash of value.
    value = 'Hello'
    key = sha256(value)
    d[key] = value

    ## The value can be get by the key.
    # print(d[key])             #  Hello

    ## Try: If the value is modified.
    # d[key] = 'Hello!'

    ## Try: If the key is modified.
    # key = sha256("Hi")

    ## Verify the item is valid.
    v = d.get(key)
    if v != None and key == sha256(v):
        print('Valid')
    else:
        print('Invalid')
# hash_ref()

#----------------------------------------------------------

## Blockchain is a chain of blocks linked by hash references.

## We will use MD5 for smaller hash.
def md5(msg):
    return hashlib.md5(msg.encode()).hexdigest()

''' For simplicity assume that:
A block is a list of the form [<previous_hash>, <data>].
A block key is the hash of data.
A blockchain is implemented as a dict of the form:
            <hash>: [<previous_hash>, <data>]
Initially the blockchain is an empty dict.
'''
bck = { }

## A cursor called last is a reference to the last block.
last = None    

## Add blocks to the blockchian. 
## Suppose a block data is just a name.
def init_bck():    
    global last
    for data in ['John', 'Jack', 'Joe', 'Jame', 'Jim']:
        hash = md5(data)
        bck[hash] = [last, data]
        last = hash
# init_bck()

def print_bck():
    for i in bck:
        print(i, bck[i])
# print_bck()

## To verify the blockchain
def verify_bck():
    if last != md5(bck[last][1]):
        print('Last block error')
        return
    h = last
    while h != None:
        pre_hash = bck[h][0]
        if pre_hash != None and pre_hash != md5(bck[pre_hash][1]):
            print('Broken link')
            return
        h = bck[h][0]
    print('Valid')
# verify_bck()

## Try: modify, 'Jame' -> 'jame'
def mod_bck():
    bck[bck[last][0]][1] = 'jame'
    print_bck()
    verify_bck()
# mod_bck()
