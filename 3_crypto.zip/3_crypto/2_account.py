''' Pybitcoin provides apis to create Bitcoin account. 
pip install pybitcoin     '''
import bitcoin as bc
def keys_suit():
    ## Create a random private key.
    prikey = bc.random_key()
    print('private:', prikey)

    ## Compute public key from the private key.
    pubkey = bc.privkey_to_pubkey(prikey)
    print('public:', pubkey)

    ## Compute address from publice key or private key.
    addr = bc.pubkey_to_address(pubkey)
    # addr = bc.privkey_to_address(prikey)
    print('address:', addr)
# keys_suit()    ## Try: Compare to results with bitaddress.org

#--------------------------------------------------------

''' Encoding:
Keys are very big values that are clumsy an error prone for human.
The purpose of encoding is to make big values to be more manageable.
All encodings can be decoded to the same value.  '''

data = 'Hello'

def encodings():
    print('Binary:')
    ## Converts each byte to sequence of 0 and 1.
    ## Resulting too many digits of 0 and 1, not suitable for human.
    a = [bin(x)[2:] for x in data.encode()]  ## To exclude '0b' prefix
    print(a)          ## ['1001000', '1100101', '1101100', '1101100', '1101111']
    print(''.join(a)) ## 10010001100101110110011011001101111

    print('\nDecimal:')
    ## A byte may be two or three digits of 0-9. 
    ## Without separators, we cannot decode back to original value.
    a = [str(ord(x)) for x in data]
    print(a)            ## ['72', '101', '108', '108', '111']
    print(''.join(a))   ## 72101108108111

    print('\nHexadecimal:')
    ## All bytes are two hex digits of (0-9 and a-f).
    ## Too few the symbols, longer the results.
    a = [hex(ord(x))[2:] for x in data]   ## To exclude '0x' prefix
    print(a)            ## ['48', '65', '6c', '6c', '6f']
    print(''.join(a))   ## 48656c6c6f

    print('\nBase64:')
    ## More symbols (a-z, A-Z, 0-9, =, /), shorter the results.
    ## Commonly used for attachment in emails (not handled by human).  '''
    import base64       ## A standard Python lib.
    b64 = base64.b64encode(data.encode())   ## Input must be bytes.
    print(b64.decode())                     ## SGVsbG8=
    print(base64.b64decode(b64).decode())   ## Hello

    print('\nBase58:')
    ## It is base64 that excludes error prone symbols (0, o, O, I, =, /)
    ## The result are slightly longer than equivalent base64.
    ## pip install base58    '''
    import base58
    b58 = base58.b58encode(data)    ## str -> bytes.
    print(b58.decode())                     ## 9Ajdvzr
    print(base58.b58decode(b58).decode())   ## Hello

    print('\nBase58Check(WIF)')  ## (base58 + Checksum)
    ## Wallets Imported Format(WIF) is suitable to human and allows error-checking.
    ## A lot longer than equivalent base58.
    b58c = base58.b58encode_check(data)
    print(b58c.decode())                         ## vSxRbq6XzDhP
    print(base58.b58decode_check(b58c).decode()) ## Hello
# encodings()

## Python provides functions for string, binary and hex encoding. 
def str_encode():
    s = 'Hello'
    print(type(s), s)   ## <class 'str'> Hello

    ## encode(): str -> bytes (an array of bytes).
    b = s.encode()      ## A 'b' prefix string is a bytes literal.
    print(type(b), b)   ## <class 'bytes'> b'Hello'

    ## decode(): bytes -> str
    t = b.decode()
    print(type(t), t)   ## <class 'str'> Hello
#--------------------------------------------------

    ## hex(): bytes -> hex_str
    h = b.hex()	    
    print(type(h), h)   ## <class 'str'> 48656c6c6f

    ## bytes.fromhex(): hex_str -> bytes
    x = bytes.fromhex(h)
    print(type(x), x)   ## <class 'bytes'> b'Hello'
# str_encode()

################################################################

## Bitcon Private Keys:
## A private key has 256 bits or 32 bytes(64 hex digits).
def bcn():
    print(bc.N)    ## int (represented in decimal). 
    ## 115792089237316195423570985008687907852837564279074904382605163141518161494337

    ## Converse to hex.
    n_hex = hex(bc.N)[2:]    ## exclude prefix '0x'.
    print(len(n_hex), n_hex)
    ## 64 fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
# bcn()   ## A slightly less than 16**64 (or 2**256).

## Generating Bitcoin private keys:
seed = 'This is a seed.'   ## Fixing seed to regenerate the same result.
def gen_prikey():
    ## 1. Random an integer within the range.
    import random
    for _ in range(3):
        print(hex(random.randint(1, bc.N))[2:])
    print()

    ## 2 Hashing bc.sha256(<seed>) returns a 32 bytes integer.
    ## There is a slim chance of overflow, but allows repeatedly generated.
    for _ in range(3):
        print(bc.sha256(seed))
    print()

    ## 3. bc.random_key() returns a random valid private key as hex_str.
    for _ in range(3):
        print(bc.random_key())
# gen_prikey()

def raw_wif_prikey():
    ## Hex private key
    hex_prikey = bc.sha256(seed)
    print(hex_prikey)  ## 64 hex digits str.
 ## 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86
    
    ## Hex private key -> raw(decimal) private key.
    raw_prikey = bc.decode_privkey(hex_prikey, 'hex') ## To decode from 'hex'.
    print(raw_prikey)  ## int
 ## 36863404501039226994932749640652428376780269686920716174806313085065835281030

    ## Raw private key -> WIF private key.
    wif_prikey = bc.encode_privkey(raw_prikey, 'wif')
    print(wif_prikey)   ## Begin with 5.
 ## 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7

    ## All formats represent the same value.
    ## e.g. WIF can be converted to hex. 
    hex_prikey = bc.encode_privkey(wif_prikey, 'hex')
    print(hex_prikey)
# raw_wif_prikey()

## To Compute Compressed Private Key.
def compress_prikey(): 
    ## Uncompressed private key
    hex_prikey = bc.sha256(seed)
    print(len(hex_prikey), hex_prikey)
  ## 64 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    ## The annotated private key for compression is:
    comp_prikey = hex_prikey + '01'
    print(len(comp_prikey), comp_prikey)
  ## 66 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    ## WIFC is the compressed version of the WIF.
    ## hex -> raw -> wif.
    rawc_prikey = bc.decode_privkey(comp_prikey, 'hex')
    wifc_prikey = bc.encode_privkey(rawc_prikey, 'wif')
    print(len(wifc_prikey), wifc_prikey)
  ## 52 Kyx8qCKsSbUrUxQMaQNsq4rxq23FxkfE2haXgNArX9c38qmpkmG5
  ## WIFC private keys begin with K or L.
# compress_prikey()

## 'bitcoinlib' provides apis for handling private keys.
## pip install bitcoinlib
def bclib_prikey():
    from bitcoinlib.keys import Key

    ## Create a random compressed private key.
    k = Key()
    print(k.private_hex)   ## 64 hex digits
    print(k.wif())
    print()

    ## To repeatedly create the same key from a seed. 
    ## The seed must be a 32-byte str.
    seed = bc.sha256('Hello')
    for _ in range(2):
        k = Key(import_key=seed)
        print(k.private_hex)
# bclib_prikey()

def wif_prikey():
    from bitcoinlib.keys import Key

    ## WIF Uncompressed private key
    uck = Key(compressed=False)
    print(len(uck.private_hex), uck.private_hex)
    wif_prikey = uck.wif()
    print(wif_prikey)
    print()

    ## WIF Compressed private key
    ck = Key(compressed=True)
    print(len(ck.private_hex), ck.private_hex)
    wifc_prikey = ck.wif()
    print(wifc_prikey)
# wif_prikey()

#------------------------------------------------------------------

''' Public keys: 
G is a tuple of point(x, y) on Elliptic Curve(EC). '''
# print(bc.G)

## Compute public key using EC generator.''' 
def gen_pubkey():
    ## Hex Private Key 
    hex_prikey = bc.sha256(seed)
    # print(hex_prikey)

    ## Raw Private Key
    raw_prikey = bc.decode_privkey(hex_prikey, 'hex')
    # print(raw_prikey)

    ## Raw public key is a tuple of x and y.
    ## Fast multiply raw private key with G.
    raw_pubkey = bc.fast_multiply(bc.G, raw_prikey)
    print(raw_pubkey)
    print()

    ## Encode into raw hex public key.
    hex_pubkey = bc.encode_pubkey(raw_pubkey, 'hex')
    print(hex_pubkey)       ## 130 hex digits and prefix with '04'

    ## 'pybitcoin' provides convenient apis.
    print(bc.privkey_to_pubkey(hex_prikey))
    print(bc.privtopub(hex_prikey))
# gen_pubkey()

''' An uncompressed public keys contains a tuple(X, Y) 
  both X and Y are 32-bytes.
A compressed public key contains only the X part. '''
def gen_comp_pubkey():
    hex_prikey = bc.sha256(seed)
    print('hex prikey:', hex_prikey)

    hex_pubkey = bc.privkey_to_pubkey(hex_prikey)
    print('hex pubkey:', hex_pubkey)

    ## A raw public key is a tuple of (int, int) 
    raw_pubkey = bc.decode_pubkey(hex_pubkey, 'hex')
    print('raw pubkey:', raw_pubkey)

    ## Unpack the raw public key into X and Y.
    x, y = raw_pubkey
    print('X:', x)
    print('Y:', y)
    
    ## Compressed public key prefix is depend on whether y is even or odd, 
    ##   if y is even prefixed with '02' else '03'.
    if (y % 2) == 0:
        prefix = '02'
    else:
        prefix = '03'

    comp_pubkey = prefix + bc.encode(x, 16)
    print('compressed pubkey:', comp_pubkey)

    ## Using api to compute compressed public key from compressed private key.
    ## '01' is just tell the algorithm to compute compressed version.
    comp_hex_prikey = hex_prikey + '01'
    print('compressed pubkey:', bc.privkey_to_pubkey(comp_hex_prikey))
# gen_comp_pubkey()

#------------------------------------------------------------------------

## Using api to compute Bitcoin address.
def gen_address():
    hex_prikey = bc.sha256(seed)
    print(hex_prikey)
    comp_hex_prikey = hex_prikey+ '01'		
    print(comp_hex_prikey)
      
    ## Uncompressed private key -> address
    print(bc.privkey_to_address(hex_prikey))

    ## Compressed private key -> compressed address
    print(bc.privkey_to_address(comp_hex_prikey))
# gen_address()

## Manually compute address from public key.
def public_to_address():
    hex_prikey = bc.sha256(seed)
    hex_pubkey = bc.privkey_to_pubkey(hex_prikey)
    byt_pubkey = bytes.fromhex(hex_pubkey)

    sha256_hash = hashlib.sha256(byt_pubkey).digest()
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(sha256_hash)
    hash_pubkey = ripemd160.digest()
    prefix = b'\x00'          ## Prefix for mainnet
    extended_key = prefix + hash_pubkey
    checksum = hashlib.sha256(hashlib.sha256(extended_key).digest()).digest()[:4]
    addr = base58.b58encode(extended_key + checksum).decode('utf-8')
    print("address:", addr)
# public_to_address()
#----------------------------------------------------------------

''' 'bitcoinlib' supports wallets.
       https://bitcoinlib.readthedocs.io/en/latest/
pip install bitcoinlib
'''
from bitcoinlib.keys import Key
from pprint import pprint
def create_keys():      ## Create a random key
    k = Key()           ## Try: Key(network='testnet')
    print('Hex Prikey:', k.private_hex)
    print('WIFC Prikey:', k.wif())
    print('Comp Pubkey:', k.public())
    print('Comp Address:', k.address())
    # pprint(k.info())
# create_keys()          ## Check: bitaddress.org

## Working with already exsit private keys.
def import_keys():
    ## Import hex Private key
    k1 = Key('6c16208a64f0aa2f09df5a0380ce939c854578c3ca3d9e9f648f232dadd26040')
    print('Comp Address:', k1.address())

    ## Import wifc private key
    k2 = Key('KzqpKvCDWMeAqCtVkjGX389rwFyXK1dCFtY3n8nF98mcB2DoV2UF')
    print('Comp Address:', k2.address())

    ## Import wif private key (uncompressed)
    k3 = Key('5JdtWD3zfNSe7quuHFZWv3XZA822RvcPVJ7ai3DWwQWbFbmLkvo')
    print('UnComp Address:', k3.address())
# import_keys()

#####################################################################

''' Ethereum Keys:
pip install eth-keys
pip install eth_utils
pip install eth-hash[pycryptodome]
'''
## Create Off Wallet Account(owa)
def gen_owa():
    from eth_keys import keys

    ## Using 32 bytes as seed for repeatedly generated. 
    ## A seed must be fixed 4 bytes.
    secret = '1234'
    seed = (secret*8).encode()

    ## Private Key
    prikey = keys.PrivateKey(seed)
    print(prikey)
 ## 0x3132333431323334313233343132333431323334313233343132333431323334

    ## Public key
    pubkey = prikey.public_key
    print(pubkey)
 ## 0x16df1cff74fd0cb490130945e50e76dd0b3a102c5dcd3357adf5d97d4cc26564239a8fa0865bd9816fe98ac9291563bf76a092f9039e6bd98cdff659595ce205

    ## Address.
    print(pubkey.to_address())
 ## 0xd099286b68f17da0e15b7ba86bad6be3b7dc673a

    ## Ethereum Checksum Address.
    print(pubkey.to_checksum_address())
 ## 0xd099286B68F17Da0E15B7ba86bAD6be3B7Dc673A
# gen_owa()

## Most users need only private key and address to work with wallets.
## Alternatively using 'eth_account'.
## pip install eth_account
def create_account():
    from eth_account import Account
    a = Account.create()        ## randomly create
    print(a.key.hex())          ## private key hex str 
    print(a.address)            ## checksum address
# create_account()

## Geth, Infura, and Ganache provide service for creating owa.
## pip install web3
def create_owa():
    from web3 import Web3
    # URL = 'http://127.0.0.1:8545'   ## Local Geth or Ganache
    URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
    w3 = Web3(Web3.HTTPProvider(URL))

    a = w3.eth.account.create(seed)
    print(a._private_key.hex())
    print(a._address)
# create_owa()

''' Saving private keys directly is unsecured.
At least some kinds of encryption should be deployed.
'eth_account' has Account that supports account encryption. 
pip install eth_account    '''
def encrypt_account():
    from eth_account import Account
    john_acc = Account.create('john')  ## 'john' is not the account password.
    print(john_acc.key.hex())
    print(john_acc.address)

    ## Encrypt an account to a json(dict) which may be pickled. 
    enc_john_acc = john_acc.encrypt('hello')   # 'hello' is the password.

    ## Decrypt an encrypted account to private key
    john_priv = Account.decrypt(enc_john_acc, 'hello')
    print(john_priv.hex())

    ## Retrieve account from private key.
    ja = Account.from_key(john_priv)
    print(ja.address)
# encrypt_account()

#-------------------------------------------------------

## Deterministic Wallet (D Wallet)

import bitcoin as bc
## To generate a private key from an index(id) and password.
## The private key may not be stored because it can be regenerated.
def dw_prikey(_id, pwd):
    return bc.sha256(str(_id) + pwd)
# print(dw_prikey(1, 'hello1'))
# print(dw_prikey(2, 'hello2'))

## An already exist id may be generated with different password.
## An id may have many private keys with different passwords.
# print(dw_prikey(1, 'hello3'))
# print(dw_prikey(1, 'hello1'))
#-------------------------------------------------------------


''' Mnemonic:
Having a password per private key is proofed to be a nightmare.
Having a wallet with a single password still no sleep tight.
Bitcoin sugests 'mnemonic'(BIP32).
pip install mnemonic
'''
def mnm_list():
    from mnemonic import Mnemonic
    ## Languages List:
    # print(Mnemonic.list_languages())

    ## English Words List:
    print(Mnemonic('english').wordlist)
# mnm_list()

def gen_mnm():
    import random
    from mnemonic import Mnemonic

    def gen_entropy():   ## entropy represents a randomness.
        ## An entropy must be a 16, 20, 24, 28, or 32 digits hex string.
        r = ''
        for i in range(random.choice([16, 20, 24, 28, 32])):
            r += '{:x}'.format(random.randint(0, 15))
        return r.encode()   ## bytes

    ent = gen_entropy()
    return Mnemonic('english').to_mnemonic(ent)
# print(gen_mnm())

## Seeds are needed for regenerate some random sequences.
## It is a good practice to created a seed from mnemonic with password.
def gen_seed(mnm, pwd):
    from mnemonic import Mnemonic
    return Mnemonic.to_seed(mnm, passphrase=pwd).hex()

def gen_seed_test():
    my_mnm = gen_mnm()
    print(gen_seed(my_mnm, 'hello123'))
    print(gen_seed(my_mnm, 'hello123'))
# gen_seed_test()
#----------------------------------------------------

## 'eth_account' lib 'Account' allows creating wallet with mnemonic. 
def  account_mnemonic():
    from eth_account import Account

    ## Enable HD wallet
    Account.enable_unaudited_hdwallet_features()

    ## Create an account with its mnemonic.
    acc, mnm = Account.create_with_mnemonic()
    print(acc.address)
    print(mnm)

    ## Then the account can be created from the mnemonic.
    print(Account.from_mnemonic(mnm).address)
# account_mnemonic()

#------------------------------------------------------------------
## Hierarchical Deterministic Wallets (HD Wallet, BIP32)
## pip install bip32utils

## Generate a bip32 root account from a mnemonic and password 
def gen_root(mnm, pwd):
    from bip32utils import BIP32Key
    seed  = gen_seed(mnm, pwd)
    return BIP32Key.fromEntropy(seed.encode())

root = gen_root(gen_mnm(), pwd='hello123')

def root_key_suit():
    print(root.PrivateKey().hex())
    print(root.PublicKey().hex())   ## compressed
    print(root.Address())
# root_key_suit()

def hdw_ex():
    ## Create the first child accounts of the root.
    print(root.CKDpriv(0).Address())
    print()

    ## Create 2 child accounts of of the first child account(index 0).
    c0 = root.CKDpriv(0)
    for i in range(2):
        print(c0.CKDpriv(i).Address())
    print()

    ## Get account by path i,j.
    print(root.CKDpriv(0).CKDpriv(0).Address())
    print(root.CKDpriv(0).CKDpriv(1).Address())
hdw_ex()

## Derive a child key (e.g., m/44'/0'/0'/0/0)
## First child under purpose 44' → coin type 0' (Bitcoin) → account 0'
##   → external chain 0 → first address index 0
def de_key_ex():
    import bip32utils 
    SQ = bip32utils.BIP32_HARDEN
    ckey = root.ChildKey(44 + SQ)
    ckey = ckey.ChildKey(0 + SQ)
    ckey = ckey.ChildKey(0 + SQ)
    ckey = ckey.ChildKey(0)  # External chain
    ckey = ckey.ChildKey(0)  # First address index

    ## Display child key suit:
    print("Child Key Private:", ckey.WalletImportFormat())
    print("Child Key Public:", ckey.ExtendedKey(private=False))
    print("Child Key Address:", ckey.Address())
# de_key_ex()
