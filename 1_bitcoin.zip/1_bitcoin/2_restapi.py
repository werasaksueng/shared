## Using python 3.9.x
# pip install python-bitcoinrpc
from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException

# bitcoin-qt -server
#      http://<user>:<pwd>@<host>:<port>
URL = 'http://rambo:hello123@127.0.0.1:8332'
api = AuthServiceProxy(URL)

print(api.getblockchaininfo())
# print(api.getblockcount())
# print(api.getblockhash(0))  # method with parameters.


