''' 'tatum.io' is a provider that supports access to 60+ blockchains 
(e.g., Bitcoin, Ethereum, Solana, Binance Smart Chain, Polygon).

Register: https://tatum.io
Create a Testnet API key:
'''
API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

import requests, json
from pprint import pprint

def rest(url):
   return requests.get(url, headers=HEADERS).json()

## Get Testnet Blockchain Info
url = 'https://api.tatum.io/v3/bitcoin/info'
# pprint(rest(url))

## Ex. Get block hash by block number. e.g. '0'.
url = "https://api.tatum.io/v3/bitcoin/block/hash/0"
# pprint(rest(url))
## Save the hash of the first block.
hash = '000000000933ea01ad0ee984209779baaec3ced90fa3f408719526f8d77f4943'

## Ex. Get block by hash.
url = "https://api.tatum.io/v3/bitcoin/block/" + hash 
# pprint(rest(url))
## Save the receiver address.
addr = 'mpXwg4jMtRhuSpVq4xS3HFHmCmWp9NyGKt'

## Ex. Get balance of an address.
url = "https://api.tatum.io/v3/bitcoin/address/balance/" + addr
# pprint(rest(url))

