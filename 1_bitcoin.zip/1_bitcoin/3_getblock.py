import requests, json

def json_rpc(method):
    URL = "https://btc.getblock.io/a3ac0ff5-7c75-417e-ac5d-143b256568d2/testnet/"
    DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
    # print(DATA)
    HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    res = requests.post(URL, data=DATA, headers=HEADERS).json()
    print(json.dumps(res, indent=3))

json_rpc('getblockchaininfo')
# json_rpc('getblockcount')
