# Register: https://tatum.io
# Create Testnet API key:
API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

import requests, json
def print_json(res):
   print(json.dumps(res.json(), indent=4, sort_keys=True))

## Restful Api
def get_info():
   URL = 'https://api.tatum.io/v3/bitcoin/info'
   print_json(requests.get(URL, headers=HEADERS))
get_info()

## Get block hash by block number.
def get_block_hash(num):
   URL = "https://api.tatum.io/v3/bitcoin/block/hash/" + num 
   print(requests.get(URL, headers=HEADERS).json())
# get_block_hash('0')   ## The genesis block
hash = '000000000933ea01ad0ee984209779baaec3ced90fa3f408719526f8d77f4943'

## Get block by hash.
def get_block():
   URL = "https://api.tatum.io/v3/bitcoin/block/" + hash 
   print_json(requests.get(URL, headers=HEADERS))
# get_block() 
addr = 'mpXwg4jMtRhuSpVq4xS3HFHmCmWp9NyGKt'

## Get balance of an address. e.g. From block 0.
def get_balance(address):
   URL = "https://api.tatum.io/v3/bitcoin/address/balance/" + address
   print_json(requests.get(URL, headers=HEADERS))
# get_balance(addr)
