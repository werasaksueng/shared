''' Json(JavaScript Object Notation) is the representation
for a list of items in the form of <name>:<value>. 
  Ex.    { "id": 1, "name": "john", "gpa": 4.0 }  
'''

## Incidentally Json syntax is the same as Python dict. 
d = { "id": 1, "name": "john", "gpa": 4.0 }
## type() is a Python built-in function.
# print(type(d))			## <class 'dict'>
# print(d["id"], d["name"], d["gpa"])	## 1 john 4.0

## A Python dict can be converted to a string.
## str() is a Python built-in function.
s = str(d)
# print(type(s))   ## <class 'str'>
# print(s)         ## {'id': 1, 'name': 'john', 'gpa': 4.0}

## 'json' lib allows conversion between string and dict.
import json
s = '{ "id": 1, "name": "john", "gpa": 4.0 }'
## json.loads() converts string to dict.
d = json.loads(s)
# print(type(d))			## <class 'dict'>
# print(d["id"], d["name"], d["gpa"])	## 1 john 4.0

## json.dumps() converts dict to string.
s = json.dumps(d)
# print(type(s))	## <class 'string'>
# print(s)	## {"id": 1, "name": "john", "gpa": 4.0}

## 'pprint' lib allows pretty-print json.
##  Useful for printing large or deeply nested json.
from pprint import pprint
d = json.loads('{"id": 1, "name": "john", "gpa": 4.0, "department": "cs", \
	"enroll": {"math": "2021spr", "java": "2022sum", "oop": "2023fall"} }')
# pprint(d)
# pprint(d, indent=5, width=20)
# pprint(d, sort_dicts=False)   ## True is default.