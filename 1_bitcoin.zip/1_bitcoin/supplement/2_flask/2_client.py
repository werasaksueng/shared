import requests

print(requests.get('http://127.0.0.1:8080/get').text)
print(requests.get('http://127.0.0.1:8080/formget?name=John').text)
print(requests.post('http://127.0.0.1:8080/post',
		data={'name': 'Jack'}).text)
print(requests.post('http://127.0.0.1:8080/put',
		data={'name': 'Joe', '_method': 'PUT'}).text)
print(requests.post('http://127.0.0.1:8080/delete',
		data={'name': 'Jim', '_method': 'DELETE'}).text)