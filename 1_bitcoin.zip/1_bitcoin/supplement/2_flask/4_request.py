from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/req/<path>')
def req(path):
    d = {}
    d['url'] = request.url
    d['scheme'] = request.scheme
    d['host'] = request.host
    d['remote_addr'] = request.remote_addr
    d['method'] = request.method
    d['path'] = request.path
    d['full_path'] = request.full_path
    d['query_string'] = request.query_string.decode()
    d['is_secure'] = str(request.is_secure)
    d['endpoint'] = request.endpoint
    d['path'] = path
    return d
# curl 127.0.0.1:8080/req/john
# curl 127.0.0.1:8080/req/abc?"name=john&id=1"

@app.route('/headers')
def headers():
    return dict(request.headers)
# curl 127.0.0.1:8080/headers
# curl 127.0.0.1:8080/headers -H "Content-type: text/plain"


if __name__ == '__main__':
    app.run(port=8080, debug=True)
