import requests

print(requests.get('http://127.0.0.1:8080/req/john').text)
print(requests.get('http://127.0.0.1:8080/req/abc?name=john&id=1').text)

print(requests.get('http://127.0.0.1:8080/headers', \
                  headers={"Content-type": "text/plain"}).text)
