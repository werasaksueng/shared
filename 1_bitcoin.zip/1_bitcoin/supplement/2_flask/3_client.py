import requests

print(requests.get('http://127.0.0.1:8080/hello').text)
print(requests.get('http://127.0.0.1:8080/add/1/2').text)
print(requests.get('http://127.0.0.1:8080/sub?a=1&b=2').text)
print(requests.get('http://127.0.0.1:8080/mul', \
                  params={'a': 2, 'b': 3}).text)
print(requests.post('http://127.0.0.1:8080/div', \
                  data={'a': 3, 'b': 2}).text)
