# pip install flask

from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
# http://127.0.0.1:8080
# curl 127.0.0.1:8080

@app.route('/hello')
def hello():
    return 'Hello'
# http://127.0.0.1:8080/hello
# curl 127.0.0.1:8080/hello
# curl -verbose 127.0.0.1:8080/hello

@app.route('/hi/jack')
def hi():
    return 'Hi Jack'
# http://127.0.0.1:8080/hi/jack
# curl 127.0.0.1:8080/hi/jack

if __name__ == '__main__':
    app.run(port=8080, debug=True)  # http://127.0.0.1:8080
##    app.run()	   	            # http://127.0.0.1:5000

'''  app.run(host, port, debug)
host: Defaults is 127.0.0.1 (localhost). 
port: Defaults is 5000.
debug: Defaults is False.
'''


