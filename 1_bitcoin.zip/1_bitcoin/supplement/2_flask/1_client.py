import requests

print(requests.get('http://127.0.0.1:8080/hello').text)
print(requests.get('http://127.0.0.1:8080/hi/jack').text)

