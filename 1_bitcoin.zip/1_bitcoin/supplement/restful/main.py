## pip install flask
from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return 'I am index.html.'
## http://127.0.0.1:8080

@app.route('/doHello/<name>')
def do_hello(name):
    return 'Hello %s.' % name
## http://127.0.0.1:8080/doHello/john

@app.route('/doGet')
def do_get():
    return 'Get: %s.' % request.args['name']
## http://127.0.0.1:8080/doGet?name=jack

@app.route('/doPost', methods=['POST'])
def do_post():
    return 'Post: %s.' % request.form['name']

@app.route('/doPut', methods=['PUT'])
def do_put():
    return 'Put: %s.' % request.form['name']

@app.route('/doDelete', methods=['DELETE'])
def do_delete():
    return 'Delete: %s.' % request.form['name']
#--------------------------------------------------

if __name__ == '__main__':
    app.run(port=8080, debug=True)


