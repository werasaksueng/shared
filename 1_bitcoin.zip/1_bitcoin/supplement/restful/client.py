import requests
print(requests.get('http://127.0.0.1:8080').text)
print(requests.get('http://127.0.0.1:8080/doHello/john').text)
print(requests.get('http://127.0.0.1:8080/doGet?name=jack').text)
## curl 127.0.0.1:8080/doGet?name=jack

print(requests.post('http://127.0.0.1:8080/doPost', data={"name": "joe"}).text)
## curl -X POST 127.0.0.1:8080/doPost -d "name=joe"

print(requests.put('http://127.0.0.1:8080/doPut', data={"name": "jame"}).text)
## curl -X PUT 127.0.0.1:8080/doPut -d "name=jame"

print(requests.delete('http://127.0.0.1:8080/doDelete', data={"name": "jim"}).text)
## curl -X DELETE 127.0.0.1:8080/doDelete -d "name=jim"