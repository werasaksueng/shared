/* 
npm list
npm i g web3
npm i g express

node main.js    
*/

var express = require('express')
var app = express()

app.get('/', 
	function(req, res) {
		res.send('Hello')
	}
)
app.get('/hi',
	(req, res) => {
		res.send('Hi')
	}
)

var Web3 = require('web3')
URL = "https://sepolia.infura.io/v3/1c33caf701824d43882200b69d5e0849"
var w3 = new Web3(URL)

app.get('/info', (req, res) => {
		w3.eth.getNodeInfo().then((r) => {
			res.send(r)
		})
	}
)

app.listen(8080)
console.log('Server running at http://127.0.0.1:8080');

// curl 127.0.0.1:8080
// curl 127.0.0.1:8080/hi
// curl 127.0.0.1:8080/info
