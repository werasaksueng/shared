from flask import Flask, render_template, request
app = Flask(__name__)

URL = 'http://john:hello@127.0.0.1:18443'

@app.route('/')
def index():
    return render_template('index.html')

from bitcoinrpc.authproxy import AuthServiceProxy
api = AuthServiceProxy(URL)

@app.route('/info')
def info():
   return api.getblockchaininfo()

@app.route('/wallet', methods=['POST'])
def wallet():
   name = request.form.get('name')
   return api.createwallet(name)

@app.route('/address', methods=['POST'])
def address():
   name = request.form.get('name')
   api = AuthServiceProxy(URL + '/wallet/' + name)
   return api.getnewaddress()

@app.route('/wallet_balance', methods=['POST'])
def wallet_balance():
   name = request.form.get('name')
   api = AuthServiceProxy(URL + '/wallet/' + name)
   return str(api.getbalance())

@app.route('/generate', methods=['POST'])
def generate():
   name = request.form.get('name')
   api = AuthServiceProxy(URL + '/wallet/' + name)
   nblocks = int(request.form.get('nblocks'))
   addr = request.form.get('addr')
   return api.generatetoaddress(nblocks, addr)

@app.route('/send', methods=['POST'])
def send():
   name = request.form.get('name')
   api = AuthServiceProxy(URL + '/wallet/' + name)
   amount = int(request.form.get('amount'))
   addr = request.form.get('addr')
   api.settxfee(0.0001)
   return api.sendtoaddress(addr, amount)

if __name__ == '__main__':
    app.run(port=8080, debug=True)