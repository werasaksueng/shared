## 'python-bitcoinrpc' allows calling to bitcoind with APIs.
## pip install python-bitcoinrpc  Check: python 3.9+ and dependency conflicts 

from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException
from pprint import pprint

## Call to local bitcoind, no wallet services.
## start_bitcoind.bat
URL = 'http://john:hello@127.0.0.1:18443'
def localbd():
    try:
        api = AuthServiceProxy(URL)
        pprint(api.getblockchaininfo())
        print(api.getblockcount())
    except JSONRPCException as e:
        print(e)
# localbd()

## Call to bitcoin-qt, to display wallet info.
## start_bitcoin-qt.bat and create 'mywallet' directory.

def create_wallets():
    ## - wallet_name (string)
    ## - disable_private_keys (bool, optional, default is False.): If True, 
    ##    the wallet will not generate private keys, making it a watch-only wallet. 
    ## - passphrase (string, optional): A passphrase for encrypting the wallet.
    ## - avoid_reuse (bool, optional, default is False.): If True,
    ##    mark reused addresses as "dirty" to prevent reusing them.
    api = AuthServiceProxy(URL)
    print(api.createwallet('john'))
    print(api.createwallet('jack'))
# create_wallets()

def create_addresses():
    ## Create a connection to john wallet.
    john_api = AuthServiceProxy(URL + '/wallet/john')
    ## Create an address in john wallet.
    john_addr = john_api.getnewaddress()

    jack_api = AuthServiceProxy(URL + '/wallet/jack')
    jack_addr = jack_api.getnewaddress()
    return john_addr, jack_addr

# john_addr, jack_addr = create_addresses()
# print(john_addr)
# print(jack_addr)
john_addr = 'bcrt1qcq6a3tuq907yfx7k3pntv7qrwvq5tg88uwdhtf'
jack_addr = 'bcrt1qus0vms6du5ztm2a9m82wuhmp0cde6n4jrq5k0x'

## To generate new blocks and send their coinbase reward to a specific address. 
## Allowed only in regtest or testnet, does not work on the mainnet.
## The default block reward for regtest is 50 BTC.
def generate_blocks(wallet_api, nblocks, addr):
    gen_blocks = wallet_api.generatetoaddress(nblocks, addr)

    ## To list the generated block hashs.
    # for bhash in gen_blocks:
    #    print(bhash)

## Generate 101 blocks to john address.
john_api = AuthServiceProxy(URL + '/wallet/john')
# generate_blocks(john_api, 101, john_addr)  

## To get wallet's total balance.
def wallet_balance(wallet_api):
    print(wallet_api.getbalance())
# wallet_balance(john_api)

## Send To Address.
## - address (string): The Bitcoin address to send to.
## - amount (numeric): The amount of BTC to send (in BTC, not satoshis).
## - comment (string, optional): A comment to add about the transaction.
## - comment_to (string, optional): A comment to add about who the transaction is sent to.
## - subtractfeefromamount (bool, optional): If true, the fee will be subtracted from the amount instead of being added on top.
## - conf_target (integer, optional): Defines how quick the transaction should be confirmed (in blocks)
##	    n: Aiming for confirmation within n blocks.
##	Lower values may result in higher fees,
## - estimate_mode (string, optional): The fee estimation mode. Options:
## 	UNSET: Default mode.
## 	ECONOMICAL: Lower fees, slower confirmation.
## 	CONSERVATIVE: Higher fees, faster confirmation.
def send(wapi, amount, raddr):
    ## To avoid fee estimation, set a small amount of fixed free.
    wapi.settxfee(0.0001)       ## Set a manual fee
    txid = wapi.sendtoaddress(raddr, amount,
        "Payment for my services",  ## Comment for payment
        "Jack Ripper",              ## Comment for recipient
        False)   ## Do not subtract fee from the amount
    print(txid)
## John sends 1 BTC to Jack.
# send(john_api, 1, jack_addr)
txid = 'ba0fceb89140e768985b9e37d2fb132c07c1a6c87cf0d9eba27405de3cd20b8e'

jack_api = AuthServiceProxy(URL + '/wallet/jack')

## To check that the txfee had been set.
# jack_api.settxfee(0.0001)
# print(jack_api.getwalletinfo()['paytxfee'])

## To check if the sending was success:
## - Check the transaction jack receives.
## - Check the transaction -> amount.
jack_api = AuthServiceProxy(URL + '/wallet/jack')
# pprint(jack_api.gettransaction(txid))

## At this point the tx is not confirmed yet.
# wallet_balance(jack_api)

## To force confirmation by generating a new block.
# generate_blocks(john_api, 1, john_addr)

## Now you can check jack balance again.
wallet_balance(jack_api)