import requests

# bitcoin-qt -server
USER = "rambo"
PWD = "hello123"
def jsonrpc(method):
    URL = "http://%s:%s@127.0.0.1:8332" % (USER, PWD)
    DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
    HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    # print(DATA)
    return requests.post(URL, data=DATA, headers=HEADERS).text

res = jsonrpc('getblockchaininfo')
print(res)			# str

import json
def json_test():
   js = json.loads(res)   	# str -> json
   # print(js['result'])
   print(js['result']['chain'])
   print(js['result']['blocks'])
# json_test()

