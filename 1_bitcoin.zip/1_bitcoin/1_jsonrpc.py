''' Start bitcoind with http server and user/password.
start_bitcoind.bat      
bitcoin-cli -regtest -rpcuser=john -rpcpassword=hello getblockcount

## The port 18443 is primary use for Json-rpc over HTTP for 'regtest'.
## Default(main): 8332, testnet: 18332
## URL = "http://{USER}:{PWD}@{HOST}:{PORT}"
'''
##############################################################

## pip install requests
import requests
from pprint import pprint
def json_rpc(url, method='getblockchaininfo'):
   ## Accept only methods with no parameters.
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   HEADERS = {"Content-type": "application/json", "Accept": "text/plain"}
   return requests.post(url, data=DATA, headers=HEADERS).json()

url = 'http://john:hello@127.0.0.1:18443' 
# pprint(json_rpc(url))  ## Try: method='getblockcount'

#------------------------------------------------

''' Using Blockchain Gateways:
Ex. 'getblock.io' is a gateway that support both JSON RPC and Web Api.
   https://getblock.io/
	Get a free endpont: email (Authen with Google). 
		Protocol: Bitcoin
		Network: Testnet
		API interrface: Json-rpc
'''
url = "https://go.getblock.io/baddeb10abff4800b37b0919908e7745"
# pprint(json_rpc(url))



