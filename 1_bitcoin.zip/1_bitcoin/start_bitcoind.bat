cd C:\mycrypto\etc\Bitcoin\daemon
bitcoind -regtest -server -rpcuser=john -rpcpassword=hello
