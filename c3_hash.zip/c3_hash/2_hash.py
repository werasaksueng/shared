''' 'hashlib' is a standard Python lib for hashing.
There are many popular hashing alogorithms.  '''
import hashlib
# print(hashlib.algorithms_available)

def hash_ex():
    msg = 'Hello'	            ## str
    msg_en = msg.encode()	    ## bytes

    ## Md5:  32 chars (16 bytes) 
    s = hashlib.md5(msg_en).hexdigest()
    print(len(s), '\t', s)

    ## Sha1:  40 chars (20 bytes) 
    s = hashlib.sha1(msg_en).hexdigest()
    print(len(s), '\t', s)

    ## Sha256:  64 chars (32 bytes, 256 bits)
    s = hashlib.sha256(msg_en).hexdigest()
    print(len(s), '\t', s)

    ## Double Sha256:  Sha256 twice (32 bytes, 256 bits).
    s = hashlib.sha256(hashlib.sha256(msg_en).digest()).hexdigest()
    print(len(s), '\t', s)

    ## RIPEMD160(SHA256(data)) = HASH160 (20 bytes)
    t = hashlib.sha256(msg_en).digest()
    s = hashlib.new("ripemd160", t).hexdigest()
    print(len(s), '\t', s)
# hash_ex()

def sha256(msg: str):
    return hashlib.sha256(msg.encode()).hexdigest()

## Always produces the same output if inputs are the same.
def consistency():
    print(sha256('Hello'))
    print(sha256('Hell' + 'o'))
    print(sha256('hello'.capitalize()))
# consistency()

## A little bit different inputs result unpredictable output.
def diff_input():
   print(sha256('Hello! how are you today?'))
   print(sha256('Hello! how are you today.'))
# diff_input()

## Certain pattern output can be expected, if try hard enough.
## Ex. Find a msg that results output of four-zeros prefixed.
import random
def pattern():
    n = 0    ## The number of tries.
    while True:
        r = str(random.random()) ## A string of random float.
        h = sha256(r)
        if h.startswith('0000'):
            print(n, r, h)
            break
        n += 1
# pattern()
#--------------------------------------------------------------------

## Sha256 results very big hash, for simplicity we will use Md5.
def md5(msg):
    return hashlib.md5(msg.encode()).hexdigest()

''' Tamper Proof is a process to verify if a message had been modified.
Ex. The file 'hello.txt' is hashed, the result is saved in 'msg_hash'.
To verify if 'hello.txt' had been modified, it is read and hashed
  then compares the result with that had been stored in 'msg_hash'. '''
def hash_file(infile, outfile):
    data = open(infile, 'r').read()
    open(outfile, 'w').write(md5(data))
# hash_file('hello.txt', 'msg_hash')

def tamper_proof(infile, hashfile):
    data = open(infile, 'r').read()
    hash = open(hashfile, 'r').read()
    if hash == md5(data):
        print('Valid')
    else:
        print('Invalid')
# tamper_proof('hello.txt', 'msg_hash')
## Try: Modify hello.txt and check tamper_proof() again.
#---------------------------------------------------------

''' Merkle Root is a process to tamper proof a set of messages. 
All messages are hashed in to one output.
This technique had been used long before Bitcoin. '''
def merkle(p):
    def swipe(a):
        r = []
        while len(a) > 0:
            r.append(md5(a.pop() + a.pop()))
        return r
    x = swipe(p) 
    while len(x) > 1:
        x = swipe(x)
    return x[0] 
''' The parameter 'p' must have length to the power of two. 
If not, it must be padded with any strings. 

Since two adjacent strings are concatenated before hashed,
  the order must stay the same. '''
msgs = ['john', 'jack', 'joe', 'jim']
# print(merkle(msgs))
## Try: Modify any item in 'msgs'.
#------------------------------------------------------------

''' Hash Reference:
We will illustratate hash reference by using a Python dict. '''

## Set an item to the dict such that its key is the hash of the value.
def set(dic, value): 
    key = md5(value)
    dic[key] = value
    return key    

## Get value of the key, it must verified that the key is valid. '''
def get(dic, key):
    value = dic.get(key)    ## If no key the value is None.
    if value != None and key == md5(value):
        return value
    else:
        return None  ## It had been modified.

def hash_ref():
    ## Create a dict to store items of the form <key>:<value>.
    d = dict()
    k = set(d, 'Hello')

    ## Try: If the value is modified.
    # d[k] = 'hello'

    ## Try: If the key is invalid.
    # k = md5('hi')

    ## The value can be get by the key.
    print(get(d, k))
# hash_ref()
#-------------------------------------------------------

''' A Blockchain is a chain of blocks linked by hash references.
A poor man Blockchain: Assume that:
A block is a list of the form [<previous_hash>, <data>].
The content of block is hashed to be the block hash.
A blockchain is implemented as a dict of items of the form:
         	    <hash>:<block> 
   where <block> is of the form:
            <hash>: [<previous_hash>, <data>]
For simplicity, suppose a block data is just a name.
'''
def init(names):
    bc = { }	## Initially the blockchain is an empty dict.
    last = None ## A reference to the last block.
    ## Add blocks to the blockchian. 
    for data in names:
        hash = md5(data)
        bc[hash] = [last, data]
        last = hash
    return bc, last
bc, last = init(['John', 'Jack', 'Joe', 'Jame', 'Jim'])

## Print the blockchain.
def print_(bc):
    for i in bc:
        print(i, bc[i])
# print_(bc)

## Verify the blockchain
def verify(bc, last):
    if last != md5(bc[last][1]):
        print('Last block error')
        return

    ## Traversal the Blockchain.
    h = last		## Starting with the 'last'.
    while h != None:	## Until reaching the genesis block.
        pre_hash = bc[h][0]
        if pre_hash != None and pre_hash != md5(bc[pre_hash][1]):
            print('Broken link')
            return
        h = bc[h][0]
    print('Valid')
# verify(bc, last)

## Try: modify, 'Jame' -> 'jame'
def tamper(bc, last):
    bc[bc[last][0]][1] = 'jame'
# tamper(bc, last)
## Try: Then print_(bc) and verify(bc, last) again
# print_(bc)
# verify(bc, last)
#----------------------------------------------------------------

''' 'Mining' is the racing process of finding a winning block.
A 'winning block' is a block that its hash has the number of 
  preceding zeros more than the value that defined by a 'target'. '''
def mining(diff):
    ## For simplicity, suppose a block is just a string.
    block = 'Hello how do you do?'

    ## A 'target' is a string that contains the 'diff' number of zeros.
    ##  e.g. if 'diff' is 4, the 'target' is '0000'.
    target = '0'*diff
    print('\nTarget:', target)

    ''' Every blocks has an integer, 'nonce' to be included in hashing.
      'mining' is a searching for a 'nonce', that makes the block hash
       has prefix of zeros as defined by the 'target'. '''
    nonce = 0
    while True:
        ## 'nonce' is appended to a block before hashing.
        h = sha256(block + str(nonce))
        if h.startswith(target):
            print('noune: %d\t hash: %s' % (nonce, h))
            break
        nonce += 1

## Larager the 'diff', the longer and harder searching.
def pow():
    for i in range(1, 6):   ## Try: 7
        mining(i)
# pow()
############################################################

''' Computing 'target':
'target' is a hex 64 digits value, defines how many preceding 
   zeros a winning 'nonce' must have.
All Bitcoin blocks contain 'target' expressed in the form of
		'bits' and 'diff'.
Both can be used to compute the same 'target' value.
Ex. Get a block from Bitcoin Blockchain (by block number).
	bitcoin-cli getblockhash 277316
Save the block id (hash).

Then get the block info by its hash.
	bitcoin-cli getblock <block id>
There will be 'bits' and 'diff' in the header:
     "bits"       : "1903a30c"           
     "difficulty" : 1180923195.25802612
'bits' is expressed as a hex value of the form: 'EECCCCCC'.
  where EE is exponent and CCCCCC is coefficient.
Ex. 'bits': '1903a30c' ->  expo = '0x19', cof = '0x03a30c'
'''	
def bits(expo, cof):
    t = cof * (2**(8 * (expo -3)))  ## Converse to an int.
    h = '{:x}'.format(t)            ## Converse int to hex string.
    # print(len(h), h)
    
    ## Fill left zero until its length is a hex 64 digits.
    while len(h) < 64:
        h = '0' + h
    print(len(h), h)
# bits(0x19, 0x03a30c)  
## 64 0000000000000003a30c00000000000000000000000000000000000000000000

## Alternatively: 'target' can be computed from 'diff'.
## A 'diff' is a float. ex. 1180923195.25802612
## 'max_target' is a Bitcoin pre-defined value.
max_target = 0x00000000FFFF0000000000000000000000000000000000000000000000000000

## A 'target' can be computed as:
##		target = max_target/diff
def diff(d):
    target = max_target / d         ## float
    ## Converse float to hex string and remove '0x' prefix.
    t = str(hex(int(target))[2:])  
    # print(len(t), t)

    ## Fill left zero until its length is 64 digits.
    while len(t) < 64:
        t = '0' + t
    print(len(t), t)
# diff(1180923195.25802612)
## 64 0000000000000003a30c00000000000000000000000000000000000000000000
