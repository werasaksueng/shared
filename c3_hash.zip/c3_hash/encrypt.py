'''
pip install pycryptodome
pip install eth_utils

'Caesar Method' encrypts a message(string) with key(int).  '''
import string
_chars = string.printable  ## Distinguish characters are favorable.
_clen = len(_chars)
# print(_chars, _clen)

def caesar():
    def encode(msg, key):
        def enc(c, key):
            ec = (_chars.find(c) + key) % _clen
            return _chars[ec]
        emsg = ''
        for i in msg:
            emsg += enc(i, key)
        return emsg

    def decode(emsg, key):
        def dec(c, key):
            dc = _chars.find(c) - key
            if dc >= _clen:
                dc -= _clen
            elif dc < 0:
                dc += _clen
            return _chars[dc]
        dmsg = ''
        for i in emsg:
            dmsg += dec(i, key)
        return dmsg

    msg = 'Hello how to you do?'
    key = 123
    em = encode(msg, key)
    print(em)
    print(decode(em, key))
caesar()
#------------------------------------------------------

 # Transposition encrypts a message(str) with a key(int).
def transposition():
    def encode(msg, key):
        slot = [''] * key
        for col in range(key):
            cur = col
            while cur < len(msg):
                slot[col] += msg[cur]
                cur += key
        return ''.join(slot)

    def decode(emsg, key):
        import math
        ncol = math.ceil(len(emsg) / key)
        nrow = key
        nboxes = (ncol * nrow) - len(emsg)
        dmsg = ['']*ncol
        col, row = 0, 0
        for i in emsg:
            dmsg[col] += i
            col += 1
            if (col == ncol) or (col == ncol-1 and row >= nrow-nboxes):
                col = 0
                row += 1
        return ''.join(dmsg)

    msg = "Hello it's nice to see you."
    key = 5
    emsg = encode(msg, key)
    print(emsg)
    print(decode(emsg, key))
# transposition()
#------------------------------------------------------

# XOR encrypts a message(str) with password(str), result is an int.
def xor():
    def encode(msg, pwd):
        key = int.from_bytes(pwd.encode(), 'big')
        text_int = int.from_bytes(msg.encode(), 'big')
        return key ^ text_int      ## Returns an int

    def decode(enc, pwd):
        key = int.from_bytes(pwd.encode(), 'big')
        text_int = key ^ enc
        length = text_int.bit_length()
        text = text_int.to_bytes((length+ 7) // 8, 'big')
        return text.decode()        ## Returns a string

    msg = 'Hello! long time no see.'
    pwd = 'hello123'
    enc = encode(msg, pwd)
    print(enc, type(enc))
    print(decode(enc, pwd))
# xor()
#--------------------------------------------------------

## Mapping creates a mapping pair for encryption and decryption.
import random
def mapping():
    def gen_map():
        sym = list(string.printable)
        random.shuffle(sym)
        target = ''.join(sym)
        return str.maketrans(string.printable, target), \
               str.maketrans(target, string.printable)

    encrypt_map, decrypt_map = gen_map()
    # print(encrypt_map)  ## For encoder.
    # print(decrypt_map)  ## For decoder.
## Exposing any of the maps would be disastrous.

    msg = 'Hello! how are you?'
    emsg = msg.translate(encrypt_map)
    print(emsg)
    print(emsg.translate(decrypt_map))
# mapping()
#-----------------------------------------------------

def read_file(name):
    with open(name, 'r') as f:
        return f.read()

def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)

''' AES encryption
A key is 16 bytes (hex str) generated from a message.
An encoded message contains initialized vector(iv)
 and ciphertext(ct) represented as json with base64 values.
Resulting 'key' and 'emsg' files.
'''
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
from eth_utils import encode_hex, decode_hex
import json
def aes():
    def encode(msg):
        data = msg.encode()
        key = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC)
        ct_bytes = cipher.encrypt(pad(data, AES.block_size))
        iv = b64encode(cipher.iv).decode('utf-8')
        ct = b64encode(ct_bytes).decode('utf-8')
        write_file('key', encode_hex(key))
        write_file('emsg', json.dumps({'iv':iv, 'ct':ct}))
    encode("Hello how do you do?")

    def decode():
        try:
            key = decode_hex(read_file('key'))
            enc = json.loads(read_file('emsg'))
            iv = b64decode(enc['iv'])
            ct = b64decode(enc['ct'])
            cipher = AES.new(key, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ct), AES.block_size).decode()
        except (ValueError, KeyError):
            print("Error")
    print(decode())
# aes()
