''' There are a lot of python libs that support hashing.
pip install pybitcoin
pip install pycryptodome 
pip install bcrypt
pip install eth-utils

Ex. 'pybitcoin' is a lightweight lib.
'''
msg = 'Hello'	            ## str
msg_en = msg.encode()	    ## bytes

import bitcoin as pybc
def pybc_ex():
    print(pybc.bin_sha256(msg_en).hex())
    print(pybc.bin_dbl_sha256(msg_en).hex())
    print(pybc.bin_hash160(msg_en).hex())
# pybc_ex()

## 'pycryptodome' is an encryption lib but also supports hashing.
from Crypto.Hash import SHA256, RIPEMD160
# print(SHA256.new(msg_en).hexdigest())
# print(RIPEMD160.new(msg_en).hexdigest())

''' 'bcrypt' is a python lib designed for password hashing (slow, secure).
It returns a 120 hex digits hash.
'salt' provides randomness, to prevent repeat generation.  '''
import bcrypt
# print(bcrypt.hashpw(msg_en, bcrypt.gensalt()).hex())

''' Ethereum uses 'keccak' hashing.
'eth-utils' supports hashing, encode/decode, conversion, key manipulations. '''
from eth_utils import keccak
# print(keccak(msg_en).hex())
