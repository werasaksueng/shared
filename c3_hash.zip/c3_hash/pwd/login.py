''' Password Hashing:
Passwords should never be directly saved or even encrypted.
A more practical solution is saving hash of passwords. '''

import redis
r = redis.Redis()

import hashlib
def md5(msg):
    return hashlib.md5(msg.encode()).hexdigest()

def register(name, pwd):
    r.set(name, md5(name+pwd))

register('john', 'hello')
print(r.get('john'))

def login(name, pwd):
    if r.get(name).decode() == md5(name+pwd):
        return 'Valid'
    return 'Invalid'

print(login('john', 'hello'))
