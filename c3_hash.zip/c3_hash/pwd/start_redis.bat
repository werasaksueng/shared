set PATH=C:\mycrypto\etc\Redis
cd C:\mycrypto\c3_hash\pwd
redis-server