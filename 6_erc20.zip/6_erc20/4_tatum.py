import requests, json
def print_json(res):
   print(json.dumps(res.json(), indent=4, sort_keys=True))

API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
CHAIN = 'ethereum-sepolia'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

## Get balances of addresses from Metamask.
account1 = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
account1_priv = 'ebac496b7df4d594c138b0a992cd9094b25ae27315f07e26d0b520976a9db423'
me = '0x5E98B03695d98eD2A6563cCE88693b494aA2df64'
me_priv = '9314f247e30e19473f4f43fe2eac137cd057a5bde1de4e9a97bdf94735b9baa9'
john = '0x3a58827fAEAc056143A78B39BC850364ABB1e759'
def get_balance(addr):
   URL = "https://api.tatum.io/v3/ethereum/account/balance/" + addr
   print_json(requests.get(URL, headers=HEADERS))
# get_balance(account1)
# get_balance(me)

## Deploy an erc20 token to 'account1' address.
def deploy():
   URL = 'https://api.tatum.io/v3/blockchain/token/deploy'
   DATA = {
         "chain": "ETH",
         "symbol": "E20",
         "name": "Erc20Token",
         "supply": "1000",
         "digits": 2,
         "address": account1,    ## The address to receive the token.
         "fromPrivateKey": account1_priv
      }
   print_json(requests.post(URL, json=DATA, headers=HEADERS))
# deploy()

## Get tokens owned by adderss, results 'amount' and 'contractAddress'.
def get_tokens(addr):
   URL = "https://api.tatum.io/v3/blockchain/token/address/ETH/" + addr
   print_json(requests.get(URL, headers=HEADERS))
# get_tokens(account1)
# contractAddress = "0x387c39347d1230efc45698c7c42f8353f22aa837"
contractAddress = "0x49cd983a4c35bc7d0bc43fdb1f0b877bd7f3a2e8"
## Try: Import the token to Metamask.

def get_token(caddr, addr):
   URL = "https://api.tatum.io/v3/blockchain/token/balance/ETH/" + caddr + "/" + addr
   return requests.get(URL, headers=HEADERS).json()['balance']
# print(get_token(contractAddress, account1))

def list_balances(caddr):
   print('accout1:', get_token(caddr, account1))
   print('me:', get_token(caddr, me))
   print('john:', get_token(caddr, john))
# list_balances(contractAddress)

## Transfer token.
def transfer(caddr, from_priv, to_addr, amount):
   URL = "https://api.tatum.io/v3/blockchain/token/transaction"
   DATA = {
      "chain": "ETH",
      "to": to_addr,
      "contractAddress": caddr,
      "amount": str(amount),
      "digits": 2,
      "fromPrivateKey": from_priv
   }
   print_json(requests.post(URL, headers=HEADERS, json=DATA))
# transfer(contractAddress, account1_priv, me, 10)
# transfer(contractAddress, me_priv, john, 1)
list_balances(contractAddress)

def burn(caddr, from_priv, amount):
   URL = "https://api.tatum.io/v3/blockchain/token/burn"
   DATA = {
      "chain": "ETH",
      "amount": str(amount),
      "contractAddress": caddr,
      "fromPrivateKey": from_priv
   }
   print_json(requests.post(URL, headers=HEADERS, json=DATA))
# burn(contractAddress, account1_priv, 100)

def mint(caddr, from_priv, to_addr, amount):
   URL = "https://api.tatum.io/v3/blockchain/token/mint"
   DATA = {
      "chain": "ETH",
      "amount": str(amount),
      "to": to_addr,
      "contractAddress": caddr,
      "fromPrivateKey": from_priv
   }
   print_json(requests.post(URL, headers=HEADERS, json=DATA))
# mint(contractAddress, account1_priv, john, 10)