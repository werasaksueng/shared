from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

## Start Ganache that Erc20_Z was already deployed.
from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

## Copy from 2_web3.py.
c_addr = '0x60b0d20d62F3816ce83e17379811B2Ea5bB122bb'

## Copy from \contracts\Erc20_Z.abi to ...static\abi\Erc20_Z.abi.
def read_file(name):
    with open(name, 'r') as f:
        return f.read()
abi = read_file('static/abi/Erc20_Z.abi')

## Get contract
con = w3.eth.contract(address=c_addr, abi=abi)

@app.route('/contest')
def con_test():
    return str([f.fn_name for f in con.all_functions()])

import json
@app.route('/mint')
def mint():
    me = w3.eth.accounts[0]
    tx_hash = to_hex(con.functions.mint(me, 1_000_000).transact({'from': me}))
    d = {"result": True, "tx_hash": tx_hash}
    return json.dumps(d)

@app.route('/balances')
def balances():
    me = w3.eth.accounts[0]
    john = w3.eth.accounts[1]
    jack = w3.eth.accounts[2]
    d = {'me': { 'address': me,
            'eth': w3.eth.get_balance(me),
            'token': con.functions.balanceOf(me).call()},
        'john': { 'address': john,
            'eth': w3.eth.get_balance(john),
            'token': con.functions.balanceOf(john).call()},
	    'jack': { 'address': jack,
            'eth': w3.eth.get_balance(jack),
            'token': con.functions.balanceOf(jack).call()}
    }
    return json.dumps(d)

@app.route('/addrbalance', methods=['POST'])
def addr_balance():
    addr = request.form.get('_addr')
    eth = w3.eth.get_balance(addr)
    token = con.functions.balanceOf(addr).call()
    if addr == None:
        return '{"result": None}'
    return json.dumps({"result": True, "eth": eth, "token": token})

@app.route('/transfer', methods=['POST'])
def transfer():
    _from = request.form.get('_from')
    _to = request.form.get('_to')
    _value = request.form.get('_value')
    if _from == None or _to == None or _value == None:
        return '{"result": False, "msg": "Invalid parameter"}'
    tx_hash = con.functions.transfer(_to, int(_value)).transact({'from': _from}).hex()
    return json.dumps({"result": True, "tx_hash": tx_hash})

if __name__ == '__main__':
    app.run(port=8080, debug=True)
