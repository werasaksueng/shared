from web3 import Web3

## Start Ganache
URL = "http://127.0.0.1:8545"
w3 = Web3(Web3.HTTPProvider(URL))

me = w3.eth.accounts[0]
john = w3.eth.accounts[1]
jack = w3.eth.accounts[2]
def eth_balances():
    print('me:', w3.eth.getBalance(me))
    print('john:', w3.eth.getBalance(john))
    print('jack:', w3.eth.getBalance(jack))
# eth_balances()

## Connect Remix to Ganache.
# ENVIRONMENT: Custom - External Http Provider

## Load and Compile Erc20_Z.sol.
## Copy Erc20_Z abi to \contracts\Erc20_Z.abi.

## Deploy ERc20_Z from 'me' at address:
c_addr = '0x60b0d20d62F3816ce83e17379811B2Ea5bB122bb'

# Remix is used for compile and deploy, from now on we use Ganache.
## Read abi file.
def read_file(name):
    with open(name, 'r') as f:
        return f.read()
abi = read_file('contracts\Erc20_Z.abi')
# print(abi)

## Get the contract from Ganache.
con = w3.eth.contract(address=c_addr, abi=abi)
def test_con():
    for f in con.all_functions():
        print(f.fn_name)
# test_con()

def info():
    print(con.functions.name().call())
    print(con.functions.symbol().call())
    print(con.functions.totalSupply().call())
# info()

## 'me' is the owner.
def balances():
    print(con.functions.balanceOf(me).call())
    print(con.functions.balanceOf(john).call())
    print(con.functions.balanceOf(jack).call())
# balances()

## Mint:
# print(con.functions.mint(me, 1_000_000).transact({'from': me}).hex())
# balances()

## Transfer from 'me' to 'john'.
# print(con.functions.transfer(john, 100).transact({'from': me}).hex())
# balances()

## Transfer from 'john' to 'jack'.
# print(con.functions.transfer(jack, 10).transact({'from': john}).hex())
# balances()

#-----------------------------------------------

## transferForm: is used in Token Distributor environment.
# Supppse me is the token owner.
#           john is a distributor of me's tokens.
# Without allowance john cannot transfer me's tokens to anyone.
# print(con.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
	# error: insufficient allowance

## me must approve john to transfer some amount of tokens.
# print(con.functions.approve(john, 50).transact({'from': me}).hex())

## Check the amount that me allows john to transfer.
# print(con.functions.allowance(me, john).call())

## Now john can transfer me's tokens to jack.
## John must own enough tokens and 
##  the transferred tokens must not excess the allowance.
# print(con.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
# balances()

