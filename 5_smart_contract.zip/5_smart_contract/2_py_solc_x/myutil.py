from web3 import Web3
URL = 'http://127.0.0.1:8545'
# URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3 = Web3(Web3.HTTPProvider(URL))

#------------------------------------------------------

def read_file(name):
    with open(name, 'r') as f:
        return f.read()

def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)

#-------------------------------------------------------

import json
def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str 
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))
#---------------------------------------------------------

def get_info(addr):
    cid = w3.eth.chain_id
    nonce = w3.eth.get_transaction_count(addr)
    block = w3.eth.get_block("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, currGas
