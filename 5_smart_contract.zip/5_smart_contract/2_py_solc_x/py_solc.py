## pip install py-solc-x
# https://solcx.readthedocs.io/en/latest/
# Support Solidity versions >=0.4.11

from myutil import *

## Install
from solcx import install_solc
# print(install_solc(version='latest'))
# print(install_solc(version='0.4.17'))
## Check C:\Users\<User>\.solcx

from solcx import compile_source
def compile(file):
    code = read_file('contracts/' + file + '.sol')
    compiled = compile_source(code,
          output_values=['abi', 'bin'],
          solc_version='0.8.14')
    # print_json(compiled)
    res = compiled['<stdin>:'+file]
    abi = res['abi']
    bin = res['bin']
    write_file('contracts/' + file + '.abi', w3.toJSON(abi))
    write_file('contracts/' + file + '.bin', bin)
    # print(abi); print(bin)
    print('Success')
# compile('Storage')

''' A complied smart contract is tested by creating an object
  (does not deployed) from the .abi and .bin files. '''
def test_contract(fn):
    abi = read_file('contracts/' + fn + '.abi')
    bin = read_file('contracts/' + fn + '.bin')

# Create contract object
    c = w3.eth.contract(abi=abi, bytecode=bin)

# List all functions in the contract.
    for f in c.all_functions():
        print(f.fn_name)
# test_contract('Storage')

#----------------------------------------------------------

## Start Ganache.
john_addr = '0xbc583d213B96e2E54a7524165cA844b1c6502311'
john_priv = '647ade95383c40c9bfa876708db689626effb8b3dfe588f2461640e4bac396fa'

## Test get_info() in 'myutil'.
# print(get_info(john_addr))

## Read abi and bin.
abi = read_file('contracts/Storage.abi')
bin = read_file('contracts/Storage.bin')
# print('abi:', abi)
# print('bin:', bin)

## Deploy raw contract creation tx.
def deploy(file):
## Create tx from contract object, need abi and bin.
    con = w3.eth.contract(abi=abi, bytecode=bin)
    cid, nonce, currGas = get_info(john_addr)
    tx = con.constructor().build_transaction({
        'nonce': nonce, 'chainId': cid,
        'gas': "0x21000", 'gasPrice': currGas
    })
    # print(tx)

## Sign and send tx.
    signed_tx = w3.eth.account.sign_transaction(tx, john_priv)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    print(tx_hash.hex())
# deploy('Storage')
tx_hash = '0xc3824827c112030d7e6133c750866a4bc09d9068ef88745ea61b3ffb89386e5b'

## Check Transaction Receipt
# tx_rc = w3.eth.get_transaction_receipt(tx_hash)
# print_json(tx_rc)

## Get Contract Address
# print(tx_rc.contractAddress)
c_addr = '0x0B7205fA965369da717Fce711Cc6e9E0616a5f25'
## Check: Etherscan, 'to' of the contract creation tx.

## Test deployed contract: needs the contract address and abi.
def test_deployed_contract(file):
    c = w3.eth.contract(address=c_addr, abi=abi)
    for f in c.all_functions():
        print(f.fn_name)
# test_deployed_contract('Storage')

#---------------------------------------------------------

## Call contract function:
## Read only call needs no gas and no signing.
def call_retrieve():
    con = w3.eth.contract(address=c_addr, abi=abi)
    print(con.functions.retrieve().call())
# call_retrieve()

## Side effect call, the sender will be charged with gas and
##  the tx must be signed with the sender private key.
def call_store(value):
    cid, nonce, currGas = get_info(john_addr)
    con = w3.eth.contract(address=c_addr, abi=abi)
    tx = con.functions.store(value).buildTransaction({
        'nonce': nonce, 'chainId': cid,
        'gas': "0x21000", 'gasPrice': currGas
    })
    signed_tx = w3.eth.account.sign_transaction(tx, john_priv)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(tx_hash.hex())
# call_store(1)
# call_retrieve()

## Check: \supplement for unsign examples.
## Try: read, compile, deploy and call 'Faucet'.



