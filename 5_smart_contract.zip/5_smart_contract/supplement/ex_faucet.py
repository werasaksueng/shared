''' This example show how to work with 'Faucet' smart contract
   using Ganache or Anvil without signing. '''

from myutil import *

john_addr = w3.eth.accounts[0]          # owner
jack_addr = w3.eth.accounts[1]          # deposit, withdraw

## Create contract object.
abi = read_file('contracts/Faucet.abi')
bin = read_file('contracts/Faucet.bin')
con_obj = w3.eth.contract(abi=abi, bytecode=bin)

## 'john' deploy the contract.
tx_hash = con_obj.constructor().transact({'from': john_addr}).hex()
# print(tx_hash)
## Fix the tx_hash from here.
tx_hash = '0x07141b644655486a1db44d2c48fd3d4defb7aa77e6d0bbd8abfbfc62e0f97caa'

## Get deployed contract.
c_addr = w3.eth.get_transaction_receipt(tx_hash).contractAddress
# print(c_addr)
con = w3.eth.contract(address=c_addr, abi=abi)

def balances():
    print(w3.eth.get_balance(john_addr))
    print(w3.eth.get_balance(jack_addr))
    print(w3.eth.get_balance(c_addr))
# balances()

''' There is no deposit() in the 'Faucet' contract.
If a tx send value to a contract address without data
  the value is added to the contract balance. 
 
Anyone can call the smart contract using 'c_addr' or 'con'.
'tx' may be created from a json using 'c_addr'.   '''
def deposit(depositor_addr, value):
    tx = { 'from': depositor_addr, 'to': c_addr, 'value': value }
    print(w3.eth.send_transaction(tx).hex())
# deposit(john_addr, 100); balances()
# deposit(jack_addr, 200); balances()

## 'tx' may be created with buildTransaction() using 'con'. 
def withdraw(withdrawer_addr, value):
    tx = con.functions.withdraw(value).buildTransaction({
        'from': withdrawer_addr,
        'gas': "0x21000", 'gasPrice': "0x40000000"  })
    print(w3.eth.send_transaction(tx).hex())
# withdraw(john_addr, 100); balances()
# withdraw(jack_addr, 10); balances()
