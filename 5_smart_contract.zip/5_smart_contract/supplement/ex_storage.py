''' This example show how to work with 'Storage' smart contract
   using Ganache or Anvil without signing.
Assume that the contract had been compiled and deployed. '''

from myutil import *

john_addr = w3.eth.accounts[0]
# print(john_addr)

def john_balance():
    print(w3.eth.get_balance(john_addr))
# john_balance()

#-----------------------------------------------
## Read abi and bin.
abi = read_file('contracts/Storage.abi')
bin = read_file('contracts/Storage.bin')

## Create contract object.
con_obj = w3.eth.contract(abi=abi, bytecode=bin)

## List functions.
def list_function():
    for f in con_obj.all_functions():
        print(f.fn_name)
# list_function()

#-----------------------------------------------

## Deploy contract:
# tx_hash = con_obj.constructor().transact({'from': john_addr}).hex()
# print(tx_hash)

## Get Contract Address
# c_addr = w3.eth.get_transaction_receipt(tx_hash).contractAddress
# print(c_addr)

## Get Deployed Contract:
# con = w3.eth.contract(address=c_addr, abi=abi)

#-----------------------------------------------
## Call retrieve()
# print(con.functions.retrieve().call())

## Call store()
# tx_hash = con.functions.store(1).transact({'from': john_addr})
# print(tx_hash)

def check_result(tx_hash):
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    if tx_receipt != None:
        print(con.functions.retrieve().call())
# check_result(tx_hash)

