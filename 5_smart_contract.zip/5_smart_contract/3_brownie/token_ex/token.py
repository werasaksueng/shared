#!/usr/bin/python3

from brownie import Token, accounts

def main():
    return Token.deploy("Test Token", "TST", 18, 1e21, {'from': accounts[0]})

def airdrop(value=1e3):
    t = main()
    for a in accounts[1:]:
        t.transfer(a, value, {'from': accounts[0]} )

def list_balances():
    try:
        t = main()
        for a in accounts:
            print(a, t.balanceOf(a))
    except:
        print('Token is not deployed.')    
