from brownie import *

def deploy():
    return Storage.deploy({'from': accounts[0]})

def retrieve(s):
    retur s.retrieve()

def store(s, v):
    s.store(v)

def main():
    s = deploy()
    store(s, 1)
    print(retrieve(s))

