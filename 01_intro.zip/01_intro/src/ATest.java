class A {
    int x = 1;
    private int y = 2;
    public int z = 3;
}
class ATest {
    public static void main(String argv[]) {
        A a = new A();
        // System.out.println(a.y);    // Error
        System.out.println(a.x + ", " + a.z); // 1, 3 
    }
}
