class Complex {
    double r, i;
    Complex(double r, double i) {
        this.r = r; this.i = i;
    }
    void add(Complex a) {
        r += a.r;
        i += a.i;
    }
    void print() {
        System.out.println(r + "+" + i+"i");
    }
}
class ComplexTest {
    static public void main(String args[]) {
        Complex c1 = new Complex(1.0, 2.0);
        Complex c2 = new Complex(3.0, 4.0);
        c1.add(c2);
        c1.print();    // 4.0+6.0i
    }
}
