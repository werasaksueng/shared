class Student:
    def __init__(self, name, gpa):
       self.name = name
       self.gpa = gpa
    def is_pro(self):
        return self.gpa < 2.0

john = Student('John', 1.8)
print(john.is_pro())
jack = Student('Jack', 4.0)
print(jack.is_pro())
