class BadSort {
    static void print(int a[]) {
        for (int i = 0; i < a.length; i++)
            System.out.print(a[i]+",");
    } 
    static void swap(int a[], int i, int j) {
        int tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    static void sort(int a[]) {
        for (int i = a.length-1; i >= 0; i--)
            for (int j = 0; j < i; j++)
                if (a[j] > a[j+1])
                    swap(a, j, j+1);
    }
    public static void main(String args[]) {
        int a[] = new int[] {4, 9, 2 ,6, 3, 8, 5, 1, 7};
        sort(a);
        print(a);
    }
}
