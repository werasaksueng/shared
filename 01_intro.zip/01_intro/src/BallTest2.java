class Ball {
    private double mass, momentum;
    Ball(double mass,  velocity) {
        this.mass = mass;
        momentum = mass * velocity;
    }
    public double getVelocity() { return momentum / mass; }
    public void setVelocity(double v) { momentum = mass * v; }
    public double getMomentum() { return momentum; }
    public void setMomentum(double mm) { momentum = mm; }
}
class BallTest {
    public static void main(String args[]) {
        Ball b = new Ball(1.0, 10.0);
        System.out.println(b.getMomentum()); // 10.0

        b.setMomentum(5.0);
        System.out.println(b.getVelocity()); // 5.0

        b.setVelocity(20.0);
        System.out.println(b.getMomentum()); // 20.0
    }
}
