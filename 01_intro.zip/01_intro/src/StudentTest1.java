class Student {
    String name;
    float gpa;
    boolean isPro() { return gpa < 2.0; } 
}
class StudentTest {
    public static void main(String arg[]) {
        Student john = new Student();
        john.name = "John"; john.gpa = 1.8f;
        System.out.println(john.name + ": " + john.isPro());

        Student jack = new Student();
        jack.name = "Jack"; jack.gpa = 4.0f;
        System.out.println(jack.name + ": " + jack.isPro());
    }
}
