class A:
    def __init__(self):
        self.x = 1
    def get_x(self):
        return self.x

a = A()
print(a.x, a.get_x())  
