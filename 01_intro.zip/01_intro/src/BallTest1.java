class Ball {
    private double mass, velocity;
    Ball(double mass, double velocity) {
            this.mass = mass;
            this.velocity = velocity;
    }
    public double getVelocity() { return velocity; }
    public void setVelocity(double v) { velocity = v; }
    public double getMomentum() { return mass * velocity; }
    public void setMomentum(double mm) { velocity = mm / mass; }
}
class BallTest {
    public static void main(String args[]) {
        Ball b = new Ball(1.0, 10.0);
        System.out.println(b.getMomentum()); // 10.0

        b.setMomentum(5.0);
        System.out.println(b.getVelocity()); // 5.0

        b.setVelocity(20.0);
        System.out.println(b.getMomentum()); // 20.0
    }
}
