class A:
    def __init__(self):
        self.__x = 1
    def __f(self):
        print('Hello')
a = A()
# print(a.__x)			## error
# a.__f()			## error
