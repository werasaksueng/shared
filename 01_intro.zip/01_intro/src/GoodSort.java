class MyArray {
    int a[] = new int[] {4, 9, 2 ,6, 3, 8, 5, 1, 7};
    public void print() {
        for (int i = 0; i < a.length; i++)
            System.out.print(a[i]+",");
    } 
    private void swap(int i, int j) {
        int tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    public void sort() {
        for (int i = a.length-1; i >= 0; i--)
            for (int j = 0; j < i; j++)
                if (a[j] > a[j+1])
                    swap(j, j+1);
    }
}
class GoodSort {
    public static void main(String args[]) {
        MyArray a = new MyArray();
        a.sort();
        a.print();
    }
}
