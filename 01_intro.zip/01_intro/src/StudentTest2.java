class Student {
    String name;
    float gpa;
    Student(String name, float gpa) {
        this.name = name; this.gpa = gpa;
    }
    boolean isPro() { return gpa < 2.0; }
}
class StudentTest {
    public static void main(String arg[]) {
        Student john = new Student("John", 1.8f);
        System.out.println(john.name + ": " + john.isPro());

        Student jack = new Student("Jack", 4.0f);
        System.out.println(jack.name + ": " + jack.isPro());
    }
}
