''' Solidity compiler using Python:
'py-solc-x' is a Python wrapper for 'solc'.
Support only Solidity versions >=0.4.11
	https://solcx.readthedocs.io/en/latest/
pip install py-solc-x
'''
## To install py-solc-x:
def install(version='0.8.14'):  ## Try: version='latest' 
    from solcx import install_solc
    print(install_solc(version)) 
# install()
# install('0.6.0')
## Check C:\Users\<User>\.solcx   Just delete to uninstall.
#-----------------------------------------------------------

## pip install web3
## Automatically detects and connects to a Web3 provider.
## Start Ganache.
from web3.auto import w3
# print(w3.is_connected())   ## Try: Without starting Ganache.

## Compile Smart Contracts with py-solc-x: 
from solcx import compile_source
from pprint import pprint
from myutil import *
def compile(file):
    ## Read input contract:
    code = read_file('contracts/'+ file + '.sol')

    ## Compile:
    compiled = compile_source(code,
          output_values=['abi', 'bin'],
          solc_version='0.8.14')
    #  pprint(compiled)

    ## Extract abi and bin
    res = compiled['<stdin>:'+file]
    abi = res['abi']
    bin = res['bin']
    # print(abi); print(bin)

    ## Save:
    write_file('contracts/'+ file + '.abi', w3.to_json(abi))
    write_file('contracts/'+ file + '.bin', bin)
    print('Success')
# compile('Storage')   
# compile('Faucet')

''' A smart contract is similar to an OOP object, which 
  may have data(state) and function(behavior).
Smart contracts must be deployed and excecuted in EVMs.
An undeployed smart contract can be tested by listing its functions. '''
def test_contract(fname):
    ## Read abi and bin.
    abi = read_file('contracts/'+ fname + '.abi')
    bin = read_file('contracts/'+ fname + '.bin')
    # print(abi); print(bin)

    ## Create a Smart Contract Object(undeployed yet).
    cobj = w3.eth.contract(abi=abi, bytecode=bin)

    ## List the object functions.
    [ print(f.fn_name) for f in cobj.all_functions()]
# test_contract('Storage')
# test_contract('Faucet')

