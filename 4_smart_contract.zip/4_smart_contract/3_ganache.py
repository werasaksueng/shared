## Smart contracts must be deployed in Ehtereum Blockchains.  
## Start Ganache:
# from web3 import Web3
# w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))

from web3.auto import w3
john = w3.eth.accounts[0]
jack = w3.eth.accounts[1]

def get_balance(addr):
    return w3.eth.get_balance(addr)
# print(get_balance(john))
# print(get_balance(jack))

## A smart contract can be included in a tx and deployed
##  by sending the tx.
def deploy(sender_addr, abi, bin):
    ## Create contract object.
    cobj = w3.eth.contract(abi=abi, bytecode=bin)

    ## Deploy the contract object.
    tx_hash = cobj.constructor().transact({'from': sender_addr}).hex()

    ## Waiting for tx receipt (a dict).
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_receipt['contractAddress']
	## Try: inspect tx_receipt with pprint()

## Ex. John is the sender to deploy 'Storage' contract.
from myutil import *
st_abi = read_file('contracts/Storage.abi')
st_bin = read_file('contracts/Storage.bin')
# st_addr = deploy(john, st_abi, st_bin)
# print(st_addr)   ## Check In Ganache: transaction and contract address.
## A deployed contract will have its address(and balance).
## Save the contract address, so that not to deploy again. 
st_addr = '0x3Ae3A3042c00401191a1a2724291cEAF5ba57672'

## To verify if the contract is deployed successfully:
## Get the bytecode at the address, success if not empty.
# print(w3.eth.get_code(st_addr))

## Check that John pays gas for sending the deploy tx.
# print(get_balance(john))

## To interact with a deployed contract, its reference is needed.
## To get the reference, the contract address and abi are needed..
def get_ref(caddr, abi):
    return w3.eth.contract(address=caddr, abi=abi)

## Test the deployed contract by listing its functions.
st_ref = get_ref(st_addr, st_abi)
# [ print(f.fn_name) for f in st_ref.all_functions()]

''' Calling a deployed contract function is performed
 by sending invocation tx which may be auto sign or raw.

Calling functions with side effects require gas
 but no side effect requires no gas.
'''
## Auto sign invocation tx:
## No side effect.
##     <contract ref>.functions.<func name>(<args>).call()
# print(st_ref.functions.retrieve().call())
## Anyone can call the function.

## With side effect.
##     <contract ref>.functions.<func name>(<args>).transact(<tx data>)
##  return the invocation tx hash.
# print(st_ref.functions.store(1).transact({'from': john}).hex()) 
## The stored value overwrite the old value.

## Check the side effect.
# print(st_ref.functions.retrieve().call())

## Check that John pays gas for sending the invocation tx.
# print(get_balance(john)) 

#-----------------------------------------------------------

''' Raw invocation tx:
Ganache supports both auto sign and raw tx.
Infura does not support wallets so no auto sign tx.

Auto sign automatically computes the amount of gas but
  usually pay more than enough. Raw tx allows more control.

Auto sign is usually more simple. Raw tx is required only
  when no wallets suppotred.

Raw tx need sender private key and recent Blockchain information.
'''
def get_bkc_info(user_addr):
    cid = w3.eth.chain_id
    nonce = w3.eth.get_transaction_count(user_addr)
    block = w3.eth.get_block("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, currGas
# print(get_bkc_info(john))

## Calling store(<value>) with raw tx.
## Copy John private key from Ganache.
john_priv = 'fcee934664d490da2b3b0593f39497e2e4831ef7d5d8c3810826ee407f322ebe'
def raw_store(sender_addr, sender_priv, value):
    ## Get Blockchain info.
    cid, nonce, currGas = get_bkc_info(john)

    ## Create raw tx (unsigned yet).
    ##  <contract ref>.functions.<func name>(<args>).build_transaction(<tx data>)
    tx = st_ref.functions.store(value).build_transaction({
        'nonce': nonce, 'chainId': cid,
        'gas': "0x21000", 'gasPrice': currGas
    })
    # print(tx)

    ## Sign and send tx.
    signed_tx = w3.eth.account.sign_transaction(tx, sender_priv)
    return w3.eth.send_raw_transaction(signed_tx.raw_transaction).hex()
# tx_hash = raw_store(john, john_priv, 2)
# print(tx_hash)
tx_hash = '979f5814454069d95bceb6d986dd05bb5aae92b249e9a3f019e2c16c4325d3ad'

## Check the side effect.
# print(st_ref.functions.retrieve().call())

## Check the tx receipt
from pprint import pprint
# tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
# pprint(str(tx_receipt))

##########################################################

''' The Faucet.sol is in the 'contracts' directory.
This smart contract similates a faucet that allows
  depositing and withdrawing an asset.

Compile and test the 'Faucet' with compile() and 
  test_contract() in py_solc.py.
There is only withdraw() in the contract.
But a deployed contract will have address and balance.
Assets can be deposited to the contract by sending
  tx to send value to the contract address (without data).

Deploy 'Faucet' contract with the above deploy().
'''
fc_abi = read_file('contracts/Faucet.abi')
fc_bin = read_file('contracts/Faucet.bin')
## Suppose John is the tx sender.
# fc_addr = deploy(john, fc_abi, fc_bin)
# print(fc_addr)
fc_addr = '0x1222Ef3c57Ba7e7b16276EAA864444Afdd820422'

## Check the faucet balances:
# print(get_balance(fc_addr)) 

## Deposit by sending value to the contract address.
## The contract reference is not needed.
def deposit(sender_addr, caddr, value):
    tx = { 'from': sender_addr, 'to': caddr, 'value': value }
    tx_hash = w3.eth.send_transaction(tx).hex()
    return w3.eth.wait_for_transaction_receipt(tx_hash)

## Suppose John deposit 100 to the faucet.
# deposit(john, fc_addr, 100)
# print(get_balance(fc_addr))
# print(get_balance(john))   ## decrease (gas + 100)

## To call withdraw(), the contract reference is needed.
def withdraw(sender_addr, caddr, abi, value):
    cref = w3.eth.contract(address=caddr, abi=abi)
    tx_hash = cref.functions.withdraw(value).transact({'from': sender_addr}).hex()
    return w3.eth.wait_for_transaction_receipt(tx_hash)

## Suppose Jack withdraw 20 from the faucet.
# withdraw(jack, fc_addr, fc_abi, 20)
# print(get_balance(fc_addr))     ## 100
# print(get_balance(jack))        ## + 20, - gas