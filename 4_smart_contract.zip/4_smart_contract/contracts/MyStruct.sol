pragma solidity ^0.8.0;
contract MyStruct {
    struct Student {
        uint id;
        string name;
        string department;
    }
    
    Student john = Student(1, "john", "cs");
    function getJohn() public view returns (Student memory) {
       return john;
    }

    Student jack;
    function setJack(uint _id, string memory _name, string memory _department) public {
        jack = Student(_id, _name, _department);
   }
}
