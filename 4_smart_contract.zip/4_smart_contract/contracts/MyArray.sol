pragma solidity ^0.8.0;
contract MyArray {
    uint[] a1;  // dynamic array of type uint
    uint[] a2 = [1, 2, 3];  // dynamic array with 1, 2 and 3
    uint[3] a3 = [1, 2, 3]; // fixed size array

    constructor() public {
      a1.push(1); a1.push(2); a1.push(3);
   }
   function get_a1() public view returns(uint[] memory) {
       return a1;
   }
   function push(uint i) public {
        a1.push(i); 
    }
    function pop() public {
        a1.pop(); 
    }
    function set(uint i, uint v) public {
        a1[i] = v;
    }
    function get(uint i) public view returns(uint) {
        return a1[i];
    }
    function remove(uint i) public {
        delete a1[i]; 
    }
    function length() public view returns (uint) {
        return a1.length; 
    }
}
