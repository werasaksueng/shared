pragma solidity ^0.8.0;
contract MyMapping {
    struct Student {
        uint id;
        string name;
        string department;
    }

    mapping(uint => Student) public my_student;
    uint public my_student_count = 0;

    function setStudent(string memory _name, string memory _department) public {
        my_student_count++;
        my_student[my_student_count] = Student(my_student_count, _name, _department);
   }

    function getStudent(uint _id) public view returns (Student memory) {
       return my_student[_id];
    }
}
