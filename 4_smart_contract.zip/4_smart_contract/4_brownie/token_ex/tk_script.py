#!/usr/bin/python3

from brownie import Token, accounts
def deploy():
    t = Token.deploy("My Token", "TST", 18, 1e21, {'from': accounts[0]})
    print('name:', t.name())
    print('symbol:', t.symbol())
    print('totalSupply:', t.totalSupply(), '\n')

def balances():
    t = Token[-1] ## Get the most recent deployed token.
    try:
        for a in accounts:
            print(f'{a}: {t.balanceOf(a)} TST, {a.balance()} ETH')
        print()
    except:
        print('Token is not deployed.') 

def airdrop(value=1e3):
    t = Token[-1] 
    for a in accounts[1:]:
        t.transfer(a, value, {'from': accounts[0]} )

def transfer(sender, receiver, value):
    t = Token[-1]
    print('Before:') 
    print(f"Sender balance: {t.balanceOf(sender)}")
    print(f"Receiver balance: {t.balanceOf(receiver)}")
    tx = t.transfer(receiver, value, {"from": sender})
    tx.wait(1)
    print('After:') 
    print(f"Sender balance: {t.balanceOf(sender)}")
    print(f"Receiver balance: {t.balanceOf(receiver)}")

def main():
    deploy()
    balances()
    airdrop()
    balances()
    transfer(accounts[1], accounts[2], 1)