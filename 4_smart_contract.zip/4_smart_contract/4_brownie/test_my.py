
def test_1(accounts):
    assert len(accounts) == 5

def test_2(accounts):
    assert accounts[0].balance() == 99999999999999999999


