## Suppose all contracts codes and output are in 'contracts' directory.
def read_file(fname):
    with open(fname, 'r') as f:
        return f.read()

def write_file(fname, data):
    with open(fname, 'w') as f:
        f.write(data)

