API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
CHAIN = 'ethereum-sepolia'
HEADERS = {'Content-type': 'application/json',
	   'x-api-key': API_KEY }

account1 = "0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5"
account1_priv = "ebac496b7df4d594c138b0a992cd9094b25ae27315f07e26d0b520976a9db423"
me = '0x5E98B03695d98eD2A6563cCE88693b494aA2df64'

import requests, json
def print_json(res):
   print(json.dumps(res.json(), indent=4, sort_keys=True))

def deploy():
   URL = 'https://api.tatum.io/v3/nft/deploy'
   DATA = {
         "chain": "ETH",
         "symbol": "MFT",
         "name": "MyNftV1",
         "fromPrivateKey": account1_priv
      }
   print_json(requests.post(URL, json=DATA, headers=HEADERS))
# deploy()
txId = '0x31091024914b58224513e6cc0431b02c845a8aab76d5a5a80c4b3fa4c02b148b'
# txId = '0xf9c12f41f3f31da95d6775b84718fade813a409c13baf8ff27db6c22560bd43d'

def get_nft_tx():
   URL = "https://api.tatum.io/v3/nft/transaction/ETH/" + txId
   print_json(requests.get(URL, headers=HEADERS))
# get_nft_tx()
contractAddress = '0x4C9f63A768a7651A99656906deC4B1f2F062e5A3'
# contractAddress = '0xd30A457E1B09CBf9B2243Ebf464b07a89db6b882'

def mint():
   URL = 'https://api.tatum.io/v3/nft/mint'
   DATA = {
         "chain": "ETH",
  	 "to": account1,
  	 "contractAddress": contractAddress,
  	 "tokenId": "123",
  	 "url": "https://my_token_data.com",
         "fromPrivateKey": account1_priv
      }
   print_json(requests.post(URL, json=DATA, headers=HEADERS))
# mint()
txId = '0xb8e9a0d60bd039d5420b2fac6a1751a42e0ea01d2d5f31bccc3351f62a6ac76d'

## Get number of tokens owned by adderss for a contract address.
def get_token(caddr, addr):
   URL = "https://api.tatum.io/v3/nft/balance/ETH/" + caddr + '/' + addr
   print_json(requests.get(URL, headers=HEADERS))
# get_token(contractAddress, account1) 

## Transfer NFT from 'account1' to 'me'.
def transfer():  
   URL = "https://api.tatum.io/v3/nft/transaction"
   PARAMS = {
      "chain": "ETH",
      "to": me,
      "contractAddress": contractAddress,
      "tokenId": "123",
      "fromPrivateKey": account1_priv
   }
   print_json(requests.post(URL, headers=HEADERS, json=PARAMS))
# transfer()
# get_token(me, contractAddress)
# get_token(account1, contractAddress)

## Get Nft by tokenId
def get_nft(caddr, tokenId,):
   URL = 'https://api.tatum.io/v3/nft/transaction/tokenId/ETH/'+ caddr + "/" + tokenId
   QUERY = { "pageSize": "10" }
   print_json(requests.get(URL, headers=HEADERS, params=QUERY))
# get_nft(contractAddress, "123") 

## Get Nft by tokenId
def get_meta(caddr, tokenId,):
   URL = 'https://api.tatum.io/v3/nft/metadata/ETH/'+ caddr + "/" + tokenId
   print_json(requests.get(URL, headers=HEADERS))
# get_meta(contractAddress, "123") 