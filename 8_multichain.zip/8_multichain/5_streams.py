from myutil import *

## start_mc.bat
## Reset Multichain and prepare.
def prepare_grant():
    prepare()   ## myutil

    with open('addr.bin', 'rb') as f:
        addrs = pickle.load(f)

## Grant 'receive,send' permissions to the addresses.
    a = '{},{},{}'.format(addrs[1], addrs[2], addrs[3])
    api.grant(a, 'receive,send')

## List permission:
    for j in api.listpermissions('receive,send', a):
        print(j['address'], j['type'])
# prepare_grant()

## Load 'addrs'.
with open('addr.bin', 'rb') as f:
    addrs = pickle.load(f)

#---------------------------------------------------------

''' List Streams:
        multichain-cli chain1 liststreams
Try:    mc liststreams
The 'root' stream is created when the first node is started. '''
def list_streams():
    for s in api.liststreams():
        print(s['name'])
# list_streams()

''' Create Stream:
   multichain-cli chain1 create stream <name> <open>
   multichain-cli chain1 createfrom <from_addr> stream <name> <open>
The creater is the 'root' or 'admin' which has 'create' permission.
An <open> stream allows anyone with 'send' permission to publish to the stream.
Return the 'txid' that creates the stream if success.
Try:
      mc create stream s1 true            '''
# print(api.create('stream', 's1', True))

''' Grant 'create' permission to address to allow a 'non-root' to be a creater.
Try:
   mc grant %addr1% create
   mc createfrom %addr1% stream s2 false

Stream info:
  multichain-cli chain1 getstreaminfo <stream_name>
'''
def get_stream_info(name):
    s = api.getstreaminfo(name)
    # print(s)
    print('name: ', s['name'])
    print('restrict: ', s['restrict'])
# get_stream_info('s1')     ## 'open' streams have 'write' is False.
# get_stream_info('s2')

''' 'write' Permission:
'root' has all permissions, but 'write' permission is not listed.
'''
def list_perms():
    for j in api.listpermissions():
        print(j['address'] , j['type'])
# list_perms()

''' List addresses that have some permissions to a stream:
      multichain-cli chain1 listpermissions <stream_name>.*
Try:
          mc listpermissions s1.*
The 'root' has 'write' permission to all streams.
A stream permission is for a particular stream and belong to an address.
'''
def list_permissions(sname):
    for j in api.listpermissions(sname+'.*'):
        print(j.get('address'), ': ', j.get('type'))
# list_permissions('s1')
# list_permissions('s2')

''' Close Stream:
Open stream: 'write' is false.
Close stream: 'write' is true.
Alternatively, a close stream can be created with restrict: write.
Try:
   mc create stream s3 "{\"restrict\":\"write\"}"
'''
# get_stream_info('s1')     ## 'write' is false
# get_stream_info('s2')     ## 'write' is True
# get_stream_info('s3')     ## 'write' is True

#-----------------------------------------------------------

## Create hex strings.
hello_hex = str_hex('hello');   ## print(hello_hex)  ## 68656c6c6f
hi_hex = str_hex('hi');         ## print(hi_hex)     ## 6869
whatup_hex = str_hex('whatup'); ## print(whatup_hex) ## 776861747570

''' Publish hex string:
A stream item may contain <key>/<value>, where <value> is a hex string.
  multichain-cli chain1 publish <stream_name> <key> <value>
  multichain-cli chain1 publishfrom <from_addr> <stream_name> <key> <value>
Publishing to an open stream requires 'send' permissions.
<key> must be string, <value> may be hex-string or json.
Return the 'txid' that publishs to the stream if success.
Try:
           mc publish s1 k1 68656c6c6f
           mc publishfrom %addr1% s1 k2 6869
More than one items may have the same key.
'''
def pub_hex(sname, key, value):
    print(api.publish(sname, key, value))
# pub_hex('s2', 'key1', hello_hex)
# pub_hex('s2', 'key1', hi_hex)

''' Publishing to a closed stream requires 'send' and 'write' permissions.
Try:
     mc publishfrom %addr2% s3 key1 68656c6c6f      ## falis.
Grant 'add1' the 'write' permission to 's3' stream.
     mc grant %addr2% s3.write
Try again:
     mc publishfrom %addr1% s4 key1 68656c6c6f
'''
#-----------------------------------------------------------------

''' Subscribe to a stream:
Reading a stream requires tracking the stream.
To start tracking a stream, the node must subscribe to the stream.
     multichain-cli chain1 subscribe <stream_name>
Try:
     mc subscribe s1
     mc subscribe s2
Nothings returned if success.

List Items of a stream:
  multichain-cli chain1 liststreamitems <stream_name>
Try:    mc liststreamitems s1
'''
def list_stream_items(sname):
    for js in api.liststreamitems(sname):
        print(js['keys'], hex_str(js['data']))
# list_stream_items('s1')
# list_stream_items('s2')

''' List Items by Stream and Key:
 multichain-cli chain1 liststreamkeyitems <stream_name> <key>
'''
def list_stream_key_items(sname, key):
    for r in api.liststreamkeyitems(sname, key):
        print(hex_str(r['data']))
# list_stream_key_items('s1', 'k1')
# list_stream_key_items('s1', 'k2')
#---------------------------------------------------------------

''' Stream allows duplicated key.
Try:
     mc publish s1 dk 68656c6c6f            ## hello
     mc publish s1 dk 776861747570          ## whatup
'''
# list_stream_key_items('s1', 'dk')
## Duplicated keys may be both useful and unwanted.
## Developers must take charge in controlling the policy.

## If there is no duplicate keys, the result can be found at the first item.
def non_duplicate_key(sname, key):
    r = api.liststreamkeyitems(sname, key)
    print(hex_str(r[0].get('data')))
# non_duplicate_key('s1', 'dk')

#--------------------------------------------------------------
''' Publish Text:
        multichain-cli chain1 publish <stream_name> <key> {"text": <txt>}         '''
# print(api.publish('s1', 'tk', {'text': 'How do you do?'}))

def read_txt(sname, key):
    for j in api.liststreamkeyitems(sname, key):
        d = j['data']
        if type(d) is dict:     ## json
            print(d['text'])
# read_txt('s1', 'tk')
#------------------------------------------------------------

''' Publish Json: allows storing table of records.
        multichain-cli chain1 publish <stream_name> <key> {'json': <json>}
Try: Command line does not allow nesting ' and ".
 mc publish s1 kj "{\"json\":{\"id\":\"1\", \"gpa\":\"3.8\", \"name\":\"John\"}}"
'''
def pub_student(key, id, name, gpa):
    json = {'json': {'id': id, 'name': name, 'gpa': gpa}}
    print(api.publish('s1', key, json))
# pub_student('cs', 1, 'John', 2.1)
# pub_student('cs', 2, 'Jack', 3.8)
# pub_student('ee', 3, 'Joe', 4.0)

## Read json: Normally we can use <key> as the identifier of the record.
def read_student(key):
    for j in api.liststreamkeyitems('s1', key):
        student =j['data']['json']
        print(student['id'], student['name'], student['gpa'])
# read_student('cs')
# read_student('ee')

## Ex. Find gpa by key and name: Querying must be processed by users.
def get_gpa(key, name):
    for js in api.liststreamkeyitems('s1', key):
        s = js['data']['json']
        if s['name'] == name:
            print(s['gpa'])
# get_gpa('cs', 'Jack')
##------------------------------------------------------------------------

def add_more_students():
    pub_student('it', 4, 'Jame', 1.2)
    pub_student('cs', 5, 'Jim', 3.1)
    pub_student('ce', 6, 'Jody', 2.1)
# add_more_students()
# read_student('cs')

''' List Command Options:
  multichain-cli chain1 liststreamkeyitems <sname> <key> <verbose>=False, <count>=10, <start>=0
<verbose> if True contains info about tx.
<count> number of items to be listed (from the first).
<start> (from 0 based position), if negative start from the end.
Try:
     mc liststreamkeyitems s1 cs
     mc liststreamkeyitems s1 cs true
'''
def list_keyitems(key, count=10, start=0):
    for j in api.liststreamkeyitems('s1', key, False, count, start):
        print(j['keys'], j['data'])
# list_keyitems('cs')
# list_keyitems('ce')
# list_keyitems('cs', 2)
# list_keyitems('cs', 3, 1)
# list_keyitems('cs', 2, 2)
# list_keyitems('cs', 1, 0)      ## the first
# list_keyitems('cs', 1, -1)     ## the last

''' Key List:
    multichain-cli chain1 liststreamqueryitems <sname> <json>
List all items by a keys list that specified by a <json>.
<json> defines keys list in the form: ["key1", "key2", ...]
Try:
    mc liststreamqueryitems s1 "{\"keys\":[\"cs\"]}"
'''
def list_queryitems(keys):
    for j in api.liststreamqueryitems('s1', keys):
        print(j['keys'], j['data'])
# list_queryitems({'keys': ['cs']})
# list_queryitems({'keys': ['it']})
# list_queryitems({'keys': ['cs', 'it']}) ## no items with the list of keys

## <key> may be a list of keys.
## Add more records with key list:
def pub_items_with_keylist():
    print(api.publish('s1', 'cs', {'json': {'dep': 'Computer Science'}}))
    print(api.publish('s1', ['cs','oo'], {'json':{'dep':'Computer Science','title':'OO Programming'}}))
    print(api.publish('s1', ['cs','oo'], {'json':{'dep':'Computer Science','title':'OO Design and Analysis'}}))
    print(api.publish('s1', ['cs','dm'], {'json':{'dep':'Computer Science','title':'Discrete Math'}}))
    print(api.publish('s1', 'ee', {'text': 'Electrical Engineer'}))
    print(api.publish('s1', ['ee','dm'], {'json':{'dep':'Electrical Engineer','title':'Discrete Math'}}))
# pub_items_with_keylist()

##  Query by Keys List:
def query_keys():
    for js in api.liststreamkeyitems('s1', 'ee'):
    # for js in api.liststreamqueryitems('s1', {'keys':['cs']}):
    # for js in api.liststreamqueryitems('s1', {'keys':['oo', 'cs']}):
    # for js in api.liststreamqueryitems('s1', {'keys':['dm', 'cs']}):
    # for js in api.liststreamqueryitems('s1', {'keys':['ee']}):
    # for js in api.liststreamqueryitems('s1', {'keys':['dm']}):
    # for js in api.liststreamqueryitems('s1', {'keys':['ee','cs']}):  ## not intersect
        print(js['keys'], js['data'])
# query_keys()
