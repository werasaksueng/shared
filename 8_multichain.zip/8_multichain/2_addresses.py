from myutil import *

''' There are three kinds of addresss:
        - In wallet addresses(iwa): created and managed in wallets.
        - Off wallet addresses(owa): created outside wallets.
        - Imported addresses: created outside and imported into a wallet.

Get Addresses:
Returns all iwa and imported addresses of the node(wallet).
    multichain-cli chain1 getaddresses
Try:      mc getaddresses
Returns a list of str.
Initially there is a 'root' address.
'''
# print(api.getaddresses())

''' The 'root' address is always the first address. '''
# print(api.getaddresses()[0])


''' List Addresses: Returns more information than getaddresses.
     multichain-cli chain1 listaddresses
Try:      mc listaddresses
Returns a list of json.
'ismine' if 'true' the address is an iwa.
'''
# print(api.listaddresses())

''' Create an iwa: the private key is stored in the node.
     multichain-cli chain1 getnewaddress
Try:    mc getnewaddress
Return a str.
'''
# print(api.getnewaddress())

''' Verify if an address is valid:
        multichain-cli chain1 validateaddress <address>
Try:    set addr=<address>
        mc validateaddress %addr%
Return a json. The result is 'isValid'.
The public key is shown but not the private key.
'''
def verify_addr():
    addr = api.getaddresses()[0]    ## root address
    pp.pprint(api.validateaddress(addr))
# verify_addr()

''' Create an owa: key-address are not stored in the node.
      multichain-cli chain1 createkeypairs <count>=1
<count> defines the number of pairs to be generated.
Try:    mc createkeypairs
        mc createkeypairs 2
Returns a list of json.
An account contains private key, public key and address.
Check:  mc getaddresses
'''
def owa_test():
    keys = api.createkeypairs()   ## list of keys
    pri = keys[0]['privkey']
    pub = keys[0]['pubkey']
    addr = keys[0]['address']
    print(len(pri), pri)    ## (56 char) wif private key
    print(len(pub), pub)    ## (66 char) compressed hex public key
    print(len(addr), addr)  ## (38 char) wif compressed address

## The created key is not stored ion the wallet. 
    print(api.listaddresses())
# owa_test()

''' Import Address:
     multichain-cli chain1 importaddress <addr> <scan>
If the <addr> is an owa.
It is imported in to the node, 'ismine' is 'false'.
<scan> is a boolean to specify tracking the transactions of the <addr>. '''
def import_addr():
## Created owa.
    addr = api.createkeypairs()[0]['address']
    print(addr)

## Show addresses in the node.
    [print(a) for a in api.listaddresses()]  ## The 'addr' is not shown.

## Import the owa.
    try:
        r = api.importaddress(addr, 'True')   ## 'True' is a str.
        if r == None:                         ## Success return None.
            print('Success')
        else:
            print(r['error']['message'])
    except:
        print('Import fails.')
        return

    [print(a) for a in api.listaddresses()]  ## 'addr' is shown but 'ismine': False.
import_addr()
