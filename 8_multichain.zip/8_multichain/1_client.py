# pip install requests
import requests

from myutil import *
def json_rpc():
	url = 'http://' + rpchost + ':' + rpcport
	data = '{"method": "getinfo",	\
			"params": [], 			\
			"id": 1, 				\
			"chain_name": "chain1"}'
	headers = { 'Content-type': 'application/json',
				'Accept': 'text/plain'}
	res = requests.post(url, data=data, headers=headers,
			auth=(rpcuser,rpcpasswd))
	print_json(res.text)
json_rpc()

#---------------------------------------------------------------

def savoir_():
	r = api.getinfo()    ## dict
	pp.pprint(r)
# savoir_()

