// EqTest.java
class A {
	private int i;
	A(int i) { this.i = i; }
}
class EqTest {
	public static void main(String args[]) {
		int a = 1, b = 1;
		System.out.println(a == b);

		A x = new A(1);
		A y = new A(1);
		System.out.println(x == y);
	}
}
/* Simple type variables are compared by value.
   Class instances are compared by address.
*/
