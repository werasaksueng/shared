// StaticData.java
class A {
	int x;
	static int s = 0;	
	A(int p) { x = p; s++; }
	int getX() { return x; }
};
class StaticData {
	public static void main(String args[]) {
		System.out.println(A.s);
		A a0 = new A(0);
		A a1 = new A(1);
		System.out.println(a0.getX() + "," + a0.s);
		System.out.println(a1.getX() + "," + a1.s);
		System.out.println(A.s);
	}
}