// ArrayIndex.java
class ArrayIndex {
	public static void main(String args[]) {
		int a[] = new int[10];
		a[10] = 1;
	}
}