// ParamPass.java
class A {
	int v;
	A(int v) { this.v = v; }
	public void inc() { v++; }
}
class ParamPass {
	static void f(int n) { n++; }
	static void g(A a) { a.inc(); }
	public static void main(String args[]) {
		int m = 0;
		f(m);
		System.out.println(m);

		A b = new A(0);
		g(b);
		System.out.println(b.v);
	}
}