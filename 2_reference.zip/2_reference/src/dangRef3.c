#include<stdio.h>
int * f() {
	int x = 1;
	return &x;
}
main() {
	int *p = f();
	printf("%d", *p);
}
