// alt_syn.py
class A:
    x = 1	 		## Class data
    def __init__(self, y):
        self.y = y		## Object data	
    def get_y(self):
        return self.y
    @classmethod
    def get_x(cls):
        return cls.x
    @staticmethod
    def sq(p):
        return p*p
a = A(2)
print(a.get_y(), A.get_x(), A.sq(2)) ## 2 1 4
