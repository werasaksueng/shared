#include<stdio.h>
#include<stdlib.h>
main() {
	int *p, *q;
	p = (int *) malloc(4);
	*p = 123;
	q = p;
	free(p);
	printf("%d", *q);
}
