x = 1; y = x
x += 1
print(x is y)		## False  
 
a = b = []
a.append(1)
print(a is b)		## True   
