class A:
    def hello(self):
        print('Hello')
a = A()
sys.getrefcount(a)		## 2
import weakref
w = weakref.ref(a)
sys.getrefcount(a) 		## 2
a.hello()			## Hello
# w.hello()			## AttributeError
r = w()
r.hello()			## Hello
sys.getrefcount(a)		## 3

