class A:				
    def hello(self):			    
        print('Hello')

class B:
    def __init__(self, a):
        self.a = a
    def greet(self):
        self.a.hello()

a = A()
b = B(a)
b.greet()			## Hello
del a
b.greet()			## Hello

import weakref
class C:
    def __init__(self, a):
        self.a = weakref.ref(a)
    def greet(self):
        if self.a != None and self.a() is not None:
            self.a().hello()
        else:
            print('Invalid')
a = A()
c = C(a)
c.greet()
del a
c.greet()