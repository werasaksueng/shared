class A { }
class B { }
class C { }
class Abc {
	public static void main(String args[]) {
		A a;		// lazy loading
		new B();
		// new C();
	}
}