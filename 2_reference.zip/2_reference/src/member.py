class A:
    x = 1
    def __init__(self, x):
        self.x = x
    def get_X():
        return A.x
    def get_x(self):
        return self.x
print(A.x, A.get_X())    // 1 1
a = A(2)
print(a.x, a.get_x())	 // 2 2