// This.java 
class A {
	private int x;
	A(int x) {
		this.x = x;
	}
	public void add(A a) {
		x += a.x;	// this.x += a.x;
	}
}
