x = 1
print(x, id(x), type(x))
x = 2
print(x, id(x), type(x))
x = 3.0
print(x, id(x), type(x))