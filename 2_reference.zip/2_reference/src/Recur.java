class MyInt {
	private int v;
	MyInt(int v) { this.v = v; }
	public MyInt copy() { return new MyInt(v); }
	public int getV() { return v; }
	public void dec() { v--; }
}
class MyMath {
	static MyInt fac(MyInt i) {
		if (i.getV() == 1)
			return new MyInt(1);
		MyInt j = i.copy();
		j.dec();
		return new MyInt(i.getV() * fac(j).getV());
	}
}
class Recur {
	static public void main(String args[]) {
		MyInt m = new MyInt(5);
		System.out.println(MyMath.fac(m).getV());
	}
}