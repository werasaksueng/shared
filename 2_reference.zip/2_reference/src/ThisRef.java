// ThisRef.java 
class A {
    private int x;
    A(int x) { this.x = x; }
    public int getX() { return this.x; }
}
class ThisRef {
    public static void main(String args[]) {
        A a1 = new A(1);
        A a2 = new A(2);
	System.out.print(a1.getX() + ", " + a2.getX());
    }
}
