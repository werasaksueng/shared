class ClassOp {
	public static void main(String args[]) {
		Class s = java.lang.String.class;
		Class a = A.class;
		Class i = int.class;
		System.out.println(s.getName()+", "+ a.getName()
			+", "+ i.getName());
	}   		// java.lang.String, A, int
}
