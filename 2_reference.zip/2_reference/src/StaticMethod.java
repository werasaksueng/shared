// StaticMethod.java
class A{
	public void f() { }
	static public void g() { }
}
class StaticMethod {
	public static void main(String args[]) {
		A.g();

		A a = new A();
		a.f();
		a.g();
	}
}
