class A { 
    int x;
    A(int x) { this.x = x; }
    public String toString() { return x+""; }
}
class ArrayTest {
    public static void main(String args[]) {
        int x[] = new int[] {1, 2, 3};
        for(int i = 0; i < x.length; i++)
            System.out.print(x[i] + ",");

        A a[] = new A[3];
        for(int i = 0; i < a.length; i++)
            a[i] = new A(i); 
        for(int i = 0; i < a.length; i++)
            System.out.print(a[i] + ",");	
    }
}
