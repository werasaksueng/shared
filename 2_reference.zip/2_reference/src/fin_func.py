import weakref
def bye():
    print('Bye')

class A:
    def hello(self):
        print('Hello')

a = A()
weakref.finalize(a, bye)
a.hello()			## Hello
a = None			## Bye
