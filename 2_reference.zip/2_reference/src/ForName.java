// ForName.java
class ForName {
	public static void main(String args[]) {
		try {
			Class c = Class.forName(args[0]);
			System.out.println(c.getName());
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
}
