import weakref, sys
class A:
    def __init__(self, x):
        self.x = x
class B:
    def setA(self, a):
        self.a = a
class C:
    def setA(self, a):
        self.a = weakref.ref(a)

b = B()
a = A(b)
b.setA(a)
print(sys.getrefcount(a))

c = C()
a = A(c)
c.setA(a)
print(sys.getrefcount(a))





