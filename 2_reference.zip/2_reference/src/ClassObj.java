// ClassObj.java
class A { }
class ClassObj {
    public static void main(String args[]) {
        A a1 = new A();
        A a2 = new A();
        System.out.print(a1.getClass() == a2.getClass());
    }
}