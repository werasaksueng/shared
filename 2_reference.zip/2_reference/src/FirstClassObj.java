class FirstClassObj {
    static Integer f() {
    Integer x = new Integer(1);
        return x;
    }
    public static void main(String args[]) {
        Integer i = f();
    }
}
