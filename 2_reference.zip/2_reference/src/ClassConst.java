class ClassOp {
	public static void main(String args[]) {
		Class s = java.lang.String.class;
		Class a = A.class;
		Class i = int.class;
		System.out.println(s.getName());
		System.out.println(a.getName());
		System.out.println(i.getName());
	}
}
