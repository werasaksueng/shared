x = 1
x = 1.0/3	## Ok
class A: pass
class B: pass
a = A()
a = B()		## Ok