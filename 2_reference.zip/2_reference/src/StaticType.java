class A { }
class B { }
class StaticType {
    public static void main(String args[]) {
        int x;
	// x = 1.0 / 3;		// Error
	// A a = new B();	// Error
    }
}
