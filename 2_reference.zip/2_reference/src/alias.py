x = 1
y = 1
z = x+0 # (x + y) / 2 
print(x == y, x == z)   ## True True
print(x is y, x is z)   ## True False
