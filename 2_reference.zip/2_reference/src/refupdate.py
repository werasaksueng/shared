import sys
x = []
print(sys.getrefcount(x))		## 2
def f():
    a = b = c = x
    print(sys.getrefcount(x))		## 5
    a = None
    print(sys.getrefcount(x))		## 4
    del b
    print(sys.getrefcount(x))		## 3
f()
print(sys.getrefcount(x))		## 2
