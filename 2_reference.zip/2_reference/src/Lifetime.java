// Lifetime.java
class A {
	int x;  // x is created and destroyed with the instance
	void f() {
		int y;
		// y is created when f() is activated
		// and destroy when f() is done.
	}
}
class Lifetime {
	public static void main(String args[]) {
		A a1;
		a1 = new A();	// a1 is created
		A a2 = new A(); // a2 is created
		a1.f();		// y is created and destroyed
		a1 = null;	// a1 is dead
	}	// a2 is dead
}