// Greet.java
class Greet {
	public static void main(String args[]) {
		new Hello().hello("John");
	}
}