class A {
	private String s;
	public void f() {
		s = new String ("Hello");
	}
}
class Obsolete {
	public static void main(String args[]) {
		A a = new A();
		a.f();
		// s is obsolete here.	
	}
}
