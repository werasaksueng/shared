// Hello.java
class Hello {
	public void hello(String name) {
		System.out.println("Hello! " + name);
	}
}