class A: pass
a = A()
print(type(A), type(a))