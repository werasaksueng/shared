#include<stdio.h>
main() {
	int *p;
	p = (int *) 1000;
	*p = 123;
	printf("%d", *p);
}

