class Stack {
	private Object [] a;
	private int top = 0;
	public Stack(int n) { a = new Object[n]; }
	public void push(Object o) { a[top++] = o; }
	public Object pop() { return a[--top]; }
/*	public Object pop() {
		Object o = a[--top];
		a[top] = null;
		return o;
	}
*/
}
class MemLeak {
	public static void main(String args[]) {
		Stack s = new Stack(1000);
		for(int i = 0; i < 1000; i++)
			s.push(new Integer(i));

		for(int i = 0; i < 1000; i++)
			s.pop();
		// All elements in the Stack are Obsolete.
	}
}
