// ThisCons.java 
class A {
    A() { System.out.print("Hello "); }
    A(String name) { this(); System.out.println(name); }
}
class ThisCons {
    public static void main(String args[]) {
        new A("John");  // Hello John
    }
}
