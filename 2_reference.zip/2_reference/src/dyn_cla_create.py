x = 1
if x == 0:
   class A: pass
else:
   class B: pass
print(dir())
