def f(x):
    x += 1
    print(x)	  ## 2
y = 1
f(y)
print(y)	  ## 1  (no side effect)

def g(p):
    p.append(1)
    print(p)		## [1]
a = []
g(a)
print(a) 		## [1]

