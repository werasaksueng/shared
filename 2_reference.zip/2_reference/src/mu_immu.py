x = 1
print(x, id(x))  ## 1 140715609846568
x = x + 1
print(x, id(x))  ## 2 140715609846600

a = []
print(a, id(a))  ## [] 2108580122944
a.append(1)
print(a, id(a))  ## [1] 2108580122944