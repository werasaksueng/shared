class A:
    def __init__(self, x):
        self.x = x
    def get_x(self):
        return self.x
a = A(1)
print(a.get_x())	## 1