// lifetime.cpp
int g;	// g is created at loading time
class A {
	private: int x;
	// x is created when the instance is created
	// and destroyed when the instance is destroyed.
	public: void f() { 
		int y;
		// y is created when f() is activated
		// and destroyed when f() is done.
	}
};
void main() {
	A a;	// a is created
	A *p;
	p = new A();	// p is created
	delete(p);	// p is destroyed
}	// a is destroyed