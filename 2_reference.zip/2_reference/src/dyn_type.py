x = 1
print(x, type(x))   ## 1 <class 'int'>
x = 1.0/3
print(x, type(x))   ## 0.3333333333333333 <class 'float'>
