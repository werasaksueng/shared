// lifetime.c
int g;
void f(int p) {
	int l;
	static int s;
}
main() {
	int m;
        f(m);
}