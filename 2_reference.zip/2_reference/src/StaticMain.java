// StaticMain.java
class StaticMain {
    int x;
    static int y;
    public static void main(String args[]) {
	// System.out.print(x);  // Error
	System.out.print(y);	 // Ok
    }
}