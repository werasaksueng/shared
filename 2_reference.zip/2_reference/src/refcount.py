import sys
x = y = [ ]
print(sys.getrefcount(x))
