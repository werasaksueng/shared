// GetClass.java
class A { }
class GetClass {
	public static void main(String args[]) {
		A a = new A();
		Class c = a.getClass();
		System.out.println(c.getName());
	}
}
