class HelloTest {
	public static void main(String args[]) {
		new Hello().hello("John");
	}
}