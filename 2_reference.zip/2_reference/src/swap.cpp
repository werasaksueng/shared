#include <iostream.h>
using namespace std;

void swapPtr(int *a, int *b) {
	int tmp = *a;
	*a = *b;
	*b = tmp;
}
void swapRef(int &a, int &b) {
	int tmp = a;
	a = b;
	b = tmp;
}
void main() {
	int x = 0, y = 1;
	swapPtr(&x, &y);
	cout << x << ',' << y << endl;

	swapRef(x, y);
	cout << x << ',' << y << endl;
}