// CallBack.java
class A {
	void f(B b) { b.h(this); }
	void g() { System.out.println("Hi"); }
}
class B {
	void h(A a) { a.g(); }
}
class CallBack {
	public static void main(String args[]) {
		A a = new A();
		B b = new B();
		a.f(b);
	}
}