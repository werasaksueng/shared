## Using web3.py with Erc20.
from web3 import Web3		## Start Ganache.
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))
# print(w3.is_connected())

## Account Setting:
me = w3.eth.accounts[0]
john = w3.eth.accounts[1]
jack = w3.eth.accounts[2]

def eth_balances():
    print('ETH balances:')
    print('me:', w3.eth.get_balance(me))
    print('john:', w3.eth.get_balance(john))
    print('jack:', w3.eth.get_balance(jack))
# eth_balances()
#------------------------------------------------

''' Suppose 'contracts/SimpleErc20.sol' had been compiled.
If not try using 'remix'.  '''
def read_file(fname):
    with open(fname, 'r') as f:
        return f.read()
 
def read_abi_bin(fname):
    return read_file('contracts/' + fname + '.abi'), \
           read_file('contracts/' + fname + '.bin')

## To test an undeployed contract.
def print_fn(cont):
    abi, bin = read_abi_bin(cont)
    cobj = w3.eth.contract(abi=abi, bytecode=bin)
    [print(f.fn_name) for f in cobj.all_functions()]
# print_fn('SimpleErc20')
#---------------------------------------

## Deploy a contract by a tx sender:
def deploy(sender_addr, cont):
    abi, bin = read_abi_bin(cont)
    cobj = w3.eth.contract(abi=abi, bytecode=bin)

    ## Deploy the contract object.
    tx_hash = cobj.constructor(
        _name = "MyToken",
        _symbol = "MTK",
        _initialSupply = 1_000_000   ## 1 million tokens
    ).transact({'from': sender_addr})

    ## Waiting for tx receipt (returns a dict).
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_receipt['contractAddress']
## Ex. 'me' deploys 'SimpleErc20'.
# caddr = deploy(me, 'SimpleErc20')
# print(caddr)
caddr = '0x56967aeea962bc3fF6408d7f12073a5DE5A54B14'

## Check: if the deployment sucess.
## 1. Check the contract address has bytecode, not None.
# print(w3.eth.get_code(caddr))

## 2. Check 'me' had paid gas for deploying the contract.
# eth_balances()

## To call the deployed contract functions we need the contract reference.
## Getting contract reference using the contract address and abi.
def get_ref(cont, addr):  ## Return contract reference
    abi, _ = read_abi_bin(cont)
    return w3.eth.contract(address=addr, abi=abi) 
cref = get_ref('SimpleErc20', caddr)

## Calling smart contract functions (read only), no gas.
def call_fn_ex(ref):
    print(ref.functions.name().call())
    print(ref.functions.symbol().call())
    print(ref.functions.totalSupply().call())
# call_fn_ex(cref)

## Check MTK balances (not the ETH):
## Initially 'me' has the totalSupply, the rests have none.
def token_balances(ref):
    print(ref.functions.symbol().call() + ' balances:')
    print('me: ', ref.functions.balanceOf(me).call())
    print('john: ', ref.functions.balanceOf(john).call())
    print('jack: ', ref.functions.balanceOf(jack).call())
# token_balances(cref)

''' The contract may be deployed without totalSupply.
The token may provide mint() for the owner to mint tokens as needed,
  such the token is called Mintable ToKen. '''

## 'me' owns the totalSupply, but the contract address has no MTK yet.
# print(cref.functions.balanceOf(caddr).call())

## Ex. Let's 'me' transfers 100 MTK to 'john'.
# print(cref.functions.transfer(john, 100).transact({'from': me}).hex())
# token_balances(cref)
## This is Ok since 'me' is the tx sender.

## Then let's 'john' transfers 10 MTK to 'jack'.
# print(cref.functions.transfer(jack, 10).transact({'from': john}).hex())
# token_balances(cref)      ## Ok
## That Ok if the tx sender is the owner of the tokens.
#--------------------------------------------------------------

''' Token Distributor System:
Supppse 'me' is the MTK token owner (who creates the tokens).
        'john' is a distributor of MTK.
        'jack' is a customer (who buys MTK from 'john').
A 'distirbutor' is not the token owner, just a seller.
The system allows many distributors that do not own the tokens.

For distributor environment, we needs to transfer tokens by:
	transferForm(owner, receiver, token)

Ex. 'john' transfers me's tokens to 'jack'.
'john' is the distributor (and the tx sender), 'me' is the owner.  '''
# print(cref.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
## Error: since 'john' is not an approved distributor. 

''' An approved distributor must have allowance from the owner to
 transfer some amount of tokens.
Ex.'me' approve 'john' to transfer 100 MTKs. '''
# print(cref.functions.approve(john, 100).transact({'from': me}).hex())

## Check the amount that 'john' is allowed to transfer.
print(cref.functions.allowance(me, john).call())

''' Now john is an approved distributor and can transfer tokens to anyone.
Ex.  'john' transfers 1 MTK to 'jack'.  '''
# print(cref.functions.transferFrom(me, jack, 1).transact({'from': john}).hex())
# eth_balances()
# token_balances(cref)
## The transferred MTK is reduced from 'me', not from 'john'. 

''' Conditions:
  - Transferred token is reduced from owner, not distributor.
  - Transferred token is reduced from the distributor allowance.
  - Transferred tokens must not excess the current allowance.
  - The allowance can be increased by more approve().
  - Distributors pay gas (ETH) and must own enough gas for sending tx.
'''
