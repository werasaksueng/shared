from brownie import MyToken, accounts
from web3 import Web3

me = accounts[0]
john = accounts[1]
jack = accounts[2]

## Newly deploy every runs.
MyToken.deploy({"from": me})
t = MyToken[-1]  ## To access the last deployed MyToken.
t.mint(me, 100)

def balances():
    t = MyToken[-1]
    print('me', t.balanceOf(me))
    print('john', t.balanceOf(john))
    print('jack', t.balanceOf(jack))

def transfer(_from, _to, _value):
    t = MyToken[-1]
    t.transfer(_to, _value, {"from": _from})

def main():
   transfer(me, john, 100)
   balances()