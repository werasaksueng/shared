import java.util.*;
class A<T> {	// T is a type parameter to class 'A'.
 	T t;
 	A(T t) { this.t = t; }
 	public T getT() { return t; }
 	public void setT(T t) { this.t = t; }
 }
class TSGclass {
	public static void main(String args[]) {
		A<Integer> a1 = new A<Integer>(1);
		A<String> a2 = new A<String>("Hello");
		System.out.println(a1.getT() + ", " + a2.getT()); // 1, Hello
		// a1.setT("1");		// compiler time error
		// a1 = a2;			// compiler time error

		Stack<Integer> s = new Stack<Integer>();
		s.push(1);
		// s.push(2.0);			// compiler time error
	}
}
