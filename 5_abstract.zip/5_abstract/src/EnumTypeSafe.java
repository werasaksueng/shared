/* class Suit {
	private final String suit;
	private Suit(String s) { suit = s; }
	public String toString() { return suit; }

	public static final Suit CLUBS = new Suit("Clubs");
	public static final Suit DIAMONDS = new Suit("Diamonds");
	public static final Suit HEARTS = new Suit("Hearts");
	public static final Suit SPADES = new Suit("Spades");
	private static final Suit[] suitArray = { CLUBS, DIAMONDS, HEARTS, SPADES };
	public static Suit[] values() { return (Suit []) suitArray.clone(); }
} */
enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }
class EnumTypeSafe {
	public static void main(String args[]) {
		Suit h = Suit.HEARTS;
		System.out.println(h);    // Hearts
		System.out.println(h ==	Suit.SPADES); // false
		for (Suit s : Suit.values())
			System.out.print(s + ", ");
	}		// Clubs, Diamonds, Hearts, Spades,
}
