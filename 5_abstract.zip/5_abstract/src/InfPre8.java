interface I {
    int x = 1;
    void f();
}