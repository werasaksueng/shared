class Inc:
    def __init__(self):
        self.c = 0
    def __call__(self):
       self.c += 1
inc = Inc()
inc(), inc()
print(inc.c)
