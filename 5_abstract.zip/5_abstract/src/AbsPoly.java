abstract class Shape {
	abstract public String getName();
	abstract public double getArea();
}
class Rectangle extends Shape {
	private double width, height;
	Rectangle(double width, double height) {
		this.width = width; this.height = height;
	}
	public String getName() { return "rectangle"; }
	public double getArea() { return width * height; }
}
class AbsPoly {
	public static void main(String args[]) {
		Shape s = new Rectangle(2,3);
		System.out.print(s.getName() + ", " + s.getArea());
			// rectangle, 6.0
	}
}