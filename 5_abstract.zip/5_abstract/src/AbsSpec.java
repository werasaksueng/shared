abstract class Spec {
	abstract public String hello(String name);
	abstract public String hi(String name);
	public static void test(Spec sp) {
		String name = "John";
		if (sp.hello(name).equals("Hello "+name) 
   && sp.hi(name).equals("Hi "+name))
			System.out.println("Ok");
	}
}
class Impl extends Spec {
	public String hello(String name) {
		return "Hello "+name;
	}
	public String hi(String name) {
		return "Hi "+name;
	}
}
class AbsSpec {
	public static void main(String args[]) {
		 Spec.test(new Impl());  // Ok
	}
}
