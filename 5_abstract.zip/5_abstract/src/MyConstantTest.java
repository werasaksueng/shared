interface MyConstant {
	int YES = 1;
	boolean NO = false;
	String GREET = "Hello";
}
class MyConstantTest implements MyConstant {
	public static void main(String args[]) {
		System.out.println(YES);
		System.out.println(GREET);
		System.out.println(YES + GREET);
	}
}