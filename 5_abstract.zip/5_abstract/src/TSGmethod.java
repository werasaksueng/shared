class TSGmethod {
	static <T, S> boolean isIn(T t, S s[]) {
		for(int i = 0; i < s.length; i++)
			if(t.equals(s[i]))
				return true;
		return false;
	}
	public static void main(String args[]) {
		Integer a[] = {1,2,3,4,5};
		System.out.println(isIn(2, a));

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		System.out.println(isIn(7.0, d));
	}
}
