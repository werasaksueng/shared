class A { String f() {return "f";}}
interface I { String g(); }
interface J { String h(); }
class B extends A implements I, J {
    public String g() {return "g";}
    public String h() {return "h";}
} 
class MulImpl {
    public static void main(String args[]) {
        B b = new B();
        System.out.print(b.f() + "," + b.g() + "," +
		b.h());
    }
}