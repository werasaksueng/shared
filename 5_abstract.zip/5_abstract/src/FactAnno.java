// FactAnno.java
interface Greet {
	void greet();
	public static Greet getInstance(String s) {
		if (s.equals("formal"))
			return (Greet) new Greet() {
				public void greet() {
					System.out.println("Hello");
				}
			};
		else return (Greet) new Greet() {
				public void greet() {
					System.out.println("Hi");
				}
			};
			
	}

}
class FactAnno {
	public static void main(String args[]) {
		Greet g = Greet.getInstance(args[0]);
		g.greet();
	}
}
