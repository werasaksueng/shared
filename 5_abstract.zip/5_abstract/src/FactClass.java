// FactClass.java	Factory Class and Factory Method
interface Greet {
	public abstract void greet();
}
class Hello implements Greet {
	public void greet() {
		System.out.println("Hello!");
	}
}
class Hi implements Greet {
	public void greet() {
		System.out.println("Hi!");
	}
}
abstract class GreetFactory {
	public static Greet getInstance(String n) {
		if (n.equals("formal"))
			return new Hello();
		return new Hi();
	}
}
class FactClass {
	public static void main(String arga[]) {
		Greet g = GreetFactory.getInstance(args[0]);
		g.greet();
	}
}
