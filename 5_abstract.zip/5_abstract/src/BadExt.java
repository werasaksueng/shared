class A {
    int f() { return 1; }
    // String g() { return "2"; }
}
class B extends A {  // extension
    int g() { return 2;  }
}
class C {			   // composition
    A a = new A();
    int f() { return a.f(); }
    int g() { return 2;  }
}

class BadExt {
    public static void main(String args[]) {
	B b = new B();
	System.out.println(b.f()+","+b.g());  // 1,2
	C c = new C(); 
	System.out.println(c.f()+","+c.g());  // 1,2
    }
}