class AMeta(type):
    ## 'attrs' is the namespace of the class.
    def __new__(meta, name, bases, attrs):
        def greet(self):
            print('Hello')

        ## Automatically add hello() to the class.
        attrs['hello'] = greet

        return super().__new__(meta, name, bases, attrs)

class A(metaclass=AMeta):
    pass
A().hello()