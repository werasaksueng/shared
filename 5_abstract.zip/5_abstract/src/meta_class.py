class A:
    pass
a = A()
print(type(A))		## <class 'type'>
print(type(a))		## <class '__main__.A'>

class BMeta(type):
    pass
class B(A, metaclass=BMeta):
    pass
print(B.__bases__)	## (<class '__main__.A'>,)
b = B()
print(type(B))		## <class '__main__.BMeta'>
print(type(b))		## <class '__main__.B'>