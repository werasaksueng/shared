enum MySuit {
	clubs('c'), diamonds('d'), hearts('h'), spades('s');

	private char symbol;
	private MySuit(char symbol) { this.symbol = symbol; }
	public char getSymbol() {
		return
				symbol;
	}
}
class MySuitTest {
	public static void main(String args[]) {
		MySuit s1 = MySuit.diamonds;
		System.out.println(s1.getSymbol());
		System.out.println(s1.ordinal());
		System.out.println(s1.toString());
		System.out.println(s1 == MySuit.spades);
		System.out.println(s1.compareTo(MySuit.spades));
		System.out.println(MySuit.valueOf("spades"));		// mapping String to enum type

		// branch
		switch(s1) {
			case clubs :	System.out.println("Clubs"); break;
			case diamonds:	System.out.println("Diamonds"); break;
			case hearts:	System.out.println("Hearts"); break;
			case spades:	System.out.println("Spades");
		}

		// iterate
		for(MySuit s : MySuit.values())
			System.out.print(s + ",");
	}
}