class TypeWrapper {
	public static void main(String args[]) {
		// jdk 1.4
		Object a[] = { new Integer(1), new Character('A'), new Boolean(true)};

		// jdk 1.5
		Object b[] = {1, 'A', true};
	}
}
/*
 		Simple Types		Type Wrapper Classes
 		    boolean			Boolean
		    byte			Byte
		    short			Short
		    char			Character
		    int				Integer
		    long			Long
		    float			Float
		    double			Double
   ex.
   			int x = 1;
   			Integer y = new Integer(x);
   			int z = y.intValue();

*/