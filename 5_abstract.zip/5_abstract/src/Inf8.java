interface I {
    int x = 1;
    int f();
    default int d() { return 3; }
    static int s() { return 4; }
}
class A implements I {
    public int f() { return 2;}
}
class Inf8 {
    public static void main(String args[]) {
        A a = new A();
        System.out.println(a.x + "," + a.f() + "," + a.d() + "," + I.s());
   }
}