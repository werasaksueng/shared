interface Greeting { void hello(); }
interface Farewell { void bye(); }
class MyClass implements Greeting, Farewell {
	public void hello() { System.out.println("Hello"); }
	public void bye() { System.out.println("Goodbye"); }
}
class MulType {
	static void g(Greeting g) { g.hello(); }
	static void f(Farewell f) { f.bye(); }
	public static void main(String args[]) {
		MyClass c = new MyClass();
		g(c);   // Hello
		f(c);   // Goodbye
	}
}
