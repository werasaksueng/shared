// BoundGeneric.java
class X { }
class A<T extends X> {
	private T t;
	A(T t) { this.t = t; }
	public T getT() { return t; }
	public void setT(T t) { this.t = t; }
}
class B extends X { }
class C extends X { }
class D { }
class BoundGeneric {
	public static void main(String args[]) {
		A<X> ax = new A<X>(new X());
		ax.setT(new B());
		ax.setT(new C());
		// ax.setT(new D());
	}
}