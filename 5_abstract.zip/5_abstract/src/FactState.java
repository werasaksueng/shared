class Greet {
	private String msg;
	private Greet(String msg) { this.msg = msg; }
	public void greet() { System.out.println(msg); }
	public static Greet getInstance(String s) { 
		return s.equals("formal") ? 
			new Greet("Hello! how do you do?") : 
			new Greet("Hi! What's up?");
	}
}
class FactState {
	static public void main(String args[]) {
		Greet g = Greet.getInstance(args[0]);
		g.greet();
	}
}
