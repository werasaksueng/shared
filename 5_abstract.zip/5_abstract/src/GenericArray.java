// GenericArray.java
import java.awt.Color;
import java.util.Date;
class GenericArray {
	public static void main(String args[]) {
		Object a[] = {Color.RED, "Hello", new Date()};
		for (Object x: a)
			System.out.println(x);
	}
}