class MyMeta(type):
    def __new__(meta, name, bases, attrs):
        print("MyMeta.__new__(): ", name)

        ## Create the class object (by default).
        cls = super().__new__(meta, name, bases, attrs)
        return cls

    def __init__(cls, name, bases, attrs):
        print("MyMeta.__init__():", name)

        # Initialize the class object, (as defined in the cass).
        super().__init__(name, bases, attrs)

print("Before defining class 'A'")
class A(metaclass=MyMeta):
    pass
print("After defining class 'A'")


class B(metaclass=MyMeta):
    def __new__(cls):
        print("B __new__()")
        return super().__new__(cls)

    def __init__(self):
        print("B __init__()")
B()

class C(metaclass=MyMeta):
    def __init__(self):
        print("C __init__()")
C()

class D():
    def __init__(self):
        print("D __init__()")
D()