class Restrict<T> {
	T t1;
	// T t2 = new T(); 	// type parameter cannot be instantiated
	// static T t3;		// type parameter cannot be static
	// static T getT() { return t1; }
	 						  // static method cannot access type parameter

	T a[];	// It's ok to define a reference to array of type parameter
	// a = new T[10];	// But cannot create an array of type parameter
}
