class NonPure {
	Object a[] = {0, 1};
	Integer i = 1;
}