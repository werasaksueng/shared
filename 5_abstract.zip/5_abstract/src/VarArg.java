// VarArg.java		Variable Length Arguments
class C {
	void f(int ...v) {
		for(int i : v)
			System.out.print(i + ",");
		System.out.println();
	}
}
class VarArg {
	public static void main(String args[]) {
		C c = new C();
		c.f();	     //
		c.f(1);      // 1,
		c.f(10, 20); // 10, 20
	}
}
