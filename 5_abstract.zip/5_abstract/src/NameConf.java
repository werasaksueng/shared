interface Suit {
    public static final int CLUBS = 0;
    public static final int DIAMONDS = 1;
    public static final int HEARTS = 2;
    public static final int SPADES = 3;
}
interface Part {
    public static final int HEAD = 0;
    public static final int HEARTS = 1;
    public static final int HANDS = 0;
}
class NameConf implements Suit, Part {
    public static void main(String args[]) {
        System.out.print(HEARTS);
    }
}