interface I {
    int x = 1;
    void f();
}
interface J extends I {
    int y = 2;
    void g();
}
class A implements I {
    public void f() { }
}
class ExtImpl {
    public static void main(String args[]) {
	System.out.println(J.x + "," + J.y);
	new A().f();
    }
}