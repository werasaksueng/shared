class AutoBoxing {
	// jdk 1.4
	static Integer incOld(Integer i) {
		int j = i.intValue();
		return new Integer(++j);
	}

	// jdk 1.5
	static Integer incNew(Integer i) {
		return ++i;
	}

	public static void main(String args[]) {
		Integer a = new Integer(1);
		Integer b = 2;			// auto-boxing at compile time
		System.out.println(a + b);	// auto unboxing

		// jdk 1.4
		System.out.println(incOld(new Integer(1)).intValue());

		// jdk 1.5
		System.out.println(incNew(1));
	}
}