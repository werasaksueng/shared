import java.util.*;
class Simplicfy {
	List b = new ArrayList<String>();
	List<String> c = new ArrayList<>();
	List<?> d = new ArrayList<>();

	// Require Java 10.
	var x = 1;
	// var y = null;     // error:

        var z = new ArrayList<String>();
        z.add("Hello");
}