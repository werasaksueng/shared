// UnSafe.java
import java.util.*;
class UnSafe {
	public static void main(String args[]) {
		Stack s = new Stack();
		s.push(new Integer(1)); s.push(new Integer(2));
		// s.push("1"); s.push("2");
		Integer a = (Integer) s.pop();
		Integer b = (Integer) s.pop();
		System.out.print(a.intValue() + b.intValue());
	}
}
