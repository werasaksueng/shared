// FactFact.java
interface Greet {
	String greet();
	public static class Factory {
		public static Greet getInstance() {
			return new Greet() {
		           public String greet() { return "Hello"; }
			};
		}
	}
}
interface Farewell {
	String bye();
	public static class Factory {
		public static Farewell getInstance() {
			return new Farewell() {
		           public String bye() { return "Bye"; }
			};
		}
	}
}
interface MyFactory {
	public static Greet.Factory getGreetFactory() { return new Greet.Factory(); }
	public static Farewell.Factory getFarewellFactory() { return new Farewell.Factory(); }
}
class FactFact {
	public static void main(String args[]) {
		Greet.Factory gf = MyFactory.getGreetFactory();
		System.out.println(gf.getInstance().greet()); // Hello
		Farewell.Factory ff = MyFactory.getFarewellFactory();
		System.out.println(ff.getInstance().bye());   // Bye
	}
}
