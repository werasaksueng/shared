// DateFormatTest.java
import java.util.*;
import java.text.*;
class DateFormatTest {
	public static void main(String args[]) {
		Locale lc = new Locale("en", "US");
		// Locale lc = new Locale("fr", "FR");
		// Locale lc = new Locale("th", "TH");

		int s = DateFormat.DEFAULT;
		// int s = DateFormat.SHORT;
		// int s = DateFormat.MEDIUM;
		// int s = DateFormat.LONG;
		// int s = DateFormat.FULL;

		DateFormat df = DateFormat.getDateInstance(s, lc);
		// DateFormat df = DateFormat.getTimeInstance(s, lc);
	
		System.out.println(df.format(new Date()));
	}
}
