abstract class A {
	abstract void f();
}
class B extends A {
	public void f() { System.out.println("Hello"); }
}
class AbstractExt {
	static void t(A a) { a.f(); }
	public static void main(String args[]) {
		 t(new B());
	}	
}