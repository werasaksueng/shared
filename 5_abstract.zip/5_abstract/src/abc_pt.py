from abc import abstractmethod, ABCMeta
class A(metaclass=ABCMeta):
    @abstractmethod
    def f(self):
        pass
# A()				## TypeError

class B(A):
    def f(self):
        print('Hello')
B().f()				## Hello

class C(A):
   pass
'''   def f(self):
       pass
'''
# C()