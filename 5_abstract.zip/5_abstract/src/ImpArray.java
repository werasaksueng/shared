class ImpArray {
	public static void main(String args[]) {
		int a[] = {2, 1, 3};
		for (int i : a)  // New 'for' syntax.
			System.out.print(i + ", ");

		class C { } 
		C [] c = new C[5];
	}
}