import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@interface Author {
	public String name();
}

@Retention(RetentionPolicy.RUNTIME)
// @Retention(RetentionPolicy.CLASS)  // class loading time,  default
// @Retention(RetentionPolicy.SOURCE) // compile time
@interface Version {
	public int major();
	public int minor();
}

/* Class Annotation */
@Author(name = "John Rambo")
@Version(major = 1, minor = 1)
class A { }

class Annotation {
	public static void main(String args[]) {
		Author a = A.class.getAnnotation(Author.class);
		System.out.println("Author: " + a.name());

		Version v = A.class.getAnnotation(Version.class);
		System.out.println("Version: " + v.major() + "." + v.minor());		
	}
}

/* Method Annotation */
class MethodAnno {
	@Author(name = "John Rambo")
	public static void f() { }

	public static void main(String args[]) {
		try {
			Method m = MethodAnno.class.getMethod("f");
			Author a = m.getAnnotation(Author.class);
			System.out.println(a.name());   // John Rambo
		} catch(NoSuchMethodException e) {
			System.out.println(e.getMessage());
		}
	}
}

/* Single Annotation */
class SingleAnno {
	@Retention(RetentionPolicy.RUNTIME)
	@interface Value { int value(); }

	class A {
		@Value(123)
		public void f() { }
	}
	public static void main(String args[]) {
		try {
			Method m = A.class.getMethod("f");
			Value v = m.getAnnotation(Value.class);
			System.out.println(v.value());    // 123
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

/* Default Annotation */
class DefaultAnno {
	@Retention(RetentionPolicy.RUNTIME)
	@interface Values {
		String name() default "John Rambo" ;
		String url() default "http://www.rambo.com";
	}
	class A {
		@Values
		// @Values( name = "Jack Ripper")
		// @Values( url = "http://www.jack.com")
		// @Values( name = "Jack Ripper", url = "http://www.jack.com")
		public void f() { }
	}
	public static void main(String args[]) {
		try {
			Method m = A.class.getMethod("f");
			Values a = m.getAnnotation(Values.class);
			System.out.println(a.name() + "\n" + a.url());
		} catch(NoSuchMethodException e) {
			System.out.println(e.getMessage());
		}
	}
}

/* Marker Annotation */
class MarkerAnno {
	@Retention(RetentionPolicy.RUNTIME)
	@interface John { }

	class A {
		@John
		public void f() { }
	}
	public static void main(String args[]) {
		try {
			Method m = A.class.getMethod("f");
			if (m.isAnnotationPresent(John.class))
					System.out.println("John");
			else
					System.out.println("Someone else");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

/* Vararg of parameter type is allows but not safe.
Java7 provides @SafeVarargs to suppress the warning. */
class SafeVararg {
	@SafeVarargs		// Try: comment this line.
	static <T> void f(T ...t){
		for (T x : t)
			System.out.println(x.getClass().getName());
	}
	public static void main(String args[]) {
		f(1, 2.0, '3', "4");
	}
}
