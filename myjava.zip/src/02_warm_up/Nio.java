import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.Files;
import java.util.List;

/* Java 7 introduce a interface 'java.nio.file.Path' to improve file operations.
    and a factory class 'java.nio.file.Paths' to create Path. */
class Nio {
	public static void main(String args[]) throws IOException {
	/* Old java.io.File */
		File f = new File("C:/myjava/1.newfeature/Nio.java");
		System.out.println(f.getName());
		System.out.println(f.getPath());
		System.out.println("-------------");

	/* Path can refers to absolute or relative paths. */
		Path p = Paths.get("Nio.java");
		// Path p = Paths.get("./Nio.java");
		// Path p = f.toPath();
		System.out.println(p.getFileName());

	/* File and Path interchange */
		File ff = p.toFile();
		Path pp = f.toPath();

	/* Java 7 introduce a service class 'java.nio.file.Files' for operations on Path. */
		Path src = Paths.get("index.txt");
		Path tar = Paths.get("temp.txt");
	/* copy() */
		Files.copy(src, tar, StandardCopyOption.REPLACE_EXISTING);
	/* readAllLines() */
		List<String> lines = Files.readAllLines(src);
		for(String l : lines)
			System.out.println(l);
	/* delete() */
		// Files.delete(tar);
	}
}
