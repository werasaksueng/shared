/* Java6 introduces 'string pool'. */
class StringPool {
	public static void main(String args[]) {
		/* A string literal creates the string in the pool. */
		String s1 = "Hello";

		/* Inferring to an already exist string in the pool, resulting the instance. */
		String s2 = "Hello";
		System.out.println(s1 == s2);	/* true */

		/* Get the reference of the already exist string in the pool. */
		String s3 = s2.intern();
		System.out.println(s1 == s3);	/* true */

		/* Create a new string which is not in the pool. */
		String s4 = new String("Hello");
		System.out.println(s1 == s4);   /* false */
	}
}
