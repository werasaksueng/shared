import java.io.*;

/* PreJava 7, closing a file or stream properly is very awkward. */
class PreJava7 {
	public static void main(String args[]) {
		BufferedReader br = null;  // The reference will be referred to in finally.
		try {
			br = new BufferedReader(new FileReader("index.txt"));
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {  // The closing should be in finally block.
			if (br != null) {   // Checking is necessary since the stream opening may fail.
				try {
					br.close();   // close() may throws an exception. 
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
/* Java 7 introduced an 'auto closeable' class that implements AutoCloseable interface.
		javap java.lang.AutoCloseable */
class A implements AutoCloseable {
		public void hello() {				// resource-specific method
			System.out.println("Hello.");
		}
		// @Override
		public void close() throws Exception {
			System.out.println("Goodbye!");
		}
}
/* Java 7 introduces 'resource block' in the try-catch, surrounded by ().
		try (<resource block>) { } catch () {<catch block>}
All objects created(newed) in resource block must be AutoCloseable.
The close() of the object will be executed when the try block exits,
  no matter an exception is thrown or not. */
class AutoClose {
	public static void main(String args[]) {
		try ( A a = new A(); ) {
			a.hello();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}							// Hello.
	}								// Goodbye!
}
//-----------------------------------------------

/* Closing files with Java7 Resources Block. */
class Java7 {
	public static void main(String args[]) {
		/* Instances defined in resource block are accessible in try-catch blocks. */
		try (
			BufferedReader br = new BufferedReader(new FileReader("index.txt"));
		) {
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
