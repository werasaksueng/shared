import java.util.*;

class Iteration {
	public static void main(String args[]) {
		final String s[] = { "John", "Jack", "Joe" };

		/* Old For-Loop. */
		for (int i = 0; i < s.length; i++)
			System.out.print(s[i] + ", ");
		System.out.println();

		/*	 External Iteration: The iteration is controlled through 'for'
	       and the action to be performed is provided by users.
		Java 5 introduced Fast For-Loop. */
		for (String x : s)
			System.out.print(x + ", ");
		System.out.println();
	
		/* For Java 'enumerate' means accessing elements in an object one at a time
		   Java 1.1 introduced Enumeration:
						javap java.util.Enumeration		*/ 
		class NameEnum implements Enumeration<String> {
			private int i = 0;
			public boolean hasMoreElements() { return i < s.length; }
			public String nextElement() { return  s[i++]; }
		}
		NameEnum ne = new NameEnum();
		while (ne.hasMoreElements())
			System.out.print(ne.nextElement() + ", ");
		System.out.println();

		/* Java 2 introduced Iterator:
						javap java.util.Iterator		*/ 
		class NameIter implements Iterator<String> {
			private int i = 0;
			public boolean hasNext() { return i < s.length; }
			public String next() { return  s[i++]; }
			public void remove() {  } // Removing element from the iterated object is rare.
		}
		NameIter ni = new NameIter();
		while (ni.hasNext())
			System.out.print(ni.next() + ", ");
		System.out.println();

		/* Java 2 also introduced Iterable, just to return an iterators.
						javap java.lang.Iterable
		To be iterated by fast for loop, the class must implement both Iterator and Iterable. */
		class Names extends NameIter implements Iterable<String> {
			public Iterator<String> iterator() { return this; }
		}
		for(String n : new Names())
            System.out.print(n + ", ");
		System.out.println();

		/* Java 5 modified all collections to implement Iterator and Iterable. */
		List<String> ls = new ArrayList<String>(Arrays.asList(s));
		for (String x : ls)
			System.out.print(x + ", ");
		System.out.println();

		/* Internal Iteration: The iteration is controlled by the object and 
		    the action to be performed is provided as a lambda(function object).
		Java 8 added forEach() to the Iterable interface.
		forEach() accepts a lambda to be performed and not return a value.
		Using 'return' just terminates the current round and continue the next.
		There is no way to terminate the rest of the forEach loop. */
		ls.forEach(x -> System.out.print(x + ", "));
	}
}
