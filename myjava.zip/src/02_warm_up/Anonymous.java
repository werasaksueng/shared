/* Anonymous classes are classes with no names.
Anonymous class must be defined and instantiated promptly.
    new <parent class>|<interface> (<args>) { <body> }     */
class A { void f() { System.out.println("A.f()"); } }
interface I { public void f(); }
class Anonymous {
	public static void main(String args[]) {
	/* Anonymous class that subclasses a class. */
		A a = new A(){
			void f() { System.out.println("a"); }
		};
		a.f();				// a

	/* Anonymous class that implements an interface. */
		I i = new I() {
			public void f() { System.out.println("i"); }
		};
		i.f();				// 1
	}
}

/* Anonymous classes do not need constructors.
But we can pass arguments the the parent class constructors. */
class AnoArg {
	static class A {
		int x;
		A(int x) { this.x = x; }
	}
   public static void main(String args[]) {
		A a = new A(1) { };
		System.out.println(a.x);		// 1
   }
}

/* An anonymous instance may refer to a variable defined in
the scope that creates the instance. But the instance can be
sent out of the scope, so the referred value is copied and
go with the instance.
That why we call the instance a closure.
   For JDK 1.7 the referred variables must be declared 'final'.
   In JDK 1.8 the referred variables are 'effectively final'
	  and not need 'final' declaration.  */
class Closure {
	static void test(A a) { a.f(); }
	public static void main(String args[]) {
		int x = 1;
		test(new A() {
			void f() {
				// ++x;    // error: x is effectively final.
				System.out.println(x);
			}
		});
		// ++x;				// error:
	}
}
/* All anonymous classes have class object like normal classes.
But anonymous classes have no names and cannot be refered to any more,
  so the classloader does not need to keep <class name>:<class object>
  and the class object can be garbage collected when the instance
  is out of scope.
Mostly anonymous class instances are passed as arguments to methods
  so that both instances and class objects can be garbage collected
  when the methods are done.
*/

