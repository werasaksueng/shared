import java.util.*;
class CollectionLiteral {
    public static void main(String[] args) {
    /* Early Java supports array literals. */
        String a[] = {"A", "B"};
        System.out.println(a);   // Object toString()
        System.out.println(Arrays.toString(a));  // [A, B]
    /* Two dimension array */
        int b[][] = {{1,2}, {3,4,5}};
        System.out.println(Arrays.deepToString(b)); // [[1, 2], [3, 4, 5]]

    /* But no collection literals e.g. list and set.
       Arrays.asList() may convert array to list, but not with array literals. */
        // List<String> lx = Arrays.asList({"John", "Jack"});  // error
        List<String> la = Arrays.asList(a);
        System.out.println(la);         // [A, B]

    /* To use a simple collection is so clumsy, it must be created empty
      and initialized one by one.
    Java 9 introduces collection factory and their toString() is improved. */
        List<String> l = List.of("john", "jack", "joe");
        System.out.println(l);      // [john, jack, joe]

        Set<Integer> s = Set.of(3, 1, 2);
        System.out.println(s);      // [1, 2, 3]

        Map<String, Double> m = Map.of("John", 1.8, "Jack", 4.0);
        System.out.println(m);      // {John=1.8, Jack=4.0}
    }
}