import java.util.*;
/* Java does not support collection literals e.g. list and set.
We must create an empty collection and explicitly add elements.
Java 9 introduces collection factory. */
class CollectionOf {
    public static void main(String[] args) {
        List<String> l = List.of("john", "jack", "joe");
        System.out.println(l);      // [john, jack, joe]

        Set<Integer> s = Set.of(3, 1, 2);
        System.out.println(s);      // [1, 2, 3]

        Map<String, Double> m = Map.of("John", 1.8, "Jack", 4.0);
        System.out.println(m);      // {John=1.8, Jack=4.0}
    }
}