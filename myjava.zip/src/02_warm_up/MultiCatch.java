/* A try block may throw more than one type of exceptions. */
class MultiCatch {
	public static void main(String args[]) {
	/* Pre-Java7: A catch block may use Exception (the base class of all 
	    exceptions) to catch all and use instanceof to check for specific. */
		try { 
			int x = Integer.parseInt(args[0]);
			System.out.println(1 / x);
		} catch (Exception ex){
			if (ex instanceof java.lang.IndexOutOfBoundsException)
				System.out.println("IndexOutOfBoundsException");
			else if (ex instanceof java.lang.NumberFormatException)
				System.out.println("NumberFormatException");
			else
				System.out.println("Something else.");
		}
	
	/* A better practice is multiple catch for each type. */ 
		try { 
			int x = Integer.parseInt(args[0]);
			System.out.println(1 / x);
		} catch (IndexOutOfBoundsException ex) {
			System.out.println("IndexOutOfBoundsException");
		} catch (NumberFormatException ex) {
			System.out.println("NumberFormatException");
		} catch (ArithmeticException ex)  {
			System.out.println("ArithmeticException");
		}

	/* Java7 introduced multiple catches in one. */
		try {
			int x = Integer.parseInt(args[0]);
			System.out.println(1 / x);
		} catch (IndexOutOfBoundsException | NumberFormatException | ArithmeticException ex) {
			System.out.println(ex.getClass());
		}
	}
}
