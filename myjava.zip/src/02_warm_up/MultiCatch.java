class MultiCatch {
	/* A try block may possibly throw more than one type of exceptions.
	public static void main(String args[]) {
	/* Pre-Java7: In case there may be many types of exceptions. */
		try {
			int x = Integer.parseInt(args[0]);
			System.out.println(1 / x);
		} catch (IndexOutOfBoundsException ex) {
			System.out.println("IndexOutOfBoundsException");
		} catch (NumberFormatException ex) {
			System.out.println("NumberFormatException");
		} catch (ArithmeticException ex)  {
			System.out.println("ArithmeticException");
		}

	/* Java7 allows catching multiple exceptions in a single catch block. */
		try {
			int x = Integer.parseInt(args[0]);
			System.out.println(1 / x);
		} catch (IndexOutOfBoundsException | NumberFormatException | ArithmeticException ex) {
			System.out.println(ex.getClass());
		}
	}
}
