class LiteralUnderscore {
	public static void main(String args[]) {
		// Java 7 allows underscore in literals to improve readability
		long a = 1234_567_89L;			// 123456789
		float b = 1_000_000.5f;			// 1000000.5
		int c = 0x00_00_00_FF;			// 255
		System.out.println(a + "\n" + b + "\n" + c);

		// Binary literals have '0b' prefix and can be assigned to integer types.
		byte x = 0b0111_1111;					// 127
		short y = 0b0111_1111_1111_1111;		// 32767
		int z = 0b11_11_11_11;					// 255
		System.out.println(x + "\n" + y + "\n" + z);
	}
}
