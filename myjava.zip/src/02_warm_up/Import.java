import java.util.Random;
import java.lang.Math;
import static java.lang.Math.sqrt;

class Import {
	public static void main(String args[]) {
	/* Explicit qualified name. */
		java.util.Date d = new java.util.Date();
		System.out.println(d);
	
	/* Import a class */
		Random r = new Random();
		System.out.println(r.nextInt());

	/* Import a class and refer to static members . 
	   All members in java.lang.Math are static. */
		System.out.println(Math.log(10));

	/* Java 5: Static import and refer to static members without class. */
		System.out.println(sqrt(4.0));
	}
}
