import static mypack.MyUtil.*;
import static java.lang.Math.sqrt;

class Import {
	public static void main(String args[]) {
	/* No import: explicit qualified name. */
		System.out.println(mypack.MyUtil.GREET);
		mypack.MyUtil.hello();
		new mypack.MyUtil.A();

	/* All members in java.lang.Math are static. */
		System.out.println(Math.log(10));

	/* Static import */
		System.out.println(GREET);
		hello();
		new A();

		System.out.println(sqrt(4.0));
	}
}
