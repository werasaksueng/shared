/* 'Overloading' is the situation when there are more than one methods
   with the same name but different parameters in the same scope.
Overloading allows reusing method name with different functionality. */
class A {
	void f() { }
	void f(int x) { }
	// int  f(int x) { }   // Return type is not concerned.
	void f(char c, double d) { }
	void f(double d, char c) { }
	void f(Object o) { }
	void f(String o) { }

	void test() {
		A a = new A();
		a.f();
		a.f(1);
		a.f('a', 1.0);
		a.f(1.0, 'a');
	}
}

/* 'Overriding' is the situation when a child class has methods with
  the same signature as methods in parent class.
Overriding allows reusing parent classes with different behaviours. */
class B {
	void f() { System.out.println("B.f()"); }
}
class C extends B {
	void f() { System.out.println("C.f()"); }
}

/* The annotation @Override tells the compiler to enforce the
  correctness of overriding for the method. */
class BB extends B {  // Using the above class B.
   @Override
	void f() { }
	// void f(int x) { }
}

/* 'Shadowing' is the situation when a child class has data members
  with the same name as in the parent class.
Shadowing allows reusing parent classes with data members of different types. */
class D {
	int x;
}
class E extends D {
	float x;
}

/* 	Shadowing VS Overriding
Access privileges:
 			private < default < protected < public

Shadowing allows less or more access privileges.
Overriding requires equal or more access privileges.  */
class F {
	int x = 1;
	void f() { System.out.println("F.f()"); }
}
class G extends F {
	private float x = 2.0f;
	// public double x = 3.0;			// Ok

	// private void f() { System.out.println("G.f()"); }	// error
	public void f() { System.out.println("G.f()"); }
}

/* Shadowing performs static binding.
While Overriding performs dynamic binding.
Check: Polymorphism.java  Binding. */

//////////////////////////////////////////////////////////////

/* A method that returns simple type cannot be overrided to
  return different type. */
class I {
	int f() { return 1; }
}
class J extends I {
	// double f() { return 1.0; }		// error
}

/* A method that returns reference type may be overrided to
  return a sub-class of the reference type. */
class X { }
class M {
	X f() { return new X(); }
}

class Y extends X { }
class N extends M {
	Y f() { return new Y(); }
}


