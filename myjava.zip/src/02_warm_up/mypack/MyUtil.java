package mypack;
public class MyUtil {
	public static final String GREET = "How are you?";
	
	public static void hello() {
		System.out.println("Hello"); }

	public static class A { }
}
