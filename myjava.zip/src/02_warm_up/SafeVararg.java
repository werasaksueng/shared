/* Vararg of parameter type is allows but not safe.
Java7 provides @SafeVarargs to suppress the warning. */
class SafeVararg {
	@SafeVarargs		// Try: comment this line.
	static <T> void f(T ...t){
		for (T x : t)
			System.out.println(x.getClass().getName());
	}

	public static void main(String args[]) {
		f(1, 2.0, '3', "4");
	}
}
