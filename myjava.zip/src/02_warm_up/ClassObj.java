/* When a class is loaded, its 'class object' is created for holding 
     information of the class.
Java provide 'Class' class for creating class objects. 
All loaded classes have only one class object.  */
class A { }
class ClassObj {
	public static void main(String[] args) {
/* <instance>.getClass() returns reference to class object of the instance.
References to class objects are normal reference.
Normally a class is loaded when it is first encountered. */
		A a = new A();
		Class<? extends A> c1 = a.getClass();
		System.out.println(c1.getName());		// A

/* forName(<class name>) where <class name> is a string, loads the class
  and returns reference to class object.
forName() allows class loading without specifying class name in the code. */
		try {
			Class<?> c2 = Class.forName("A");
			System.out.println(c2.getName());	// A
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

/* <class>.class is an operator where <class> is embedded class name.
It causes the class loading if not already loaded and return the class
  object reference.
.class is allowed to applied to simple types. ex. int.class .
It is used mostly as the class id of the class.*/
		Class<A> c3 = A.class;
		System.out.println(c3.getName());		// A
	}
}
