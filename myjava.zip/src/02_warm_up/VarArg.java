// Java 5 introduced	Variable Length Arguments.
class VarArg {
	static void f(int ...x) {
		for (int i : x)
			System.out.print(i + ", ");
		System.out.println();
	}
	public static void main(String args[]) {
		f();
		f(1);
		f(1,2);
		f(1,2,3);
	}
}
/*
VarArg type must be the last parameter.
	(int... a, int b)
No more than one VarArg parameter.
	(int... a, String... b)
No parameter with the same type before VarArg.
	(int a, int... b)
*/

/* Java 5 introduced printf().
 public java.io.PrintStream printf(java.lang.String, java.lang.Object...)
 public java.io.PrintWriter printf(java.lang.String, java.lang.Object...)
*/
class Printf {
	public static void main(String args[]) {
		String temp = "INSERT INTO %s VALUES(%d, %s, %1.1f)\n";
		System.out.printf(temp, "students", 1, "John", 1.4);
		System.out.printf(temp, "students", 2, "Jack", 4.0);
	}
}

/* The early Java does not support var-arg.
The java interpreter (java.exe) collects command line argumenets
  intro a string array and pass to the String args[]. */
class Args {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++)
			System.out.println("Hello " + args[i]);
	}
}
/*
java Args John Jack Joe
*/