class Main {
	public static void main(String[] args) {
		(new beans.Hello()).hello();
	}
/* 'class path' is a list of paths (to directories or jar files)
 where the class loader to look for classes to be loaded.
Try:   java -verbose Main >t.txt
A lot of classes are loaded when booting JVM.

Class loader in JDK1.8:
1. If no CLASSPATH, the default 'class path' is
		- %JAVA_HOME%\jre\lib\*.jar  and \ext\*.jar
		- working dirctory.

From the working dirctory.
  beans.Hello is searched from working dirctory.
javac Main.java
java Main

2. Move \beans to c:\tmp
set CLASSPATH=c:\tmp
java Main		// ClassNotFoundException: beans.Hello

If the CLASSPATH is set, 
 the working dirctory is not in 'class path' by default.
set CLASSPATH=c:\tmp;.
*** So mostly . should be included in CLASSPATH.

3. Create jar file.
cd c:\tmp
jar -cf j.jar .
jar -tf j.jar
Move j.jar to working dirctory.
set CLASSPATH=			// reset CLASSPATH
java Main				// jar file is not 'class path' by default.
set CLASSPATH=j.jar;.

2. Include jar file in CLASSPATH.
set CLASSPATH=%PATH%;m.jar;.
java Main
-----------------------------------------

Application in jar.
1. Create manifest file m.txt.
2. Move \beans back to working director.
In the working dirctory.
jar -cfm m.jar m.txt .
java -jar m.jar


Problems of Jar files:
1. By Jdk8 the standard libraries were becoming too big and clumsy 
  compared to new leaner languages.
2. The rt.jar is too big to live in Android and small iot.
3. All public classes in jars are accesible to aLL resulting security issues.
4. Classloaders can only load classes and .mf in jar files, no others.
*/
