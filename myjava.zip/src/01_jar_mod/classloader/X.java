/* The class name will be the name of the .class file.
A file may contain more than one classes.
There can be at most one public class in a file.
The public class name must be the same as the file name.

Supoose a class uses class 'Y' and the 'class loader' can not 
  find the Y.class file:
   - At runtime, a class not found error is throwed.
   - At compile time:
      -- find Y.java but not Y.class, Y.java is compiled and loaded.
      -- find Y.java and Y.class, check if is uptodate, Y.class is loaded else
      -- no Y.java, a class not found error is throwed.
*/
public class X {
    public static void main(String[] args) {

       (new Y()).print();
    }       // Try: Rename Y.java to YY.java and compile again.
}
/* It possible that a non-public class will not be the same as the file name.
But if there is one class in a file, and their names are the same
  all dependency class files will be automatically compiled.
The pitfall is the class names must be directly referred.
*/
