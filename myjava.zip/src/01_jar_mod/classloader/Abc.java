class A { }
class B { }
class C { }
class Abc {
	public static void main(String args[]) {
		A a;		  // lazy loading.
		new B();	  // B is loaded.
	}       // Try: java -verbose Abc
}
/* C++ compiles and links all classes into an executable file
     that will be loaded and executed as a whole.
Java compiles a class into separate .class file.
  - Dynamic load and link.
  - .class files can be reused without .java files.
  - Unit test. 

'class' is a compiled unit, independent class can be compiled independently.
Classes that used by others are called dependency, their .java or .class
   must be available at compile time.

There is a 'class loader' that its task are:
  - Load classes from file.
  - Creates 'class object' for each loaded class and stores stores 
      in a HashTable to be used later.
  - Look ups and returns requested classes.
Loaded class objects cannot be unloaded.
If a class is already loaded it will not be loaded again, so all 
  classes are loaded only once at the first encounter.

When a class is requested it will be looked up in the HashTable
  and returned if found, else the class will be loaded  and returned.

Class loader are used in both:
  - compile time: the class information is used for error checking.
  - execution time: the class is used for create objects.
It is possible that the 'class loader' at compile time is not the same
   as at compile time.

Class loaders can be customized for different platforms and environments.
The default one is used by javac.exe and java.exe.
*/
