class K {
    void f() {
        System.out.println("Hello I am K.");
    }
}

