class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, I am Jdk-" + System.getProperty("java.version"));

	}
}
/* 
cd C:\myjava\src\01_intro
javac Hello.java
java Hello

Since Java12:
java Hello.java
*/
