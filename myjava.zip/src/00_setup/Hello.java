class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, I am Jdk-" + System.getProperty("java.version"));
	}
}
/* Open Command Prompt
\myjava\set20
javac -version

cd C:\myjava\src\00_setup
javac Hello.java
java Hello

Since Java12:
java Hello.java
*/