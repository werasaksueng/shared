/* A 'functional' interface is an interface that defines only functions.
If an interface that defines only one method, is called a 'SAM'
 (Single Abstract Method) interface. */
import java.util.*;
import java.io.*;
import java.util.function.*;
interface MySam<P, R> {
	/* Accept a parameter of type P and return a value of type R. */
	public R compute(P p);
}
/* Java 8 introduces 'lambda' which is an instance of a function type
 that is defined by a 'lambda expression'.
A 'lambda expression' is an expression that represents a function.
			(<parameters>) ->  <body>
			<body> --> <expression> | { <block> }
A 'lambda expression' cannot have a name and cannot be generic types.
Before a 'lambda expression' can be used as a function, it must be
 bound to a sam (function type) resulting a 'lambda'.
The binding allows type checking at compile time.
When the method of the lambda is called, the body of the
 'lambda expression' is executed. */
class MySamTest {
	public static void main(String[] args) {
	/* Pre Java 8, using anonymous class. */
		MySam<Integer, Integer> sq1 = new MySam<Integer, Integer>() {
			public Integer compute(Integer n) {
				return n*n;
			}
		};
		System.out.println(sq1.compute(2));

	/* Java 8 provides lambda for creating instances of SAM interface. */
		MySam<Integer, Integer> sq2 = (Integer n) -> { return n*n; };
		System.out.println(sq2.compute(3));
	}
}

/* Binding a lambda expression to a sam:
 	- the interface must has exactly one method.
 	- the lambda parameters match the parameters of the interface method.
 	- the return type of the lambda match the return type of the interface method

Ordinary interface if has only one method can be used as a sam. */
interface Hello {
	String hello(String name);
}
class HelloTest {
	public static void main(String[] args) {
		Hello h = (String name) -> { return "Hello " + name; };
		System.out.println(h.hello("John"));
	}
}

/* Java provides @FunctionalInterface to annotate functional interfaces
  which allows compile time checking. */
@FunctionalInterface
interface Hi {
	String hi(String name);
	// String hello(String name);
}
class HiTest {
	public static void main(String[] args) {
		Hi h = (String name) -> { return "Hi " + name; };
		System.out.println(h.hi("Jack"));

	/* There are some predefined sam in the java.util.function which can be
			used as functional interfaces without defining a new. */
		Function<String, String> f = (String name) -> { return "What's up? " + name; };
		System.out.println(f.apply("Joe"));
	}
}
//-------------------------------------------------

/* The body of lambda expression may be an expression or a block.
An expression is evaluated into a value that will be returned.
A block is a sequence of statements surrounded in { and } to be executed.
Sams are classified by the types of input and output. */
class LambdaExpression {
	/* Procedure: accepts nothing, returns nothing */
	interface Procedure {
		void execute();
	}
	/* An expression and block may or may not return anything. */
	static Procedure procedure = () -> System.out.println("Hello");

	/* {} represents an empty block, 'null' is a value and
	   'void' specifies the function does not return anything. */
	static Procedure emptyProcedure = () -> {};

	/* Supplier:  accepts nothing(no parameters), returns something */
	interface Supplier {
		String get();
	}
	/* An expression value is automatically returned.
	 'return' makes it a statement, so not allowed. */
	static Supplier hello = () -> "Hello";

	/* A block may have any number of statements and returns a value. */
	static Supplier hi = () -> { System.out.println("Hello");
											return "How are you?"; };

	/* Consumer: accepts something, returns nothing */
	interface Consumer {
		void accept(String name);
	}
	static Consumer g1 =  (String name) ->
				System.out.println("Hello " + name);
	static Consumer g2 =  (String name) -> {
				System.out.println("Hello " + name);
				System.out.println("How do you do?");
			};
	/* If parameter types can be inferred from the interface,
	 they can be optional. */
	static Consumer g3 =  (name) -> System.out.println("Hi " + name);

	/* If there is only one parameter, the () can be omitted. */
	static Consumer g4 =  name -> System.out.println("What's up? " + name);

	/* Function or Operator: accepts something and returns something. */
	interface Op {
		int eval(int a, int b);
	}
	/* The result of the expression is automatically returned. */
	static Op add = (int a, int b) -> a + b;
	static Op sub = (a, b) -> a - b;		// Parameter types can be omitted.

	public static void main(String[] args) {
		procedure.execute();
		emptyProcedure.execute();

		System.out.println(hello.get());
		System.out.println(hi.get());

		g1.accept("John");
		g2.accept("Jack");
		g3.accept("Joe");
		g4.accept("Jame");

		System.out.println(add.eval(1, 2));
		System.out.println(sub.eval(1, 2));
	}
}

/* The java.util.function contains many functional types.
	Operator 	takes T, returns T.
		UnaryOperator<T> 				T apply(T)
		BinaryOperator<T> 			T apply(T, T)

	Function		takes T, returns R.
		Function<T,R> 					R apply(T)
		BiFunction<T1, T2, R> 		R apply(T1, T2)

	Predicate 	takes T, returns boolean.
		Predicate<T> 					boolean test(T)
		BiPredicate<T1, T2> 			boolean test(T1, T2)
	
	Consumer 	takes T, return nothing.
		Consumer<T> 					void accept(T)
		BiConsumer<T1, T2> 			void accept(T1, T2)

	Supplier 	takes nothing, return R.
		 Supplier<R> 					R get()  */
class FunctionalType {
	public static void main(String[] args) {
		Function<String, Integer> f = s -> Integer.parseInt(s);
		System.out.println(f.apply("123"));			// 123
		BiFunction<String, String, Integer> bf = (x, y) -> Integer.parseInt(x) + Integer.parseInt(y);
		System.out.println(bf.apply("1", "2"));	// 3
	}
}

/* There are also functional types for primitive types.
	Primitive Unary Operators 	takes primitive type, return primitive typ.
		IntUnaryOperator			int applyAsInt(int)
		LongUnaryOperator			long applyAsLong(long)
		DoubleUnaryOperator		double applyAsDouble(double)

	Primitive Binary Operators  takes two primitive type, return primitive typ.
		IntBinaryOperator			int applyAsInt(int, int)
		LongBinaryOperator		long applyAsLong(long, long)
		DoubleBinaryOperator		double applyAsDouble(double, double)

	Primitive Predicates		takes primitive type, return boolean.
		IntPredicate 				boolean apply(int)
		longPredicate 				boolean apply(long)
		DoublePredicate 			boolean apply(double)

	Primitive Consumer	takes primitive type, return nothing.
		IntConsumer<int> 			void accept(int)
		LongConsumer<long> 		void accept(long)
		DoubleConsumer<double> 	void accept(double)
		 
	Primitive Supplier	takes nothing, return primitive type.
		IntSupplier 				int getAsInt()
		LongSupplier 				long getAsLong()
		DoubleSupplier 			double getAsDouble()  */
class PrimitiveFunctionalType {
	public static void main(String[] args) {
		IntUnaryOperator iuo = (int x) -> ++x;
		System.out.println(iuo.applyAsInt(1));
	}
}

/* There are also functional types for reference types and primitive types.
	Primitive Functions		takes primitive type returns reference types.
		IntFunction<T> 			T apply(int)
		LongFunction<T> 			T apply(long)
		DoubleFunction<T> 		T apply(double) 

	To Primitive Functions	takes reference types returns primitive type.
		ToIntFunction<T> 			int applyAsInt(T)
		ToLongFunction<T> 		long apply(T)
		ToDoubleFunction<T> 		double apply(T)

	To Primitive Binary Functions
		ToIntBiFunction<T1, T2> 		int applyAsInt(T1, T2)
		ToLongBiFunction<T1, T2> 		long apply(T1, T2)
		ToDoubleBiFunction<T1, T2> 	double apply(T1, T2)
		
	Primitive To Primitive Functions
		IntToLongFunction 			long applyAsLong(int)
		IntToDoubleFunction 			double applyAsDouble(int)
		LongToIntFunction 			int applyAsInt(long)
		LongToDoubleFunction 		double applyAsDouble(double)
		DoubleToIntFunction 			int applyAsInt(double)
		DoubleToLongFunction 		long applyAsLong(double) 	*/
class ToPrimitiveFunctionalType {
	public static void main(String[] args) {
		IntFunction<String> ifs = (int x) -> x + "";
		System.out.println(ifs.apply(1) + "2");			// 12
		ToIntFunction<String> tif = (String x) -> Integer.parseInt(x);
		System.out.println(tif.applyAsInt("1") + 2);		// 3
	}
}
////////////////////////////////////////////////////////

/* Java allows using already existing methods as lambda expression:
		 		<class>::<static method>
				<instance>::<instance method>
  e.g. Using String methods.    */

class PrintlnTest {
	public static void main(String[] args) {
		/* Binding to a lambda. */
		Consumer<String> c1 = x -> System.out.println(x);
		c1.accept("Hello");				// Hello

		/* Binding to an existing method.
		The System.out is an instance of java.io.PrintStream. */
		Consumer<String> c2 = System.out::println;
		c2.accept("Hi");					// Hi
	}
}

/* Using user defined static and non-static methods. */
class A {
	static void hello(String n) { System.out.println("Hello " + n); }
	void hi(String n) { System.out.println("Hi " + n); }
}
class ATest {
	public static void main(String[] args) {
		Consumer<String> c1 = A::hello;
		c1.accept("John");			// Hello John
		Consumer<String> c2 = new A()::hi;
		c2.accept("Jack");			// Hi Jack
	}
}

/* Constructor reference:  <class>::new */
interface Factory<T, U> { T create(U u); }
interface ArrayFactory<T> { T[ ] create(int n); }
interface ListFactory<T> {	List<T> create(); }
class Student {
	String name;
	Student(String name) { this.name = name; }
	public String toString() { return name; }
}
class ConstructorRef {
	public static void main(String[] args) {
		Factory<Student, String> f = Student::new;
		Student john = f.create("John");
		System.out.println(john);

		ArrayFactory<Student> af = Student[]::new;
		Student sa[] = af.create(10);
		System.out.println(sa.length);

		ListFactory<Student> lf = ArrayList<Student>::new;
		List<Student> l = lf.create();
		System.out.println(l.size());
	}
}
