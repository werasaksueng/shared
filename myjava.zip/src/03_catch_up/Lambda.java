/* A 'functional' interface is an interface that defines only functions.
If an interface that defines only one method, is called a 'SAM'
 (Single Abstract Method) interface. */
import java.util.*;
import java.io.*;
import java.util.function.*;
interface MySam<P, R> {
	// Accept a parameter of type P and return a value of type R.
	public R compute(P p);
}
/* Java 8 introduces 'lambda' which is an instance of a function type
 that is defined by a 'lambda expression'.
A 'lambda expression' is an expression that represents a function.
			(<parameters>) ->  <body>
			<body> --> <expression> | { <block> }
A 'lambda expression' cannot have a name and cannot be generic types.
A 'lambda expression' cannot be used as a function, it must be bound
 to an instance(lambda) of a sam (function type).
The binding allows type checking at compile time.
When the method of the lambda is called, the body of the
 'lambda expression' is executed. */
class MySamTest {
// class Lambda {
	public static void main(String[] args) {
	// Pre Java 8, we use an anonymous class.
		MySam<Integer, Integer> sq1 = new MySam<Integer, Integer>() {
			public Integer compute(Integer n) {
				return n*n;
			}
		};
		System.out.println(sq1.compute(2));

	// Java 8 provides lambda for creating instances of SAM interface.
		MySam<Integer, Integer> sq2 = (Integer n) -> { return n*n; };
		System.out.println(sq2.compute(3));
	}
}

/* Binding a lambda expression to a lambda:
 	- the functional interface must has exactly one method.
 	- the lambda parameters match the parameters of the interface method.
 	- the return type of the lambda match the return type of the interface method

Ordinary SAM can be used as functional interface that is to be bound
 with a lambda expression. */
interface Hello {
	String hello(String name);
}
class HelloTest {
// class Lambda {
	public static void main(String[] args) {
		Hello h1 = (String name) -> { return "Hello " + name; };
		System.out.println(h1.hello("John"));
	}
}

/* Java provides @FunctionalInterface to annotate functional interface
  which allows compile time checking. That allows using an existing SAM
  as a functional interface.
There are some predefined sam in the java.util.function which can be
  as functional interfaces without defining a sam. */
@FunctionalInterface
interface Hi {
	String hi(String name);
	// String hello(String name);
}
class HiTest {
// class Lambda {
	public static void main(String[] args) {
		Hi h1 = (String name) -> { return "Hi " + name; };
		System.out.println(h1.hi("Jack"));

		Function<String, String> h2 = (String name) -> { return "What's up? " + name; };
		System.out.println(h2.apply("Joe"));
	}
}
//-------------------------------------------------

/* The body of lambda expression may be an expression or a block.
The expression is evaluated into a value, that is a lambda.
A block is a sequence of statements surrounded in { and }.

'lambda expression' must be corresponded to the binding sam.
Sams are classified by the types of input and output. */
class ExpressionTest {
	/* Procedure: accepts nothing, returns nothing */
	interface Procedure {
		void execute();
	}
	/* A Java expression may be a statement.
	'void' methods do not return values. */
	static Procedure procedure = () -> System.out.println("Hello");

	/* null is not an empty expression. {} represent an empty block. */
	static Procedure emptyProcedure = () -> {};

	/* Supplier:  accepts nothing, returns something */
	interface Supplier {
		String get();
	}
	/* Expression values are automatically returned, 'return' is not allowed. */
	static Supplier hello = () -> "Hello";

	/* A block may have any number of return statements,
	 but only one value is returned. */
	static Supplier hi = () -> { return "Hi"; };

	/* Consumer: accepts something, returns nothing */
	interface Consumer {
		void accept(String name);
	}
	static Consumer g1 =  (String name) ->
				System.out.println("Hello " + name);
	static Consumer g2 =  (String name) -> {
				System.out.print("Hello " + name);
				System.out.println(" how do you do?");
			};
	/* If parameter types can be inferred from the interface,
	 they can be optional. */
	static Consumer g3 =  (name) -> System.out.println("Hi " + name);

	/* If there is only one parameter, the () can be omitted. */
	static Consumer g4 =  name -> System.out.println("What's up? " + name);

	/* Function or Operator: accepts something and returns something. */
	interface Op {
		int eval(int a, int b);
	}
	/* The result of the expression is automatically returned. */
	static Op add = (int a, int b) -> a + b;
	static Op sub = (a, b) -> a - b;		// Parameter types can be omitted.

	public static void main(String[] args) {
		procedure.execute();
		emptyProcedure.execute();

		System.out.println(hello.get());
		System.out.println(hi.get());

		g1.accept("John");
		g2.accept("Jack");
		g3.accept("Joe");
		g4.accept("Jame");

		System.out.println(add.eval(1, 2));
		System.out.println(sub.eval(1, 2));
	}
}

/* The java.util.function contains many functional types.
	Operator 	takes T, returns T.
		UnaryOperator<T> 				T apply(T)
		BinaryOperator<T> 			T apply(T, T)

	Function		takes T, returns R.
		Function<T,R> 					R apply(T)
		BiFunction<T1, T2, R> 		R apply(T1, T2)

	Predicate 	takes T, returns boolean.
		Predicate<T> 					boolean test(T)
		BiPredicate<T1, T2> 			boolean test(T1, T2)
	
	Consumer 	takes T, return nothing.
		Consumer<T> 					void accept(T)
		BiConsumer<T1, T2> 			void accept(T1, T2)

	Supplier 	takes nothing, return R.
		 Supplier<R> 					R get()  */
class FunctionalType {
	public static void main(String[] args) {
		Function<String, Integer> f = s -> Integer.parseInt(s);
		System.out.println(f.apply("123"));			// 123
		BiFunction<String, String, Integer> bf = (x, y) -> Integer.parseInt(x) + Integer.parseInt(y);
		System.out.println(bf.apply("1", "2"));	// 3
	}
}

/* There are also functional types for primitive types.
	Primitive Unary Operators 	takes primitive type, return primitive typ.
		IntUnaryOperator			int applyAsInt(int)
		LongUnaryOperator			long applyAsLong(long)
		DoubleUnaryOperator		double applyAsDouble(double)

	Primitive Binary Operators  takes two primitive type, return primitive typ.
		IntBinaryOperator			int applyAsInt(int, int)
		LongBinaryOperator		long applyAsLong(long, long)
		DoubleBinaryOperator		double applyAsDouble(double, double)

	Primitive Predicates		takes primitive type, return boolean.
		IntPredicate 				boolean apply(int)
		longPredicate 				boolean apply(long)
		DoublePredicate 			boolean apply(double)

	Primitive Consumer	takes primitive type, return nothing.
		IntConsumer<int> 			void accept(int)
		LongConsumer<long> 		void accept(long)
		DoubleConsumer<double> 	void accept(double)
		 
	Primitive Supplier	takes nothing, return primitive type.
		IntSupplier 				int getAsInt()
		LongSupplier 				long getAsLong()
		DoubleSupplier 			double getAsDouble()  */
class PrimitiveFunctionalType {
	public static void main(String[] args) {
		IntUnaryOperator iuo = (int x) -> ++x;
		System.out.println(iuo.applyAsInt(1));
	}
}

/* There are also functional types for reference types and primitive types.
	Primitive Functions		takes primitive type returns reference types.
		IntFunction<T> 			T apply(int)
		LongFunction<T> 			T apply(long)
		DoubleFunction<T> 		T apply(double) 

	To Primitive Functions	takes reference types returns primitive type.
		ToIntFunction<T> 			int applyAsInt(T)
		ToLongFunction<T> 		long apply(T)
		ToDoubleFunction<T> 		double apply(T)

	To Primitive Binary Functions
		ToIntBiFunction<T1, T2> 		int applyAsInt(T1, T2)
		ToLongBiFunction<T1, T2> 		long apply(T1, T2)
		ToDoubleBiFunction<T1, T2> 	double apply(T1, T2)
		
	Primitive To Primitive Functions
		IntToLongFunction 			long applyAsLong(int)
		IntToDoubleFunction 			double applyAsDouble(int)
		LongToIntFunction 			int applyAsInt(long)
		LongToDoubleFunction 		double applyAsDouble(double)
		DoubleToIntFunction 			int applyAsInt(double)
		DoubleToLongFunction 		long applyAsLong(double) 	*/
class ToPrimitiveFunctionalType {
	public static void main(String[] args) {
		IntFunction<String> ifs = (int x) -> x + "";
		System.out.println(ifs.apply(1) + "2");			// 12
		ToIntFunction<String> tif = (String x) -> Integer.parseInt(x);
		System.out.println(tif.applyAsInt("1") + 2);		// 3
	}
}
////////////////////////////////////////////////////////

/* Lambda expressions can refer to values defined in the outer scope.
Since a lambda may be send out of it's scope, so the referred values
 are 'captured' and go with the lambda.
Local variables/objects of the scope that define the leambda
 are effectively final.  */
class Capture {
	static int g = 1;
	static IntUnaryOperator getInstance(int p) {
		int l = 1;
		return x -> x + l + p + g;
			// p and l are effectively final but x and g are not.
	}

	// To work around capturing effectively final value.
	static IntSupplier  getInstance() {
		int count[] = { 0 }; // count is effectively final, but its content is not.
		return () -> ++count[0];
	}
	public static void main(String[] args) {
		IntUnaryOperator fun = getInstance(1);
		System.out.println(fun.applyAsInt(1));
		g = 2;
		System.out.println(fun.applyAsInt(1));

		IntSupplier inc =  getInstance();
		for (int i = 0; i < 5; i++)
			System.out.print(inc.getAsInt() + ",");
	}
}
/* It is not defined in any specifications, but it is known that:
	A non-capturing lambda only needs to be evaluated once.
Since it will return an identical value for the same parameters.
But Capturing lambdas need to be evaluated every time they are encountered.
*/
///////////////////////////////////////////////////////////////

/* Java allows using already existing methods as lambda expression:
		 		<class>::<static method>
				<instance>::<instance method>
  e.g. Using String methods.    */

class PrintlnTest {
	public static void main(String[] args) {
		Consumer<String> c1 = x -> System.out.println(x);
		c1.accept("Hello");

		PrintStream ps = System.out; // new PrintStream(System.out);
		Consumer<String> c2 = ps::println;
		c2.accept("Hi");

		/* System.out is an instance of java.io.PrintStream. */
		Consumer<String> c3 = System.out::println;
		c3.accept("What's Up?");
	}
}

/* Using user defined class methods. */
class A {
	static void hello(String name) {
		System.out.println("Hello " + name);
	}
	void hi(String name) {
		System.out.println("Hi " + name);
	}
	static Consumer<String> getHello() { return A::hello; }
	Consumer<String> getHi() { return new A()::hi; }
}
class ATest {
	public static void main(String[] args) {
		A.getHello().accept("John");
		new A().getHi().accept("Jack");
	}
}

/* Constructor reference:  <class>::new */
interface Factory<T, U> {
	T create(U u);
}
interface ArrayFactory<T> {
	T[ ] create(int n);
}
interface ListFactory<T> {
	List<T> create();
}
class Student {
	String name;
	Student(String name) { this.name = name; }
	public String toString() { return name; }
}
class ConstructorRef {
	public static void main(String[] args) {
		Factory<Student, String> fac = Student::new;
		Student john = fac.create("John");
		System.out.println(john);

		ArrayFactory<Student> afac = Student[]::new;
		Student sa[] = afac.create(10);
		System.out.println(sa.length);

		ListFactory<Student> lfac = ArrayList<Student>::new;
		List<Student> l = lfac.create();
		System.out.println(l.size());
	}
}
