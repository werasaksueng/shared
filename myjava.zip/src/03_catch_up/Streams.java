import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import static java.util.stream.Collectors.toList;

/* 'Streams' are sequences of elements, with a set of 'aggregate' operations.
An 'aggregate' operation performs on all elements of input stream and passes
  results as output stream without explicit iteration controls.

Collections concern with efficiency for accessing elements.
Streams concern with efficiency for operations on elements.

Streams have no storages, it performs operation on element that comes in
  and passes result out one at a time..
Streams use less memory than collections, and normally faster since internal iteration.

Stream programming:
   1. Starting with a 'source' that provides input to be performed.
   2. Construct chain of intermediate operations to perform on data.
   3. Using a terminal operation to 'collect' or 'reduce' the result.
	Some reductions result an optional which requires unwrapping.
That allows thinking declaratively what to do on data without
 concerning with moving data and store intermediate results.  */

interface MyUtil {
	public static String names[ ] = { "John", "Jack", "Joe" };
	public static Consumer<Object> sout = s -> System.out.print(s + ",");
	public static void prints(Stream<?> s) {
		s.forEach(x -> System.out.print(x + ","));
		System.out.println();
	}
}

/* Streams of objects. */
class Create {
	public static void main(String args[]) {
	/* Stream.empty() create an empty stream. */
		Stream<?> s = Stream.empty();
		MyUtil.prints(s);

	/* Collection.stream() creates a stream from a collection. */
		List<String> ls = Arrays.asList("john", "jack");
		Stream<String> s1 = ls.stream();
		MyUtil.prints(s1);		// john,jack,

	/* Arrays.stream(<array>) creates a stream from an array. */
		Stream<String> s2 = Arrays.stream(MyUtil.names);
		MyUtil.prints(s2); 		// John,Jack,Joe,

	/* Stream.of(<vararg>) creates a stream from a arg-var. */
		Stream<String> s3 = Stream.of("Jim", "Jame", "Janet");
		MyUtil.prints(s3);		// Jim,Jame,Janet,

	/* Stream.builder() creates a stream by series of add() and finished with build(). */
		Stream<String> s4 = Stream.<String>builder().add("a").add("b").add("c").build();
		MyUtil.prints(s4);		// a,b,c

	/* Streams.generate() creates an infinite stream from a function/lamda.
	The actual number of elements should be cut off with limit().   */
		Stream<Double> s5 = Stream.generate(Math::random).limit(3);
		MyUtil.prints(s5);

	/* Stream.iterate() creates an infinite stream form an 'initial value'
	and 'update function/lambda'. */
		Stream<Integer > s6 = Stream.iterate(0, x -> ++x).limit(5);
		MyUtil.prints(s6);		// 0,1,2,3,4,

	/* Files.lines(<path>) creates a stream from <path> file. */
		try {
			Path path = Paths.get("Streams.java");
			Stream<String> s7 = Files.lines(path);
			System.out.println(s7.count());
			// MyUtil.prints(s7);
		} catch(IOException e) {
			System.out.println(e);
		}
	}
}

/* Streams of primitive types, but there are only 3 kinds:
				int, long, double. */
class PrimitiveStream {
	/* sum() is a terminal operation that sums all elements in
	 the stream and returns result as a single value. */
	public static void main(String args[]) {
		int s1 = IntStream.of(1, 2, 3).sum();
		System.out.println(s1);

		long s2 = LongStream.of(1L, 2L, 3L).sum();
		System.out.println(s2);

		double s3 = DoubleStream.of(1.0, 2.0, 3.0).sum();
		System.out.println(s3);

   /* Object streams do not have sum().
	The result of reduction object streams are optional. */
		Optional<Integer> s4 = Stream.of(1, 2, 3).reduce(Integer::sum);
		if(s4.isPresent())
			System.out.println(s4.get());

	/* Stream.mapToInt() converts stream of object to a stream of int.
	There are also mapToLong() and mapToDouble(). */
		int s5 = Stream.of(1, 2, 3).mapToInt(x -> x).sum();
		System.out.println(s5);
	}
}
//----------------------------------------------------------

/* A 'terminal' operation is the last operation on a stream.
Once a terminal is executed, the stream is "consumed".  */
class Terminals {
	public static void main(String args[]) {
	/* Stream.forEach(<consumer>) performs the <consumer> for each element. */
		Stream.of(MyUtil.names)
			.forEach(s -> System.out.print(s + ","));
		System.out.println();					// John,Jack,Joe,

	/* Stream.toArray() collects all elements into an array. */
		Object sa[ ] = Stream.of(MyUtil.names).toArray();
		System.out.println(Arrays.asList(sa));	// [John, Jack, Joe]

	/* count() reduces the number of elements into a long. */
		long c = Stream.of(MyUtil.names).count();
		System.out.println(c);					// 3

	/* min(<comparator>)/max(<comparator>) returns an option<T>.
	   get() returns the wrapped value. */
		int m = Stream.of(3, 2, 5, 6, 3, 1)
			.max(Integer::compareTo)
			.get();
		System.out.println(m);					// 6

	/* Alternatively; uses ifPresent() to do something. */
      Stream.of(1, 2, 3).min(Integer::compareTo).ifPresent(System.out::println);
   }
}

/* 'Reducers' are operations that reduce the elements into a value.
      Optional<T> reduce(BinaryOperator<T> accumulator)
	  T reduce(T identity, BinaryOperator<T> accumulator)
	  T reduce(T identity, BinaryOperator<T> accumulator, BinaryOperator<T> combiner)
*/
class Reducers {
	public static void main(String args[]) {
		System.out.println(Stream.of(1, 2, 3).reduce(Integer::sum).get());	// 6
		System.out.println(Stream.of(1, 2, 3).reduce(0, (a, b) -> a + b));	// 6
		System.out.println(Stream.of(1, 2, 3).reduce(Integer.MIN_VALUE, Integer::max)); // 3
		System.out.println(Stream.of("a", "b", "c").reduce(":", String::concat));  // :abc
	}
}

/* 'Collectors' are operations that collect the elements into a collection 
  ex. e.g. List, Set or Map. */
class Collectors {
	public static void main(String args[]) {
	/* R collect(Supplier<R> supplier,
					BiConsumer<R, ? super T> accumulator,
					BiConsumer<R, R> combiner)              */
		List<String> a = Stream.of("John", "Jack", "Joe")
				.collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
		System.out.println(a);		// [John, Jack, Joe]

	/* Collector Object:
	Collector.of() create a collector from lambdas.
	It may collect the elements into the specified type. e.g. to a string.  */
		Collector<String, StringJoiner, String> co =
   			Collector.of(
   				() -> new StringJoiner(" | "),  // supplier
   				(j, s) -> j.add(s),             // accumulator
   				(j1, j2) -> j1.merge(j2),       // combiner
   				StringJoiner::toString);        // finisher
		String s = Stream.of("John", "Jack", "Joe").collect(co);
		System.out.println(s);		// John | Jack | Joe
	}
}

/* Stream processing executes elements in the stream one by one until no more.
That allows some kind of optimization. 
A 'short-circuit' operation can stop processing elements in the stream 
  if the answer can be inferred without examining all the elements.
 ex. limit(), skip(), findAny(), findFirst(), anyMatch(), and allMatch().
But count(), min(), max(), and noneMatch() are not. */
class ShortCircuit {
	public static void main(String args[]) {
	/* findAny() returns any element of the stream, or an empty if the stream is empty. */
		System.out.println(Stream.of(2, 1, 3).findAny().get());		// 2

	/* findFirst() returns the first element, or an empty if the stream is empty.*/
		System.out.println(Stream.of(3, 1, 5, 4, 2).findFirst().get()); // 3

	/* anyMatch(<predicate>) returns a boolean 'true' if there is an element match the predicate, else returns 'false'. */
		System.out.println(Stream.of(3, 4, 1, 5).anyMatch(x -> x % 2 == 0)); // true

	/* allMatch(<predicate>) returns a boolean 'true' if all elements match the predicate, else returns 'false'. */
		System.out.println(Stream.of(3, 7, 1, 5).allMatch(x -> x % 2 != 0)); // true

	/* noneMatch(<predicate>) returns a boolean 'true' if there is no elements match the predicate, else returns 'false'. */
		System.out.println(Stream.of(3, 7, 1, 2).noneMatch(x -> x % 2 == 0)); // false
	}
}
//--------------------------------------------------------

/* 'Intermediate' are aggregate operations between 'source' and 'terminal'.
An intermediate operates on elements one at a time by take input from the left 
  and pass result to the right.
Some operations may remember state (stateful) and some may not (stateless).  */
class Intermediate {
	public static void main(String args[]) {
	/* map(<function>) applies the <function> to each elements one by one. */
		Stream.of(MyUtil.names)
			.map(s -> s.toUpperCase())
			.forEach(MyUtil.sout);			// JOHN,JACK,JOE,
		System.out.println();

	/* filter(<predicate>) applies <predicate> to each elements and allows only
	 the elements that the predicate returns true to pass through the stream. */
		Stream.of(MyUtil.names)
			.filter(s -> s.startsWith("Jo"))
			.forEach(MyUtil.sout);			// John,Joe,
		System.out.println();

	/* filter() is not a short-circuit operation. */
		Stream.of(MyUtil.names)
			.filter(s -> !s.equals("Jack"))
			.forEach(MyUtil.sout);			// John,Joe,
		System.out.println();

	/* distinct() returns a stream in the same order, except the duplicates are suppressed. */
		Stream.of(2, 4, 1, 3, 1, 1, 5, 2, 3)
			.distinct()
			.forEach(MyUtil.sout);
		System.out.println();				// 2,4,1,3,5,

	/* sorted(<comparator>) returns the stream that is sorted by the comparator. */
		Stream.of(MyUtil.names)
			.sorted(String::compareTo)
			.forEach(MyUtil.sout);			// Jack,Joe,John,
		System.out.println();

	/* limit(<number>) cuts off the stream to only <number> elements.
	It is a stateful and short-circuiting operation. */
		Stream.of( 0, 1, 2, 3, 4, 5, 6 )
			.limit(3)
			.forEach(MyUtil.sout);			// 0,1,2,
		System.out.println();

	/* skip(<number>) cuts off the first <number> elements of the stream.
	skip() is a stateful operation. */
		Stream.of( 0, 1, 2, 3, 4, 5, 6 )
			.skip(3)
			.forEach(MyUtil.sout);			// 3,4,5,6,
		System.out.println();

	/* peek(<consumer>) apply the <consumer> on each elements that pass through the stream.
		but peek() is lazy we need to force the execution by collect() or toArray() */
		Object n[] = Stream.of(MyUtil.names)
			.peek(MyUtil.sout)					// John,Jack,Joe,
			.toArray();			// .collect(Collectors.toList());
		System.out.println();
		System.out.println(Arrays.asList(n));	// [John, Jack, Joe]
	}
}

/* A lazy intermediate operator will be executed only when its result
is requested by the next operation.
Starting at the terminal each operator requests input from the left. */
class Lazy {
	public static void main(String args[]) {
		Object a[] = Stream.of(1, 2, 3)
				.peek(x -> System.out.print("before: " +  x))
				.map(x -> x * x)
				.peek(x -> System.out.println(" after: "+ x))
				.toArray();
								// before: 1 after: 1
								// before: 2 after: 4
								// before: 3 after: 9
		System.out.println(Arrays.asList(a));	// [1, 4, 9]
	}
}

/* Pruning is the process of reducing the number of operations to be performed.
		- using 'short circuit' operator.
		- reordering the operator chain.   */
class Pruning {
	public static void main(String args[]) {
		Stream.of(1, 2, 3)
			.map(x -> {
				System.out.print("\nmap: " + x + ", ");
				return x * x;
			})
			.filter(x -> {
				System.out.print("filter: " + x + ", ");
				return (x % 2) == 0;
			})
			.forEach(x -> System.out.print("forEach: " + x));
							// map: 1, filter: 1,
							// map: 2, filter: 4, forEach: 4
							// map: 3, filter: 9,
		System.out.println();

	/* The stream is pruned if performs filter before map. */
		Stream.of(1, 2, 3)
			.filter(x -> {
				System.out.print("\nfilter: " + x + ", ");
				return (x % 2) == 0;
			})
			.map(x -> {
				System.out.print("map: " + x + ", ");
				return x * x;
			})
			.forEach(x -> System.out.print("forEach: " + x));
							// filter: 1,
							// filter: 2, map: 2, forEach: 4
							// filter: 3,
	}
}

/* Normally elements are passed through a stream one at a time.
If an operation does not have to remember what elements it had performed so far,
  it is a 'stateless' operation.
 ex. filter(), map(), anyMatch(), findAny(), findFirst(), forEach(), collect().

If an operation has to remember the elements it had encountered it is a 'stateful' operation.
  ex. distinct(), skip(), limit(), sorted(), reduce().

Stateless is more efficient because it allows short-circuit and pruning. */
class Stateful {
	public static void main(String args[]) {
	/* Some stateful operations must complete the operations on all elements before
		passing to the next operation, so it behave as a data source.
	ex. sorted() is a stateful data source operation. */
		Stream.of(2, 1, 3)
			.peek(x -> System.out.print("\nbefore: " +  x))
			.sorted((x1, x2) -> {
				System.out.printf("\nsort: %s; %s", x1, x2);
				return x1.compareTo(x2);
			})
			.peek(x -> System.out.print("\nafter: " +  x))
			.forEach(s ->
					System.out.print(" forEach: " + s)
			);
						// before: 2
						// before: 1
						// before: 3
						// sort: 1; 2
						// sort: 3; 1
						// sort: 3; 2
						// after: 1 forEach: 1
						// after: 2 forEach: 2
						// after: 3 forEach: 3
		System.out.println("\n---------------------------------------------");

	/* max(), min() are stateful data source operation. */
		Stream.of(2, 5, 1, 4, 3)
			.max((x, y) ->  {
				System.out.printf("\nmax: %d; %d", x, y);
				return x - y;
			})
			.ifPresent(s ->
					System.out.print(" ifPresent: " + s)
			);
						// max: 2; 5
						// max: 5; 1
						// max: 5; 4
						// max: 5; 3 ifPresent: 5
		System.out.println("\n++++++++++++++++++++++++++++++++++++++++++++++");

	/* Some stateful operations just remember the state of the performed elements and
		pass some result to the next operation before all elements had encountered.
	These operation are calle stateful intermediate.
		ex. distinct() is stateful and allow pruning. */
		Stream.of(3, 1, 2, 2, 1, 4, 3)
			.peek(s -> System.out.print("\nbefore: " + s + ", "))
			.distinct()
			.peek(s -> System.out.print("after: " + s + ", "))
			.forEach(s -> System.out.print("forEach: " + s));
						// before: 3, after: 3, forEach: 3
						// before: 1, after: 1, forEach: 1
						// before: 2, after: 2, forEach: 2
						// before: 2,
						// before: 1,
						// before: 4, after: 4, forEach: 4
						// before: 3,			
		System.out.println("\n************************************************");

	/* There may be more than one stateful operations in a chain. */
		Stream.of(4, 2, 3, 1)
			.sorted((x1, x2) -> {
				System.out.printf("\nsort: %s; %s", x1, x2);
				return x1.compareTo(x2);
			})
			.max((x, y) ->  {
				System.out.printf("\nmax: %d; %d", x, y);
				return x - y;
			})
			.ifPresent(s -> System.out.print(" ifPresent: " + s));
						// sort: 2; 4
						// sort: 3; 2
						// sort: 3; 4
						// sort: 3; 2
						// sort: 1; 3
						// sort: 1; 2
						// max: 1; 2
						// max: 2; 3
						// max: 3; 4 ifPresent: 4
	}
}

/* Example: Math */
class SummaryStatistics {
	public static void main(String args[]) {
		IntSummaryStatistics iss = IntStream
				.of(2, 3, 5, 7, 11, 13, 17, 19)
				.summaryStatistics();
		System.out.println(iss.getMin() + ", " +
								 iss.getMax() + ", " +
								 iss.getSum() + ", " +
								 iss.getAverage() );
	}
}
class Factorial {
	static long fac(long n){
		return LongStream.rangeClosed(1, n)
      			.reduce(1, (a, b) -> a * b);
	}
	public static void main(String args[]) {
		System.out.println(fac(5));
	}
}

class Fibonacci {
	static int fib(int n) {
		if (n <= 1) 
			return n;
		else 
			return fib(n - 1) + fib(n - 2);
	}
	static void fib0(int n) {
		for (int i = 0; i < n; i++)
			System.out.print(fib(i) + ",");
		System.out.println();
	}
	static void fib1(long n){
		Stream.iterate(new int[]{0, 1}, t -> new int[]{t[1], t[0] + t[1]})
			.limit(n)
			.forEach(x -> System.out.print("{" + x[0] + "," + x[1] + "}"));
		System.out.println();
	}
	static List<Integer> fib2(long n){
		return Stream.iterate(new int[]{0, 1}, t -> new int[]{t[1], t[0] + t[1]})
			.limit(n)
			.map(p -> p[0])
			.collect(toList());
	}
	public static void main(String args[]) {
		fib0(10);
		fib1(10);
		System.out.println(fib2(10));
	}
}
