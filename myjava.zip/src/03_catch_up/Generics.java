import java.awt.Color;
import java.util.*;

/* 'Generic' is a mechanism to allow method/class to handle any types.
C++ implements generic using template, Java uses polymorhims. */
class Generics {
	static void f(Object o) {System.out.println(o); }
	public static void main(String args[]) {
	/* There are two kinds of generic:
	1. Generic Data structure is a data structure(e.g. array or stack)
	    that contains instances of any classes or a family of classes.
	2. Generic Method is a method that accepts parameters of any classes 
		     or a family of class.
	Java uses 'Object' reference to hold instances of any classes. */
		Object a[] = {Color.RED, "Hello", new Date()};
		for (Object x: a)
			f(x);
	}
}

/* Java is a 'non-pure' object-oriented language, that means
  having both simple types and reference type.
Simple type variables are not objects and cannot be assigned to
  Object reference. Therefore we cannot have array of generic simple type.
Java2 provides a solution by introcudcing 'type wrapper classes'.
 		Simple Types				Type Wrapper Classes
 			boolean						Boolean
		    byte							Byte
		    short						Short
		    char							Character
		    int							Integer
		    long							Long
		    float						Float
		    double						Double
   ex.
   			int x = 1;
   			Integer y = new Integer(x);
   			int z = y.intValue();

Java5 introduced Autobox, which is automatic wrapping simple 
  type values as needed. */
class TypeWrapper {
	public static void main(String args[]) {
	/* Java2 needs explicit type wrapping, but deprecated Java 4 */
		// Object a[] = { new Integer(1), new Character('A'), new Boolean(true)};

	/* Java5 introduced autoboxing, that is automatic wrapping. */
		Object b[] = {1, 'A', true};
		System.out.println(Arrays.asList(b));
	}
}

/* Autoboxing is proofed to be handy.
  ex.	Integer inc(Integer x) {
			int y = x.intValue();
			++y;
			return new Integer(y);
		}
*/
class AutoBox {
	static Integer inc(Integer x) {
		return ++x;
	}
	public static void main(String args[]) {
			Integer a = 1;
			System.out.println(inc(a));
	}
}

/* Syntax errors are grammar errors.
	  Ex. illegal characters, invalid variable names, unbalance begin and end.
	Semantic errors are logical errors.
	  Ex. array index out of bound, divided by zero, invalid input values

All syntax errors and some of semantic errors are detectable at compile time.
Type error is a subset of semantic errors.
If a language is designed so that all typed errors are detectable at compile time
  then we call it a strongly typed language or type safe.

Java2 introduced Collection which is a set of generic data structures that use
  Object as references, but that made Java an unsafe language. */
class TypeError {
	@SuppressWarnings("unchecked")
	public static void main(String args[]) {
		Stack s = new Stack();
		s.push(1); s.push(2);
		// s.push("1"); s.push("2");    // runtime error
		Integer a = (Integer) s.pop();
		Integer b = (Integer) s.pop();
		System.out.print(a.intValue() + b.intValue());
	}
}

/* Java5 introduced 'type safe' collections which type parameters.  */
class TypeSafe {
	public static void main(String args[]) {
		Stack<String> s = new Stack<String>();
		s.push("1");
		// s.push(2);			// compile time  error
	}
}

/* Java 5 introduced 'type safe' generic for classes and methods
  that allows 'type parameter' to worked with and type checking
  at compile time.
1. Type safe generic class.
	T is a type parameter to a class, typically a single capital letter.  */
class GenericClass {
	static class A<T> {
		T t;
		A(T t) { this.t = t; }
		public T getT() { return t; }
		public void setT(T t) { this.t = t; }
	}
	/* Type safe generic classes need type initiating so that
	  the compiler knows what the type parameter will be. */
	public static void main(String args[]) {
		A<Integer> a1 = new A<Integer>(1);
		A<String> a2 = new A<String>("Hello");
		System.out.println(a1.getT() + ", " + a2.getT());
		// a1.setT("1");			// compiler time error
		// a1 = a2;					// compiler time error
	}
}
/* 2. Type safe generic method.
Type parameters are defined before the return type.
So that they can be used as method parameters.
'extends' allows defining type relationship.  */
class GenericMethod {
	static <T, S extends T> boolean isMember(T t, S s[]) {
		for(int i = 0; i < s.length; i++)
			if(t.equals(s[i]))
				return true;
		return false;
	}
	public static void main(String args[]) {
		Integer a[] = {1,2,3,4,5};
		System.out.println(isMember(2, a));

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		System.out.println(isMember(7.0, d));
	}
}

/* Restriction for using type safe generic: */
class Restriction<T> {
	T t1;
	// T t2 = new T(); 	// Type parameter cannot be instantiated(newed).
	// static T t3;		// Type parameter must not be static
	// static T getT() { return t1; }
	 						  // static method cannot access type parameter

	T a[];	// It's ok to define a reference to array of type parameter
	// a = new T[10];	// But cannot create an array of type parameter
}

/* To simplify type safe generic collection defintions. */
class Diamond {
	public static void main(String args[]) {
	/* Pre-Java7: both left and right hand sides must be
	    explicit type parameterized.  */
		List<String> a = new ArrayList<String>();
		a.add("Helo");
 
	/* Java7 allowed implicit type on the left side, default is <Object>
	  if the right side has type parameterized. */
		List c = new ArrayList<String>();
	/* Implicit type on the right side is allowed with warning. */
		// List<String> x = new ArrayList();  // warned

	/* Java7 introduces <>, diamond operator.
	    <> allows type inference, no need to repeat the type parameter. */
		List<String> b = new ArrayList<>();   // Try: remove <>.
		b.add("Hi");
		// b.add(1);	// error:

	/* Java9 introduces anonymous class with diamond operator. */
		List<String> l = new ArrayList<>(){ };
	}
}

/* Wildcard generic <?> is for specifying any types. But can be used 
 only in cases type parameters can be inferred by compiler from 
 assignment or passing. */
class Wildcard {
	static class NumberArray<T extends Number> {
		private T t[];
		NumberArray(T t[]) { this.t = t; }
		public double average() {
			double s = 0.0;
			for (T x : t)
				s += x.doubleValue();
			return s / t.length;
		}
		boolean sameAvg(NumberArray<?> na) {
			return (average() == na.average())? true : false;
		}
	}
	public static void main(String args[]) {
		Integer i[] = {1,2,3,4,5};
		NumberArray<?> ia = new NumberArray<>(i);
		System.out.println(ia.average());

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		NumberArray<?> da = new NumberArray<>(d);
		System.out.println(da.average());

		System.out.println(ia.sameAvg(da));
	}
}

/* Java10 type inference allows declaration without explicit type. */
class TypeInference {
   public static void main(String args[]) {
   /* 'var' instance/variable must be:
         - local scope, not allowed for parameters.
         - initiallized with value of known type at compile time.  */
      var x = 1;
      System.out.println(x);

      var y = 1.0/2;
      System.out.println(y);

   /* 'null' type cannot be inferred. */
      // var z = null;     // error:

   /* Generic type must be explicitly defined with type parameters. */
      var list = new ArrayList<String>();
      list.add("Hello"); list.add("Hi");
   }
}
