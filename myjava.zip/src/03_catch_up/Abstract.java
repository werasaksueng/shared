/* A function(or method) consists of 
	- head (specification)
	- body (implementation).

C++ 'Virtual function' is a function that has no bodys.
	e.g	 class A {
				public: virtual void f() = 0;
			};

Java: 'Abstract method' is a method that has no bodys.
It has just specification but no implementation.

If a class contains at least one abstract method
 then the class must be abstract, but not vice versa.
'Abstract class' is a class defined with 'abstarct' keyword. */
abstract class X { }

/* Abstract classes cannot be used for creating an instance.
An abstract class may contain normal members(data and methods).
Abstract classes are used for defining 'non-pure specification'.  */
abstract class A {
	int x = 1;
	abstract public void f();
	abstract public void h();
	public void g() { System.out.println("g: " + x); }
}
class Abstract {
	public static void main(String args[]) {
		A a;
		// new A();
	}
}

class AImpl extends A {
  	public void f() { System.out.println("f"); }
	public void h() { System.out.println("h"); }
}
class AImplTest {
	public static void main(String args[]) {
		A a = new B();
		a.f();
		a.h();
	}
}

/* Boundary, service or utility classes do not contain state and 
  should not be used to create instance. 
'abstract' is an effective way for making a class un-newable.
A class with only private constructors is un-newable. 
But it is also un-extendable. */
 abstract class MyMath{
 	static public final double PI = 3.1415;
 	static public double sq(double n) { return n * n; }
}
class MyMathTest {
	static public void main(String args[]) {
		System.out.println(MyMath.sq(MyMath.PI));
	}
 }

 /* Using abstract class as specification. */
abstract class Spec {
	abstract public String hello(String name);
	abstract public String hi(String name);
	public static void test(Spec sp) {
		String name = "John";
		if (sp.hello(name).equals("Hello "+name) &&
		    sp.hi(name).equals("Hi "+name))
			System.out.println("Ok");
	}
}
class Impl extends Spec {
	public String hello(String name) {
		return "Hello "+name;
	}
	public String hi(String name) {
		return "Hi "+name;
	}
}
class SpecTest {
	public static void main(String args[]) {
		 Spec.test(new Impl());
	}
}
///////////////////////////////////////////////////////////

/* Pre-Java8 Interface
Interfaces are 'pure' specification. */
interface I1 {
	/* All members are public by defulat.
	All data members must be static, final, and initialized. */
	// int x;						// error
	static final int y = 1;

	/* All method members must be abstract and cannot be static. */
	// void f() { }					// error
	abstract void g();
}

/* Testing the default. */
interface I2 {
	int x = 1;		// public static final by default
	void f();		// public abstract by default
}
//--------------------------------------------------

/* Java 8 interfaces allows:
	1. Default method.
	2. Static methods.
That allows using interfaces as 'non-pure' specifications. */
interface I8 {
	default void f() { System.out.println("default"); }
	static public void g() { System.out.println("static"); }
}
/* Interfaces are specification and can be used as types.
Implementation means making the specification usable.
A class that implements an interface inherited the
  specification into its class and behaves a sub-type
  of the type(interface). */
class I8Impl implements I8 { }
class I8Test {
	public static void main(String args[]) {
		I8Impl i = new I8Impl();
		i.f();					// default

	/* g() is belong to interface I8, not class I8Impl. */
		I8.g();					// static
		// I8Impl.g();		// error
	}
}

/* Extension and Implementation rules.
1. A class may extend exactly one parent class (default is Object).
2. A class may implement any number of interface (including none).

class A { }
interface I { }
interface J { }
class B extends A implements I, J { }						*/

/* 3. Interfaces can be extened, the result is an interface
  with possibly more specification.

interface I { void f(); }
interface J extends I { void g(); }							 */

/* 4. An interfaces can be partialliy implemented(not all methods
 implemented), the result is an abtract class. e.g.

interface I { void f(); void g(); }
abstract class A implements I { public void f(){} }
class B extends A { public void g(){} }						*/

//-------------------------------------------------------

/* Java 8 Rules of Interface Implementation:
 1. If the parent class and the interface have the same method, 
  the 'class win'.

class A { public void f() { System.out.println("A.f"); } }
interface I { default void f() { System.out.println("I.f"); } }
class B extends A implements I { }
class Rule1 {
	public static void test() {
		new B().f();				// A.f
	}
}
*/

/* 2. If both interfaces have the same default methods,
  the class must implements its own. e.g.

interface I { default void f() { System.out.println("I.f()"); } }
interface J { default void f() { System.out.println("J.f()"); } }
class A implements I, J {
  public void f() { System.out.println("A.f()"); }
}
*/

/* 3. A method cannot be both abstract and default method in
the same interface. e.g.

interface I {
	public abstract void f();
	// default public void f() { System.out.println("K8.f"); }
}
*/

/* 4. An extended interface can implement abstract methods of the
 parent interface as default methods. e.g.

interface I { void f(); }
interface J extends I {
	default public void f() { System.out.println("J.f"); }
}
*/

//----------------------------------------------------------

/* Java11 introduces private method in interfaces. */
interface I11 {
   private void f() {
      System.out.println("private");
   }
   private static void g() {
      System.out.println("private static");
   }

	/* Private methods are visible only within the interface. */
   default void h() {
      f();
      I11.g();
   }
}
//--------------------------------------------------------

/* 'Companion' classes and 'Utility' methods are for working with 
      a class that implements an interface. */
class PreJava8Companion {
	interface A {
		public int get();
		public A add(int x);
	}
	static class AImpl implements A {
		private int x;
		AImpl(int x) { this.x = x; }
		public int get() { return x; }

/* Static method members of a class that can access private state directly. */
		public A add(int x) {
			return new AImpl(x + this.x);
		}
	}
	/* A companion class is a separated class designed to handle 
	    a class, it needs to access private state via setter/getter. */
	static class AComp {
		public static A add(A a1, A a2) {
			return new AImpl(a1.get() + a2.get());
		}
	}

	public static void main(String args[]) {
		A a1 = new AImpl(1);
		A a2 = a1.add(1);
		System.out.println(AComp.add(a1, a2).get());
	}
}

/* Java 8: Using interface static methods, companion needs
 not to be a separated class but included in the interface. */
class Java8Companion {
	interface A {
		public int get();
		static public A add(A a1, A a2) {
			return new AImpl(a1.get() + a2.get());
		}
	}
	static class AImpl implements A {
		private int x;
		AImpl(int x) { this.x = x; }
		public int get() { return x; }
	}

	public static void main(String args[]) {
		A a1 = new AImpl(1);
		A a2 = new AImpl(2);
		System.out.println(A.add(a1, a2).get());
	}
}

