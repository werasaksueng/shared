import java.util.Optional;
import java.util.NoSuchElementException;
import java.util.Objects;

/* Null references is the most costly semantic error.
In Java using null references causes a NullPointerException. */
class NullExcept {
	public static void main(String args[]) {
		String s = "Hello";
		s = null;
		System.out.println(s.length());
	}
}

/*	Java 8 offers 'Optional' to deal with NullPointerException.
Optional<T> is a wrapper class for class T that may or may not contain a value. */
class NullWrapper {
	public static void main(String args[]) {
	/* <T> Optional<T> empty(): Returns an empty Optional T. */
		Optional<String> o1 = Optional.empty(); // optional string with no value.
		System.out.println(o1);		// Optional.empty

	/* <T> Optional<T> of(T value): Returns an Optional T containing a value. */
		// Optional<String> on = Optional.of(null); // runtime error
		Optional<String> o2 = Optional.of("Hello"); // parameter must be non-null
		System.out.println(o2);		// Optional[Hello]

	/* <T> Optional<T> ofNullable(T value):
		If the value is non-null, it returns an Optional containing the value.
		If the value is null, it returns an empty Optional.
		So It does not matter if the parameters are null or not. */
		Optional<String> o3 = Optional.ofNullable(null);
		System.out.println(o3);		// Optional.empty

		Optional<String> o4 = Optional.ofNullable("Hello");
		System.out.println(o4);		// Optional[Hello]
	}
}

/* We use Optional just to prevent calling methods on the instance
  that may cause NullPointerException.
We cannot call methods of the wrapped class on the instance of Optional.
It imposes a practice that to use an Optional:
	- Check if it has a value.
	- If it has, unwrap and handle the value.
	- Else reports error or do something.     */
class CheckAndUnWrap {
	public static void main(String args[]) {
		Optional<String> n = Optional.ofNullable(null);
		Optional<String> h = Optional.ofNullable("Hello");

	/* An optional string is not a String, but toString() is allowed.
	It can be appended (+), the result is an optional string.
	Calling toString() on empty optional string does not causes error. */
		System.out.println(n + " John");  // Optional.empty John
		System.out.println(h + " Jack");  // Optional[Hello] Jack

	/* To access the wrapped value we need an unwrapping method:
			get()   returns the wrapped value of the optional.  */
		System.out.println(h.get());		// Hello

	/* Unwrapping an empty optional causes a NoSuchElementException. */
		try {
			System.out.println(n.get());
		} catch (NoSuchElementException ex ) {
			System.out.println("No value");		// No value
		}

	/*  Using try-catch is clumsy and less efficient, if-else is better.
	isPresent() can determine if an optional has a value. */
		if (n.isPresent())
			System.out.println(n.get());
		else
			System.out.println("No value");		// No value

		if (h.isPresent())
			System.out.println(h.get());			// Hello
		else
			System.out.println("No value");

/* Using if-statement when accessing optional values is so awkward.
Java 8 provides 4 alternatives to handle the situation.

   1. orElse(<default>) return the default value if the optional has no value.
	   So we do not need the if statement and isPresent(). */
		System.out.println(n.orElse("Hi"));		// Hi
		System.out.println(h.orElse("Hi"));		// Hello

/* 2. ifPresent(<Function>) performs the <Function> if the the optional has a value. */
		n.ifPresent(x -> System.out.println(x + " John"));
		h.ifPresent(x -> System.out.println(x + " Jack"));	// Hello Jack

/* 3. orElseGet(<Supplier>) returns the value of <Supplier> if the the optional has no value. */
		System.out.println(n.orElseGet(() -> "Hi"));		// Hi
		System.out.println(h.orElseGet(() -> "Hi"));		// Hello

/* 4. orElseThrow(<Exception>) returns the value if the the optional has a value, else throws the <Exception>. */
		try {
			System.out.println(n.orElseThrow(Exception::new));
		} catch (Exception ex ) {
			System.out.println("Empty");			// Empty
		}
		try {
			System.out.println(h.orElseThrow(Exception::new));	// Hello
		} catch (Exception ex ) {
			System.out.println("Empty");
		}
	}
}

/* When we create and use an instance we should certainly know it has value or not? 
But if an instance is returned from a method, we should never assume it has value.
So from now on, Java 8 forces you to deal with optionals.
Optionals add layer of complexity since a lot of library methods return optional. */
class OptionalReturned {
	static Optional<String> hello(String name) {
		if (name.equals("John"))
			return Optional.empty();
		return Optional.of("Hello " + name);
	}

	public static void main(String args[]) {
		Optional<String> os = hello("John");
		if (os.isPresent())
			System.out.println(os.get());

		os = hello("Jack");
		if (os.isPresent())
			System.out.println(os.get());	// Hello Jack

		System.out.println(hello("John").orElse("Hi Joe")); // Hi Joe
		System.out.println(hello("Jame").orElse("Hi Joe")); // Hello Jame

		hello("Jeff").ifPresent(System.out::println);	// Hello Jeff
	}
}

/* Java7 introduce a service class 'java.util.Objects' for null-safe operations.
All Object's contract methods should be forward to these methods. */
class NullSafeObject {
	public static void main(String args[]) {
		class A {
			Integer x;
			A(Integer x) { this.x = x; }
			public boolean equals(Object o) {
				return (o instanceof A) && x.equals(((A) o).x);
			}
		}
		A a1 = new A(null);
		A a2 = new A(null);
		// System.out.println(a1.equals(a2));   // error:

		class B {
			Integer x;
			B(Integer x) { this.x = x; }
			public boolean equals(Object o) {
				return Objects.equals(x, ((B)o).x);
			}
		}
		B b1 = new B(null);
		B b2 = new B(null);
		System.out.println(b1.equals(b2));   // true
	}
}
