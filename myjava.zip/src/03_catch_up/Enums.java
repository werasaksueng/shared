/* C enum: is a type of possible values.
   ex. 'day' type has seven values.
		typedef enum {sun, mon, tue, wed, thu, fri, sat} day;
	The type allows:
		day i, d;        // Declare variables.
		d = fri;         // Assignment.
		if (d == fir)    // Comparision.
		switch(d) {      // Branching switcher.
			case mon :
			case tue :
			case wed :
			case thu :
			case fri : printf("workday\n"); break;
			case sun :
			case sat : printf("holiday\n"); break;
		}
		for (i = sun; i <= sat; i++)	// Iteration.
			printf("%d\n", i);

C compiler encodes enum's values as contant int.
So a 'day' variable can be handled as int, that is unsafe,
 since they are supposed to be value of day. */

/* Java interfaces can used for defining enums.
All interface data memebers are implicitly constants.
Each value must be explicitly defined, but may be of any types.

A Constant Type  is a type of possible values that are of a type.
If the real type is not serious, 'int' is used for efficiency.
But this approach is still type unsafe and may have name conflict.  */
class TypedConstant{
	interface Suit {
		public static final int CLUBS = 0;
		public static final int DIAMONDS = 1;
		public static final int HEARTS = 2;
		public static final int SPADES = 3;
	}
	public static void main(String args[]) {
		int s = Suit.CLUBS;
	/* 's' can be assigned, compared, branched, iterated as 'int'. */
	}
}

/* Joshua Bloch (Effective Java) proposed an implementation of type safe Enum.
That means the enum values can only be applied with the defined methods.  */
class TypeSafeEnum {
	static class Suit {
		private final String suit;
		private Suit(String s) { suit = s; }
		public String toString() { return suit; }

		public static final Suit CLUBS = new Suit("Clubs");
		public static final Suit DIAMONDS = new Suit("Diamonds");
		public static final Suit HEARTS = new Suit("Hearts");
		public static final Suit SPADES = new Suit("Spades");
		private static final Suit[] suitArray = { CLUBS, DIAMONDS, HEARTS, SPADES };
		public static Suit[] values() { return (Suit []) suitArray.clone(); }
	}
/* Try:
	  enum Suit { clubs, diamonds, hearts, spades }
 */
	public static void main(String args[]) {
		for (Suit s : Suit.values())
			System.out.print(s + ", ");
	}
}
/* Type safe enum provides sets of constants that are type safe and immutable.
If the class has a private constructor, the enumeration is unextensible.
If the class has a non-private constructor, the enumeration is extensible.
Multiple parties can extend the enumeration without knowledge
 of one another, and their extensions will never confict.

We can create our own enum using 'enum' by sub-classing java.lang.Enum.

public abstract class java.lang.Enum extends java.lang.Object implements java.lang.Comparable,java.io.Serializable{
    public final java.lang.String name();
    public final int ordinal();
    protected java.lang.Enum(java.lang.String, int);
    public java.lang.String toString();
    public final boolean equals(java.lang.Object);
    public final int hashCode();
    protected final java.lang.Object clone()       throws java.lang.CloneNotSupportedException;
    public final int compareTo(java.lang.Enum);
    public final java.lang.Class getDeclaringClass();
    public static java.lang.Enum valueOf(java.lang.Class, java.lang.String);
    public int compareTo(java.lang.Object);
} */
class MyEnum {
	enum MySuit {
	/* Define 'symbol' and 'value'. */
		clubs('c'), diamonds('d'), hearts('h'), spades('s');

		private char symbol;
		MySuit(char symbol) { this.symbol = symbol; }
		public char getSymbol() { return symbol; }
	}
	
	public static void main(String args[]) {
		MySuit s = MySuit.diamonds;
		System.out.println(s.getSymbol());		// d
		System.out.println(s.ordinal());			// 1
		System.out.println(s.toString());		// diamonds
	/* map */		
		System.out.println(MySuit.valueOf("spades"));	// spades

	/* compare */
		System.out.println(s == MySuit.spades);			// false
		System.out.println(s.compareTo(MySuit.spades));	// -2

	/* iterate */
		for(MySuit x : MySuit.values())
			System.out.print(x + ","); // clubs,diamonds,hearts,spades

	/* branch */
		switch(s) {
			case clubs :	System.out.println("Clubs"); break;
			case diamonds:	System.out.println("Diamonds"); break;
			case hearts:	System.out.println("Hearts"); break;
			case spades:	System.out.println("Spades");
		}
	}
}
