import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.function.*;
/* Java 8, forEach() has been added to the Iterable interface,
   which is a super-interface of Collection. So all Collection
   objects can be forEach().   */
class ForEach {
	public static void main(String[] args) {
		java.util.List<String> a = Arrays.asList("John", "Jack", "Joe");
	/* Internal Iteration: The users delegate the 'loop' control to the
	 library and provide a functional to be performed at each iterations. */
		a.forEach(x -> System.out.print(x + ","));
		System.out.println();
	}
}

/* Lambdas has changed many programming practice in Java.
Ex. Programming Threads.   */ 
class Greet {
	public static void hello() {
		System.out.println("Hello");
	}
}
class ThreadEx {
	public static void main(String[] args) {
	/* Anonymous Class */
		Runnable ano = new Runnable(){
			public void run() { Greet.hello(); }
		};
		new Thread(ano).start();

	/* Lambda */
		Runnable lam = () -> Greet.hello();
	   new Thread(lam).start();

	/* Method reference */
		Runnable mr = Greet::hello;
		new Thread(mr).start();
	}
}

/* Ex. String Comparators */
class ComparatorEx {
	public static void main(String[] args) {
		String a[] = {"John", "Jack", "Joe", "Jim", "Jame"};

		/* lambda comparator  */
		String a1[] = a.clone();
		Arrays.sort(a1, (x, y) -> x.compareTo(y));
		System.out.println(Arrays.asList(a1));

		/* Method reference comparator */
		String a2[] = a.clone();
		Arrays.sort(a2, String::compareTo);
		System.out.println(Arrays.asList(a2));
	}
}

/* Ex. Action Listener for GUI. */
class ActionListenerEx {
	public static void test() {
		JButton bt = new JButton("Greet");

	/* Anonymous class */
	/*	bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Hello!");
			}
		});
	*/

	/* Lambda */
		bt.addActionListener(e -> System.out.println("Hi!"));
		JFrame jf = new JFrame("Lambda Listener");
		jf.add(bt, BorderLayout.CENTER);
		jf.pack();
		jf.setVisible(true);
	}
}

