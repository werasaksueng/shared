/* In Java 8, forEach() has been added to the Iterable interface,
  which is a super-interface of Collection. So all Collection
  objects can be forEach().   */
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.function.*;
class ForEach {
	public static void main(String[] args) {
		java.util.List<String> a = Arrays.asList("John", "Jack", "Joe");

	/* External Iteration: The users control the iteration through 'for'
	 which uses the iteration method provided by the class of the object. */
		for(String x : a)
			System.out.print(x + ",");
		System.out.println();

	/* Internal Iteration: The users delegate the 'loop' control to the
	 library and provide a functional to be performed at each iterations. */
		a.forEach(x -> System.out.print(x + ","));
		System.out.println();

	/* External iteration concerns with 'how' to iterate and 'what' to do
	with each iteration. While internal iteration concern only with 'what'.
	The library can optimize iteration performance by using laziness,
	parallelism, and out-of-order execution. None of these is user concern.

	Using 'return' just terminates the current iteration and continue the next.
	There is no way to terminate the rest of forEach loop.
	forEach accepts a consumer lambda, so it cannot return a value. */
		a.forEach(x -> {
			if (x.equals("Jack"))
				return;
			System.out.println("Hi " + x);
		});
		System.out.println();
	}
}

/* forEach() increases performance of passing result between loops.  */
class MyMath {
	static int dou(int x) {			// 'double' is a keyword.
		return x + x;
	}
	static int sq(int x) {
		return x * x;
	}
	static IntUnaryOperator getDouble() { return MyMath::dou; }
	static IntUnaryOperator getSq() { return MyMath::sq; }
}
class Composition {
	public static void main(String[] args) {
		/* Explicit loops need to store intermediate results. */
		java.util.List <Integer> a = Arrays.asList(1, 2, 3);
		java.util.List<Integer> a1 = new ArrayList<Integer>();
		for (Integer x : a)
			a1.add(MyMath.dou(x));

		java.util.List<Integer> a2 = new ArrayList<Integer>();
		for (Integer x : a1)
			a2.add(MyMath.sq(x));

		for (Integer x : a2)
			System.out.print(x  + ", ");
		System.out.println();

		/* forEach() allows composition more than one functions
		 without storing intermediate result. */
		a.forEach(x -> System.out.print(MyMath.getSq().applyAsInt(
												  MyMath.getDouble().applyAsInt(x)) + ", "));
	}
}

/* Lambdas has changed many programming practice in Java.
Ex. Programming Threads.   */ 
class ThreadEx {
	static class Greet {
		public static void hello() {
			System.out.println("Hello");
		}
	}
	public static void main(String[] args) {
	/* Anonymous Class */
		Runnable ano = new Runnable(){
			public void run() { Greet.hello(); }
		};
		new Thread(ano).start();

	/* Lambda */
		Runnable lam = () -> Greet.hello();
	   new Thread(lam).start();

	/* Method reference */
		Runnable mr = Greet::hello;
		new Thread(mr).start();
	}
}

/* Ex. String Comparators */
class ComparatorEx {
	public static void main(String[] args) {
		String a[] = {"John", "Jack", "Joe", "Jim", "Jame"};

		/* Passing a lambda comparator. */
		String a1[] = a.clone();
		Arrays.sort(a1, (x, y) -> x.compareTo(y));
		System.out.println(Arrays.asList(a1));

		String a2[] = a.clone();
		Arrays.sort(a2, String::compareTo);
		System.out.println(Arrays.asList(a2));
	}
}

/* Ex. Action Listener for GUI. */
class ActionListenerEx {
	public static void test() {
		JButton bt = new JButton("Greet");

	/* Anonymous class */
	/*	bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Hello!");
			}
		});
	*/

	/* Lambda */
		bt.addActionListener(e -> System.out.println("Hi!"));
		JFrame jf = new JFrame("Lambda Listener");
		jf.add(bt, BorderLayout.CENTER);
		jf.pack();
		jf.setVisible(true);
	}
}

