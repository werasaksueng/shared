import java.util.concurrent.*;
import java.util.function.Supplier;
import java.util.stream.*;

/* Java 7: A 'FutureTask' provides asynchronous calls.
A 'Callable' is an instance that can be executed by a future task.
A future task executed a callable with a newly created thread, 
  and may continue working on something while checks for the result. */
class MyCallable implements Callable<String> {
	public String call() throws Exception {
		IntStream.range(0, 3).forEach(n -> {
			System.out.println(n + ": " + Thread.currentThread().getName());
			try { Thread.sleep(1);} catch(Exception e) { }
		} );
		return "Finish."; 
	}
}
class AsynJava7 {
	public static void main(String args[]) {
		/* Wrap MyCallable in a FutureTask. */
		FutureTask<String> fc = new FutureTask<>(new MyCallable());

		/* Create a thread to execute the FutureTask. */
		new Thread(fc).start();

		/* Repeatedly check and wait for the result.*/
		while (true) {
			try {
				if(fc.isDone()){
					System.out.print(fc.get());  // get the result returned by the future task
					break;
				}
				System.out.println("Doing something: " + Thread.currentThread().getName());
				Thread.sleep(100);
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
	}
}

/* Java 8: CompletableFuture simplify asynchronous call and get the result.
It executes a lambda instead of a callable.
A worker thread is created explicitly.
No loop for checking the result. */
class AsynJava8 {
	public static void main(String args[]) throws InterruptedException, ExecutionException, TimeoutException {
		CompletableFuture<String> cf = CompletableFuture.supplyAsync( // Supplier<String>
			() -> {
				for (int n = 0; n < 3; n++) {
					System.out.println(n + ": " + Thread.currentThread().getName());
					try { Thread.sleep(500); } catch(Exception ex) { }
				}
				return "Finish.";
			});

		/* getNow(<fallback>): if the result is not present yet, the fallback value is returned. */
		System.out.println("getNow:  " + cf.getNow("Hi"));

		/* get(<time>, <time uint>): waits x time units, then tries to get the result,
			if no value, a TimeoutException is thrown. */
		try {
			System.out.println("get 1: " + cf.get(1, TimeUnit.SECONDS ) );
		} catch(TimeoutException ex) {
			System.out.println("get 1: Timeout");
		}
		System.out.println("get 5: " + cf.get(5, TimeUnit.SECONDS ) );

		/* get() waits for ever until the CompletableFuture is completed or cancelled. */
		// System.out.println("get:  " + cf.get());
	}
}
