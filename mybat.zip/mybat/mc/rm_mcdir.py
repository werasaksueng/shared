import shutil
mc_dir = 'C:/Users/THAIMART/AppData/Roaming/MultiChain'
try:
	shutil.rmtree(mc_dir)
	print('Delete MultiChain dir success.')
except OSError as e:
        print(e)
