import shutil
try:
	shutil.rmtree('C:\mycrypto\etc\geth_\Ethereum')
except OSError as e:
        print(e)
print('Delete success.')