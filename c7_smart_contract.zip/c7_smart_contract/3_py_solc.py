''' Now we can work with Solidity compiler using Python.

'py-solc-x' is a Python wrapper for 'solc'.
It supports Solidity versions >=0.4.11
	https://solcx.readthedocs.io/en/latest/

## To install py-solc-x:
pip install py-solc-x
'''
from solcx import install_solc   
# print(install_solc(version='0.8.14'))  ## Try: version='latest' 
## Check C:\Users\<User>\.solcx   Just delete to uninstall.

## We may need helper functions from web3 to work with py-solc-x. 
## pip install web3
from web3.auto import w3
# print(w3.is_connected())	## Try: Without starting Ganache.
#--------------------------------------------------------------

''' Compile Smart Contracts with py-solc-x: 
      Ex. .\contracts\Storage.sol

'pragma' declares the version of the solidity to be used.
pragma solidity ^0.8.14;          ## ^ Minimum version.
pragma solidity >=0.7.0 <0.9.0;   ## Range version.
'''
## For read/write files:
def read_file(fname):
    with open(fname, 'r') as f:
        return f.read()
def write_file(fname, data):
    with open(fname, 'w') as f:
        f.write(data)
        
from solcx import compile_source
from pprint import pprint
def compile(file, solc_version='0.8.14'):
    ## Assume contract files are in '\contracts' directory.
    ## The contract name is the same the file (without .sol)
    code = read_file('contracts/'+ file + '.sol')

    ## Compile:
    compiled = compile_source(code,
          output_values=['abi', 'bin'],
          solc_version=solc_version)
    print('Key:', compiled.keys())
    #  pprint(compiled)

    ## Extract abi and bin
    res = compiled['<stdin>:'+file]
    abi = res['abi']
    bin = res['bin']
    # print(abi); print(bin)

    ## Save:
    write_file('contracts/'+ file + '.abi', w3.to_json(abi))
    write_file('contracts/'+ file + '.bin', bin)
    print('Success')
# compile('Storage')   ## Check: Storage.abi and Storage.bin
# compile('Faucet')    ## Try:

## To read 'abi' and 'bin':
def read_abi_bin(fname):
    abi = read_file('contracts/'+ fname + '.abi')
    bin = read_file('contracts/'+ fname + '.bin')
    return abi, bin
st_abi, st_bin = read_abi_bin('Storage')
# print(st_abi)
# print(st_bin)

## A contract object(undeployed) can be created from abi and bin.
## An undeployed contract can be tested by listing its functions. 
def test_contract(abi, bin):
    ## Create a contract object using abi and bin.
    co = w3.eth.contract(abi=abi, bytecode=bin)

    ## List the object functions.
    [ print(f.fn_name) for f in co.all_functions()]
# test_contract(st_abi, st_bin)
#---------------------------------------------------------------------

## Deploy a contract:
## Start Ganache.
from web3 import Web3
# w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
# john = w3.eth.accounts[0]
# jack = w3.eth.accounts[1]

## Check john and jack balances:
# print(w3.eth.get_balance(john), w3.eth.get_balance(jack))

## Send a deploy contract tx:
def deploy(sender_addr, abi, bin):
    ## Create a contract object.
    cobj = w3.eth.contract(abi=abi, bytecode=bin)

    ## Deploy the contract object.
    tx_hash = cobj.constructor().transact({'from': sender_addr}).hex()

    ## Waiting for tx receipt (returns a dict).
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return tx_receipt['contractAddress']

## Suppose John deploys 'Storage' contract.
# st_addr = deploy(john, st_abi, st_bin)
# print(st_addr)	## Check: Ganache transaction and contract address.
st_addr = '0x316B9d12e70500AC181a57E458c5DA1E2884b168'

## A deployed contract will have address and balance.
## To verify if the contract is deployed successfully.
# w3.eth_get_code(<addr>) Get the bytecode at the address, success if not empty. '''
# print(w3.eth.get_code(st_addr))

## Check John pays gas for sending the deploy tx.
# print(w3.eth.get_balance(john))

## Check the contract balance, should be zero for now.
# print(w3.eth.get_balance(st_addr))

## To interact with contract functions we need the contract reference.
## Getting a contract reference by contract address and abi.
def get_ref(addr, abi):
    return w3.eth.contract(address=addr, abi=abi)

## List the deployed contract functions.
# st_ref = get_ref(st_addr, st_abi)
# [print(f.fn_name) for f in st_ref.all_functions()]

''' Calling a contract function with 'auto sign' tx.
For no side effect functios, no gas needed.
     <contract ref>.functions.<function name>(<args>).call() '''
# print(st_ref.functions.retrieve().call()) ## 0 if not stored yet.

''' For side effect functions, the caller pay gas.
 <contract ref>.functions.<function name>(<args>).transact(<tx data>)
The tx hash is returned.
<tx data> may contains the tx sender address.
The stored value overwrite the old value.

Ex. John calls store() with value 1.  '''
# print(st_ref.functions.store(1).transact({'from': john}).hex()) 

## Check the side effect:
# print(st_ref.functions.retrieve().call())  ## 1 overwrite 0

## Check: John pays gas for sending the tx.
# print(w3.eth.get_balance(john))
#-------------------------------------------------------

''' Raw 'invocation' tx:
Ganache supports both auto sign and raw tx.
Infura does not support wallets so no auto-sign tx.

Auto sign automatically computes gas but usually pay more than enough.
Raw tx allows more control but not alway success (if not enough gass).
Raw tx need sender private key and recent Blockchain information. '''
def get_info(user_addr):
    cid = w3.eth.chain_id
    nonce = w3.eth.get_transaction_count(user_addr)
    block = w3.eth.get_block("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, currGas

## Get: John private key from Ganache.
john_priv = 'deefc3c907fd2e9dfc71f028906dab43be4fd8dedee24451865c78b429377329'

def raw_store(sender, sender_priv, ref, value):
    ## Get info with john address.
    cid, nonce, currGas = get_info(sender)
    # print(cid, nonce, currGas)

    ## Create raw tx (unsigned yet).
    ##  <contract ref>.functions.<func name>(<args>).build_transaction(<tx data>)
    tx = ref.functions.store(value).build_transaction({
        'chainId': cid, 'nonce': nonce, 
        'gas': "0x21000", 'gasPrice': currGas
    })
    # print(tx)

    ## Sign and send tx.
    signed_tx = w3.eth.account.sign_transaction(tx, sender_priv)
    return w3.eth.send_raw_transaction(signed_tx.raw_transaction).hex()
## Ex. John calls store(2).
# print(raw_store(john, john_priv, st_ref, 2))

## Check the side effect.
# print(st_ref.functions.retrieve().call())

