''' 'brownie' is a developer tool for smart contract development,
  similar to 'truffle' but uss Python.

pip install eth-brownie		## Python 3.9.x - 3.11.x

brownie --version 

Using Brownie with Ganache:   start Ganache
Brownie Console is a client similar to 'bitcoin-cli'.
brownie console	   ## Connect to 127.0.0.1:8545 by default.
>>> web3.client_version

'brownie' supports wallet services.
Accounts are stored at:
    C:/Users/<username>/brownie/accounts

## Ganache provides pre-created accounts (with balances).
>>> accounts
>>> accounts[0].address		## str
>>> accounts[0].balance()	## in wei

## WEI -> ETH
>>> b = accounts[0].balance()
>>> web3.from_wei(b, 'ether')

## Create a new account (no pre-funding).
>>> accounts.add()	## Try: check accounts.

## 'brownie' supports create/send tx but does not charge gas.
## 'Ganache' auto-commits all txs, but not the ETH Blockchain.
## Ex. Transfer 1 WEI from accounts[0] to accounts[1]
>>> accounts[0].transfer(accounts[1], "100") ## in wei
>>> accounts[0].balance()
>>> accounts[1].balance()
>>> exit()
#------------------------------------------------------
''' Runing 'brownie' lib in standalone app.
When the 'brownie' lib is imported. 
Several helpful objects are preloaded:
    accounts, network, config, project, chain, history, web3.
    'Contract' for interact with deployed contracts (given ABI + address) 
    'rpc' for interact with local Blockchain (dev and Ganache).
    Compiled contracts are available by name.
'''
from brownie import *
from pprint import pprint
# pprint(config)

## To check networks that can be connected to:
## brownie networks list

## Initially no networks connected.
## A Blockchain at '127.0.0.1:8545' can be connected with 'development'.
# network.connect('development')
# [print(a, a.balance()) for a in accounts]
#------------------------------------------------------

## 'Brownie project' simplifies intialization and directory organization.
brownie init myapp		## Create a project:
cd myapp

## 'scripts' contains script files, 'tests' contains test files.
## 'contracts' contains smart contract files.
## Copy myscript.py to myapp\scripts
## Run a brownie script in command line (in the project dir).
brownie run myscript.py
## A brownie scripe must have main() as the starting point.
## Brownie does not allow file and directory names that start with digits.
#------------------------------------------------------

## Brownie Testing:
## Test files and test function names must start with 'test'
## There can be many test functions and files.
## Copy test_my.py to myapp\tests
brownie test

## A project is deleted by removing the project dirctory.
#------------------------------------------------------

## Brownie project and smart contracts:
	Ex. storage_ex

## Create project:
brownie init stApp
cd stApp

## Copy Storage.sol to stApp\contracts
brownie compile
    result: \stapp\build\contracts\Storage.json
## Try: changing version and compile again.
      pragma solidity 0.8.17;

## Copy stscript.py to stApp\scripts
brownie run stscript.py	
'''



