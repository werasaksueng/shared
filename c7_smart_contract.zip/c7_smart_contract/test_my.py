## Preloaded objects can be passed as parameters.
def test_1(accounts):
    assert len(accounts) == 3

## A function name does not start with 'test', it will be exculded from testing.
def xtest_2(accounts):
    assert accounts[0].balance() == 99999999999999999999


