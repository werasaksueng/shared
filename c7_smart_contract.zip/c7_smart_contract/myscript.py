from brownie import *

## Connect to Ganache by default.
def list_accounts():
    for a in accounts:
        print(a, a.balance())

def transfer():
    print(accounts[0].transfer(accounts[1], "1"))
    print(accounts[0].balance())
    print(accounts[1].balance())

def main():
    list_accounts()
    # transfer()


