print('Hello')
