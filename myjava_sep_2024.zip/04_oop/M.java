class A { 
	// private A()  { this(0); System.out.println("A"); }
	A(int x)  { System.out.println("A: " + x); }
}
class B extends A {
	// B()  { super(); }
	// B()  { this(0); System.out.println("B"); }
	B(int x)  { super(x); System.out.println("B: " + x); }
}
class M {
	public static void main(String args[]) {
		new B(1);
	}
}