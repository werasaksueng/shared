/* java.lang.Object is the root(top-most) class.
All classes are descendants of the 'Object' class.
The 'Object' class has some members and inherited to all classes.
There must be some guardian rules for using those inherited members. */

import java.util.*;

/* toString():
If the parameter of System.out.print() or System.out.println(a) is
	- a simple type it will be converted into String then sent out.
	- a String then it will be sent to System.out.
	- an instance, that is not String, its toString() will be called 
	and the result is sent out.

java.lang.Object provides the default implmentation of toString()
  that shows its class name and the instance address.
All entity classes should override toString() to show the instance state. */
class ToString {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) {
			this.id = id; this.name = name;
		}
		public String toString() { return id + "," + name; }
	}

	public static void main(String args[]) {
		System.out.println(new Student(123, "John Rambo"));	// 123,John Rambo

	/* Standard lib classes have toString() implemented. */
		System.out.println(new String("Hello"));			// Hello
	}
}

/* Operator == (comparison) 
	- Simple types compare by value. 
   - Reference types compare by reference.
The java.lang.Object provides equals() for object comparison but
  its default implementation compares by reference.
Mostly we override equals() to provide the semantics for instance equality.

There are some kinds of objects that will not be compared
  and do not need to override equals().
    e.g. non-entity objects and function-thread objects.
But if the equals() should never be invoked at all, then the equals()
  should be overrided to throw UnsupportedOperationException. */
class Equals {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) {
			this.id = id; this.name = name;
		}
		// Mostly the objects primary key (id) are compared.
		public boolean equals(Object o) {
			if (o != null && o instanceof Student) {
				Student s = (Student) o;
				if (id == s.id)
					return true;
			}
			return false;
		}
	}

	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		Student b = new Student(123, "John Rambo");
		System.out.println(a == b);			// false
		System.out.println(a.equals(b));		// true

		String x = new String("Hello");
		String y = new String("Hello");
		System.out.println(x == y);			// false
		System.out.println(x.equals(y));		// true

		/* Java provides string pool. */ 
		String m = "Hello";
		String n = "Hello";
		System.out.println(m == n); 			// true
	}
}

/* java.lang.Object provides hasCode() for hashing
 the instances of the class.

Whenever hashCode() is invoked on the same object,
  it must return the same integer value. But the result 
  need not to be the same from execution to execution.

If two objects are equal according to equals(),
  then the hashCode() must return the same value.
hashCode() should be computed from the object states
  that used by equals().
The default hashCode() returns the instance address. */
class HashTest {
	static class A { }
	public static void main(String args[]) {
		System.out.println(new A().hashCode());
		System.out.println(new A().hashCode());

		System.out.println(new Object().hashCode());
	}		
}
class HashCode {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) { this.id = id; this.name = name; }
		public int hashCode() { return id; }

		/* Try: without equals() */
		// public boolean equals(Object o) {
		// 	if (o != null && o instanceof Student) {
		// 		Student s = (Student) o;
		// 		if (id == s.id)
		// 			return true;
		// 	}
		// 	return false;
		// }
	}

	public static void main(String args[]) {
		Map<Student, String> h = new HashMap<Student, String>();
		h.put(new Student(123, "John Rambo"), "BadGuy");
		System.out.println(h.get(new Student(123, "John Rambo")));

		System.out.println(new String("Hello").hashCode());
		System.out.println(new String("Hello").hashCode());
	}
}

/* Before an object is garbage collected, its finalize() is called.
 We should override finalize() to provide the last action if needed.
We cannot determine when an object will be a garbage and it can take
 a long time for a garbage to be collected and if the JVM stops ruptly
 some garbages will not be collected. There is no guarantee that
 finalize() will be executed.
  - Nothing time-critical should ever be done by finalize().
  - Never depend on finalize() to update critical persistent state.

 There are only two valid uses of finalize():
	- To act as a "safety net" in case the users of the object
forget to call the explicit termination methods. e.g. InputStream,
OutputStream and Timer have finalize()
	- To garbage collect an instance that uses native code,
because it is not a normal object, the garbage collector
doesn't know about its memory usage.

In case a class needs to perform a post-active activity.
Define an explicit termination method. Ex.
			 class A {
				........
				public void stop() {
					// perform post-active activity
				}
			}
 Ex.
		java.util.Timer.cancel()
		java.awt.Graphics.dispose()
		java.awt.Window.dispose()
		java.awt.Image.flush()
*/
class Finalize {
	static class A {	 // finalize() is deprecated.
		A() { System.out.println("Hello"); }
		protected void finalize() throws Throwable {
			System.out.println("Bye");
		}
	}

	public static void main(String args[]) {
		A a = new A();
		System.gc();		// request the gc to execute promptly.
	}
}
