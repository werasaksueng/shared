package com.b;

import com.a.A;

class D extends A {
	public void print() { 
		System.out.println(y + ", " + z); 
	}
}

class E {
	A a = new A();
	public void print() {
		System.out.println(a.z);
	}
}
/*	Visibility must be detremined with class relationship and package.

											Visibility Modifiers
									private		defaul	protected public
Same Class Same Package		   yes		 yes		  yes		  yes
Sub Class Same Package		   no		 	yes		  yes		  yes
User Class Same Package	   	no		 	yes		  yes		  yes
Sub Class Other Package	  	   no		 	no		  	  yes		  yes
Other Class Other Package	   no		 	no		  	  no		  yes
*/