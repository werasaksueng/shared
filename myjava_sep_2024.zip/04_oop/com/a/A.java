package com.a;

/* Same classes. */
public class A { 
	private int w = 1;
	int x = 2;
	protected int y = 3;
	public int z = 4;
	static public int s = 5;

	int get_W() { return w; }
}

/* Sub class and Same package. */
class B extends A {
	public void f() {
	/* Private members are inherited but not accessible. */
		// System.out.println(w);			//error
		System.out.println(get_W());	

	/* Non-private and static member are inherited. */
		System.out.println(x + ", " + y + ", " + z + ", " + s);
	}
}

/* User class and Same package. */
class C {
	A a = new A();
	public void f() {
		System.out.println(a.x + ", " + a.y + ", " + a.z + ", " + A.s);
	}
}

