/* 'Shadowing' is the situation when a child class has data members
  with the same name as the parent class data members.
Type and value may be different.

'Overriding' is the situation where a child class has method members
  with the same header as method members in parent class. 
*/
class A {
	int x = 1;
	void f() { System.out.println("A"); }
}

class B extends A {
	float x = 2.0f;							   // shadow

/* @Override tells the compiler to enforce the correctness
 of overriding for the method. */
	@Override
	void f() { System.out.println("B"); }			// override
	void f(int x) { System.out.println("x"); }	// overload
}
class ShadowOverride {
	public static void main(String args[]) {
		B b = new B();
		System.out.println(b.x);		// 2.0
		b.f();							// B
	}
}
//----------------------------------------------------------

/* Shadowing allows less or more access privileges.
   Overriding requires equal or more access privileges.
Access privileges:
 			private < default < protected < public    */
class C {
	int x = 1;
	void f() { System.out.println("C"); }
}
class E extends C {
	private float x = 2.0f;
	// public double x = 3.0;			// Ok

	// private void f() { System.out.println("E"); }	// error
	public void f() { System.out.println("E"); }
}
//---------------------------------------------------

/* A method that returns simple type cannot be overrided to
  return different type. */
class F {
	int f() { return 1; }
}
class G extends F {
	// double f() { return 1.0; }		// error
}

/* A method that returns reference type may be overrided to
  return a sub-class of the reference type. */
class X { }
class M {
	X f() { return new X(); }
}

class Y extends X { }
class N extends M {
	Y f() { return new Y(); }
}
