
/* Interfaces may have a lot of methods and hard to implement. */
interface I {
	void f1();
	void f2();
	void f3();
}

/* Suppose it is hard to implement all the methods, and some methods
      may never used at all. e.g. we need only f1(). */
class Implementation {
	static class Impl implements I {
		public void f1() { System.out.println("f1"); }
		public void f2() {}
		public void f3() {}
	}
	public static void main(String args[]) {
		new Impl().f1();			// f1
	}
}

/* 'Adapter Classes' are abstract classes that provide empty implementations
     for all the methods of an interface.  e.g.
			java.awt.event.WindowAdapter
			java.awt.event.KeyAdapter
			java.awt.event.ComponentAdapter
			org.xml.sax.helpers.ParserAdapter        */
class AdapterClass {
	static abstract class IAdaptor implements I {
		public void f1() {}
		public void f2() {}
		public void f3() {}
	}
	static class Impl extends IAdaptor {
		public void f1() { System.out.println("f1"); }
	}
	public static void main(String args[]) {
		new Impl().f1();				// f1
	}
}

 /* 'Abstract Adapter Classes' provide default implementations
      which are not empty for some the methods of the interface. e.g.
			java.util.AbstractList
			java.util.AbstractSet
			javax.swing.AbstractAction

Suppose the default implementations of f1() and f2() are provided. */
class AbstractAdapter {
	static abstract class AbstractI implements I {
		public void f1() { System.out.println("f1"); }
		public void f2() { System.out.println("f2"); }
		abstract public void f3();
	}
	static class Impl extends AbstractI {
		public void f3() { System.out.println("f3"); }
	}
	public static void main(String args[]) {
		Impl i = new Impl();
		i.f1(); i.f2(); i.f3();
	}
}

/* 'Simple(or Default) Adapter Classes' provide default simple implementations 
      for all the methods of the interface. e.g.
			java.beans.SimpleBeanInfo
			com.sun.media.sound.SimpleInputDevice
			java.text.SimpleTextBoundary
			sun.security.validator.SimpleValidator
			java.util.SimpleTimeZone

			javax.swing.DefaultListModel
			javax.swing.table.DefaultTableModel
			org.xml.sax.helpers.DefaultHandler  				*/
class SimpleClass {
	static class SimpleI implements I {
		public void f1() { System.out.println("f1"); }
		public void f2() { System.out.println("f2"); }
		public void f3() { System.out.println("f3"); }
	}
	static class Impl extends SimpleI {  // override only the unfitted
		public void f1() { System.out.println("F1"); }
	}
	public static void main(String args[]) {
		Impl i = new Impl();
		i.f1(); i.f2(); i.f3();
	}
}

/* Java 8 can implement adaptors, abstract, and simple in the interface.  */
class Java8Adapter {
	interface I {
		default public void f1() { }
		default public void f2() { }
		default public void f3() { }
	}
	static class Impl implements I {
		public void f1() { System.out.println("Hello"); }
	}
	public static void main(String args[]) {
		Impl i = new Impl();
		i.f1(); i.f2(); i.f3();
	}
}

