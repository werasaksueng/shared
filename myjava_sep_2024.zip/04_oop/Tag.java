import java.util.*;

/* 'instanceof' is an operator for testing if an instance is of a type 
     which may be class or interface. */
class Instanceof {
	static class A { }
	static class B extends A { }

	interface I { }
	static class Impl implements I { }

	public static void main(String args[]) {
		A a = new A();
		B b = new B();
		Impl i = new Impl();
		System.out.println( a instanceof A );		// true
		System.out.println( b instanceof A );		// true
		System.out.println( i instanceof I );		// true
	}
}

/* Tag(or Marker) interfaces are for specify privileges or permission
    to all instances of the class.
By convention, tag interfaces that grant permission are end with 'able'. */
class GreetTag {
	interface Greetable { }
	static abstract class Human {
		abstract public String getName();
	}
	static class John extends Human {
		public String getName() { return "John"; }
	}
	static class Jack extends Human implements Greetable {
		public String getName() { return "Jack"; }
	}

	static void greet(Human h) {
		if (h instanceof Greetable)
			System.out.println("Hello! " + h.getName());
	}
	public static void main(String args[]) {
		greet(new Jack());
		greet(new John());
	}
}
//-----------------------------------------------------------

/* A sequence is a collection of order-oriented elements.
C++ Iterator allows iterating a sequence without knowing internal representation. 
	  	list<int> l;
	  	list<int>::iterator i;
	  	for (i = l.begin(); i != l.end(); i++)
	  		cout << *i << ","; 

Enumerate means handing out one element at time.
Java 'Enumeration' interface specifies that objects of the class can be enumerated.
	public interface java.util.Enumeration<E> {
		public abstract boolean hasMoreElements();
		public abstract E nextElement();
		public default java.util.Iterator<E> asIterator();
	}
 */
class EnumerationTag {
	static class MyEnumeration implements Enumeration<String> {
		private int i = 0;
		private static String a[] = { "John", "Jack", "Joe" };
		public boolean hasMoreElements() { return i < a.length; }
		public String nextElement() { return  a[i++]; }
	}
	public static void main(String args[]) {
		MyEnumeration e = new MyEnumeration();
		while (e.hasMoreElements())
			System.out.print(e.nextElement() + ", ");
	}
}

/* Java 1.2 introduced 'Iterator' interface which more meaningful name changed.
	public interface java.util.Iterator<E> {
		public abstract boolean hasNext();
		public abstract E next();
		public default void remove();
		public default void forEachRemaining(java.util.function.Consumer<? super E>);
	}
*/
class IteratorTag {
	static class MyIterator implements Iterator<String> {
		private int i = 0;
		private static  String a[] = { "John", "Jack", "Joe" };
		public boolean hasNext() { return i < a.length; }
		public String next() { return  a[i++]; }
		// public void remove() { }
		// Removing element from the underlying collection is rare.
	}
 	public static void main(String args[]) {
		MyIterator i = new MyIterator();
		while (i.hasNext())
			System.out.print(i.next() + ", ");
	}
}

/* java.lang.Iterable is an interface to specify that the class has 
     an iterator for iterating the sequence.
		public interface java.lang.Iterable<T> {
			public abstract java.util.Iterator<T> iterator();
			public default void forEach(java.util.function.Consumer<? super T>);
			public default java.util.Spliterator<T> spliterator();
		}
To made an iterator object supports fast for loop, it must implement
  'Iterator' and 'Iterable', which iterator() just return 'this'.  */
class IterableTag {
	static class C implements Iterator<String>, Iterable<String> {
		private int i = 0;
		private static  String a[] = { "John", "Jack", "Joe" };
		public boolean hasNext() { return i < a.length; }
		public String next() { return  a[i++]; }
		// public void remove() { }
		public Iterator<String> iterator() { return this; }
	}
	public static void main(String args[]) {
		for(String s : new C())
			System.out.print(s + ", ");
	}
}
//------------------------------------------------------------------

/*  Cloning:
java.lang.Object defines clone() for copy by value the instance.
  - bitwise copy the instance (without using constructor) very efficient 
     but shallow copy.
  - It is 'protected', if need to call as 'public' it must be overided.
  - Cloning instance is not safe, therefore this clone() checks if the 
      class has permission(to be cloned) by implementing Cloneable.
    If the class does not implement Cloneable throws CloneNotSupportException.

The Object's clone() can do the job nicely so mostly it is implemented as:
			super.clone()
It must be overrided if special semantic is needed.
   
clone() contracts:
	1. x is a cloneable object.
	2. x.clone() != x must be true.
	3. x.clone().getClass() == x.getClass() should be true but not required.
	4. x.clone().equals(x) should be true but not required.
*/
class CloneTag {
	static class Student implements Cloneable {
		private int id;
		private String name;
		Student(int id, String name) {
			this.id = id; this.name = name;
		}
		public void setName(String n) { name = n; }
		public String toString() { return id + "," + name; }

		public Object clone() throws CloneNotSupportedException {
			return super.clone();
		}
	}
	public static void main(String args[]) {
		Student s1 = new Student(1, "John");
		try {
			Student s2 = (Student) s1.clone();
			System.out.println(s1 + ", " + s2);
		} catch(CloneNotSupportedException e) {
			System.out.println(e);
		}
	}
}
