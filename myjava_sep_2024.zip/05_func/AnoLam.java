/*	  Anonymous Classes VS Lambda Expressions
- Anonymous classes may have any number of methods.
  Lambda expression has only one method.

- Anonymous classes must explicitly declare the method's parameters and return type.
  Lambda expressions allow the method's parameters type and return type to be inferred.

- Anonymous classes are compiled into a separate .class file and loaded (at runtime)
  into a class object.
  Lambda expressions do not have a separate class. The Java compiler converts them
into private method of the class and uses invoke dynamic instruction that was added
in Java 7 to bind this method dynamically.

- Method binding for anonymous class instances must be dynamic, since some methods may be
defined in the parent classes.
  Method binding for lambdas can be static, since the method is defined in the class
where the lambda expression is defined.
			**** lambda is more efficient and uses less memory. ****    */
class AnoLam {
	public static void main(String[] args) {
		/* The java.lang.Runnable that defines Java Thread is a SAM.
					public interface Runnable {
				 		public abstract void run();
				 	}
		*/
		Runnable r1 = new Runnable() {
			@Override
			public void run() {
				System.out.println("Anonymous class.");
			}
		};
		r1.run();

		Runnable r2 = () -> { System.out.println("Lambda Expression."); };
		r2.run();

// ------------------------------------------------------------------------------------

	/* Anonymous class definition introduces a new scope that creates another
	environment during runtime. Lambda expression does not create a new scope.	*/
		int x = 1;
		Runnable r3 = new Runnable() {
			int x = 2;
			@Override
			public void run() {
				int x = 3;
				System.out.println(this.x + ", " + x);		// 2, 3
			}
		};
		r3.run();

		Runnable r4 = () -> {
				// int x = 5;	// error: x is already defined in main().
				int y = 1;		// Add to the scope of main().
				System.out.println(y);
		};
		r4.run();

// ------------------------------------------------------------------------------------

	/* In anonymous class, 'this' is resolved to the anonymous class instance,
	whereas 'this' in lambda expression is resolved to the enclosing class
	instance where the lambda is defined.	*/
		Runnable r5 = new Runnable() {
			@Override
			public void run() {
				System.out.println(this.getClass().getName());
			}
		};
		r5.run();

	 	// main() is static, refering to 'this' is an error.
		Runnable r6 = () -> {
			// System.out.println(this.getClass().getName());		// error
			System.out.println(new AnoLam().getClass().getName());
		};
		r6.run();
	}
}
/* Serialization for anonymous class instance is highly discouraged.
   Serialization for lambda is allowed, only if its parameters and
   return type are Serializable. So lambda is good for RMI.
 */
