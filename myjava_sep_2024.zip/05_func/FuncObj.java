import java.util.*;
import java.text.*;

/* A 'function object' is an instance that contains functions(methods).
Mostly function objects do not have state (stateless).
Function objects can be freely passed between scopes. */
interface Op {
	public int eval(int x, int y);
	static int run(int []a, Op op) {
		int r = a[0];
		for (int i = 1; i < a.length; i++)
			r = op.eval(r, a[i]);
		return r;
	}
}
class Plus implements Op {
	public int eval(int x, int y) { return x + y; }
}
class Mul implements Op {
	public int eval(int x, int y) { return x * y; }
}
class OpObject {
	public static void main(String args[]) {
		int [] a = new int[] {1, 2, 3, 4, 5};
		System.out.println(Op.run(a, new Plus()));
		System.out.println(Op.run(a, new Mul()));

/* If 'Plus' class is rarely used, anonymous class is better. */
		System.out.println(Op.run(a, new Op(){
			public int eval(int x, int y) { return x + y; }
		}));
	}
}

/* Function objects are called functionals or first-class objects:
		1. Dynamically created.
		2. Stored as objects and may be in collections.
		3. Passed and returned from functions. */
interface Inc {
	int inc(int n);
}
class Functional {
	static void run(Inc f, int x) {
		System.out.println(f.inc(x));
	}
	static Inc getInc(int x) {
		return new Inc(){
			public int inc(int n) { return x+n; }
		};
	}

	public static void main(String args[]) {
	/* Dynamic Create */
		Inc i = new Inc() { public int inc(int n) { return ++n; } };

	/* It can be executed as a function. */
		System.out.println(i.inc(1));

	/* It can be passed as a parameter to other functions(or methods).*/
		run(i, 1);

	/* It can be created and sent out of a function as a return value.*/
		System.out.println(getInc(2).inc(1));

	/* It can be stored in an array or a collections. */
		Inc [ ] ia = { getInc(1), getInc(2), getInc(3) };
		for (Inc x : ia)
			System.out.print(x.inc(1) + ",");
	}
}

/* Quick Sort utilities needs a comparator that defines how to compare.
       e.g.       sort(<sequence>, <comparator>)
The comparator is a function objects that may be defined as separated
 classes or defined as member of the class.
java.util.Comparator is an interface to define the class that implements
  compare() for comparing the elements.    */
class SortComparator {
	static class A {
		int x;
		A(int x) { this.x = x; }
		public String toString() { return "" + x; }
		static class ByValueComparator implements Comparator<A> {
			public int compare(A a1, A a2) {
				return a1.x - a2.x;
			}
		}
	}
	public static void main(String args[]) {
		A a[] = {new A(2), new A(1), new A(3)};
		Arrays.sort(a, new A.ByValueComparator());
		System.out.println(Arrays.asList(a));
   }
}

/* java.lang.Comparable is an interface that allows the class
 to be the comparator of itself. But there can be only one
 way to compare the elements. */
class SortComparable {
	static class A implements Comparable<A> {
		int x;
		A(int x) { this.x = x; }
		public String toString() { return "" + x; }
		public int compareTo(A a) {
			return x - a.x;
		}
	}
	public static void main(String args[]) {
		A a[] = {new A(2), new A(1), new A(3)};
		Arrays.sort(a);  // No need to pass a comparator.
		System.out.println(Arrays.asList(a));
	}
}

/* Time Sort:
Suppose a time object contains only hour, minute and second.
Time comparators must give priority to the most significant to the less. */
class TimeSort {
	static class Time implements Comparable<Time> {
		private int hour, minute, second;	// no error check for simplicity.
		Time(int h, int m, int s) {	hour = h; minute = m; second = s; }
		public String toString() { return hour + ":" + minute + ":" + second; }

		public int compareTo(Time t) {
			int hDif = hour - t.hour;
			if (hDif != 0)
				return hDif;
			int mDif = minute - t.minute;
			if (mDif != 0)
				return mDif;
			return  second - t.second;
		}
	}
	public static void main(String args[]) {
		Time []t = { new Time(8, 10, 00),
					    new Time(2, 30, 11),
					    new Time(6, 45, 50) };
		Arrays.sort(t);
		System.out.println(Arrays.asList(t));
	}
}

// String Sort:
class StringSort {
	public static void main(String args[]) {
		String [] s = {"aa", "bb", "aA", "a", "AA", "ab", "AB", "BB", "Bb", "B", "Aa"};

	/* String class has compareTo() to compare unicode value of the strings. */
		String [] s1 = (String [])s.clone();
		Arrays.sort(s1);				// In-place
		System.out.println(Arrays.asList(s1));

	/* String has the CASE_INSENSITIVE_ORDER comparator. */
		String [] s2 = (String [])s.clone();
		Arrays.sort(s2, String.CASE_INSENSITIVE_ORDER);
		System.out.println(Arrays.asList(s2));

	/* java.text.Collator has text comparator for each Local. */
		String [] s3 = (String [])s.clone();
		Arrays.sort(s3, Collator.getInstance(Locale.US));
		System.out.println(Arrays.asList(s3));

	/* Define anonymous class for string comparator by length. */
		String [] s4 = (String [])s.clone();
		Arrays.sort(s4, new Comparator<String>() {
			public int compare(String s1, String s2) {
				return s1.length() - s2.length();
			}
		});
		System.out.println(Arrays.asList(s3));
	}
}
