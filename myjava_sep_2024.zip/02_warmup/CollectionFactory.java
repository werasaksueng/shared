import java.util.*;
/* Java does not support collection literals.
To create a simple list or set, it must be
  uninitialize created and add elements later.
Java 9 introduces collection factory. */
class CollectionFactory {
    public static void main(String[] args) {
        List<String> l = List.of("john", "jack", "joe");
        System.out.println(l);      // [john, jack, joe]

        Set<Integer> s = Set.of(3, 1, 1, 2);
        System.out.println(s);      // [1, 2, 3]
    }
}