/* Java allowsusing memory as streams.
   		ByteArrayInputStream
 		ByteArrayOutputStream

		CharArrayReader
		CharArrayWriter

		StringReader
		StringWriter       */

import java.io.*;
class MemoryStream {
	public static void main(String args[]) throws IOException {
	/* Byte Array Atream */
		byte b[] = {72, 101, 108, 108, 111};
		ByteArrayInputStream bai = new ByteArrayInputStream(b);
		ByteArrayOutputStream bao = new ByteArrayOutputStream();
		int x;
		while ((x = bai.read()) != -1)
			bao.write(x);
		bai.close(); 
		bao.close();
		// bao.writeTo(System.out);
		System.out.println(new String(bao.toByteArray(),0,5));

	/* Char Array Stream */
		char c[] = {'H','e','l','l','o'};
		CharArrayReader car = new CharArrayReader(c);
		CharArrayWriter caw = new CharArrayWriter();
		while ((x = car.read()) != -1)
			caw.write(x);
		car.close(); caw.close();
		System.out.println(caw.toString());

	/* String Stream */
		String s = "Hello";
		StringReader sr = new StringReader(s);
		StringWriter sw = new StringWriter();
		while ((x = sr.read()) != -1)
			sw.write(x);
		sr.close(); sw.close();
		System.out.println(sw.toString());
	}
}
