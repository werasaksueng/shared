/*  File Byte Streams:
		FileInputStream
		FileOutputStream

	File Char Streams:
		FileReader
		FileWriter    */

import java.io.*;
class FileStreams {
	public static void main(String args[]) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			bis = new BufferedInputStream(new FileInputStream("FileStreams.java"));
			bos = new BufferedOutputStream(new FileOutputStream("tmp1.txt"));
			byte b[] = new byte[1024];
			int c;
			while ((c = bis.read(b)) != -1)
				bos.write(b, 0, c);
			bis.close();
			bos.close();
		} catch(IOException ex) {
			System.out.println(ex);
		}
	}
}

/* Random Access File */
class RandomAccess {
	public static void main(String args[]) {
		try {
			RandomAccessFile ra = new RandomAccessFile(
				"FileStreams.java",	// file name
				"r");				// mode: "r", "rw", "rws", "rwd"
			ra.seek(7);
			System.out.println(ra.readLine());

	/* seek() always start from the begin of file. */
			ra.seek(12);
			System.out.println(ra.readLine());
			ra.close();
		} catch(IOException ex) {
			System.out.println(ex);
		}
	}
}

