import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

class PreJava7 {
	public static void main(String args[]) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("index.txt"));
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

	// Try-with-resources Block
class Java8 {
	public static void main(String args[]) {
		try (
			BufferedReader br = new BufferedReader(new FileReader("index.txt"));
		) {
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
/*
1. Resources declared within the try-with-resources block must implement
the interface java.lang.AutoCloseable.

2. All of its resources will be automatically closed when the try block exits.
*/

