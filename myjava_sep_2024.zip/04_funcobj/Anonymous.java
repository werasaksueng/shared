/* Anonymous classes are classes that have no names.
There is no need to keep <class name>:<class object> in the
  class loader so the <class object> can be garbage collected
  when no needed.
Mostly anonymous class is used when the reference in the
  creation scope is not needed.
Anonymous class must be defined and instantiated instantly.
    new <parent class>|<interface> (<args>) { <body> }   */

/* Anonymous class that subclasses a class. */
class A { 
	void f() { System.out.println("A.f()"); } 
}
class AnoClass {
	public static void main(String args[]) {
		A a = new A(){
			void f() { System.out.println("a"); }
		};
		a.f();
	}
}

/* Anonymous class that implements an interface. */
interface I { 
	public void f();
}
class AnoInter {
	public static void main(String args[]) {
		I i = new I() {
			public void f() { System.out.println("i"); }
		};
		i.f();
	}
}

/* Anonymous classes do not need constructors.
But we can pass arguments the the parent class constructors. */
class B {
   int x;
   B(int x) { this.x = x; }
}
class AnoArg {
   	public static void main(String args[]) {
		B b = new B(1) { };
		System.out.println(b.x);
   }
}

/* An anonymous instance may refer to a variable defined in
the scope that creates the instance. But the instance can be
sent out of the scope, so the referred value is copied and
go with the instance.
That why we call the instance a closure.
   For JDK 1.7 the referred variables must be declared 'final'.
   Inn JDK 1.8 the referred variables are 'effectively final'.
 */
class Closure {
	static void test(A a) { a.f(); }
	public static void main(String args[]) {
		int x = 1;
		test(new A() {
			void f() {
				// ++x;    // error: x is effectively final.
				System.out.println(x);
			}
		});
		// ++x;				// error:
	}
}
