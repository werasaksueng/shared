import java.util.function.*;

/* A 'functional' interface is an interface that defines only methods.
If an interface defines only one method, is called a 'SAM' (Single Abstract Method). */
interface MySam<P, R> {
	/* Accept a parameter of type P and return a value of type R. */
	public R compute(P p);
}

/* Lambda:
Java 8 introduces 'lambda' which is an instance of a function type
  that is defined by a 'lambda expression'.
A 'lambda expression' is an expression that represents a function.
			(<parameters>) ->  <body>
			<body> --> <expression> | { <block> }
A 'lambda expression' have no names.
A 'lambda expression' cannot be used as a function, it must be bound
  to an instance(lambda) of a sam (function type).
The binding allows type checking at compile time.
Lambdas cannot be generic types.
When the method of a lambda is called, the body of the
 'lambda expression' is executed. */
class MySamImpl {
	public static void main(String args[]) {
	/* Pre Java 8, anonymous class. */
		MySam<Integer, Integer> sq1 = new MySam<Integer, Integer>() {
			public Integer compute(Integer n) {
				return n*n;
			}
		};
		System.out.println(sq1.compute(2));			// 4

		/* Java 8, lambda is instances of SAM interface implementation. */
		MySam<Integer, Integer> sq2 = (Integer n) -> { return n*n; };
		System.out.println(sq2.compute(3));			// 9
	}
}

/* Ordinary SAM can be bound to lambda expression. */
interface Hello {
	String hello(String name);
}
/* @FunctionalInterface is for annotate functional interface to allows 
  compile time checking.  */
@FunctionalInterface
interface Hi {
	String hi(String name);
	// String hello(String name);		// Try: uncomment this line.
}
/* Binding lambda expression to SAM:
 	- the SAM must has exactly one method.
 	- the lambda parameters match the parameters of the interface method.
 	- the return type of the lambda match the return type of the interface method.
*/
class Binding {
	public static void main(String args[]) {
		Hello h1 = (String name) -> { return "Hello " + name; };
		System.out.println(h1.hello("John"));

		Hi h2 = (String name) -> { return "Hi " + name; };
		System.out.println(h2.hi("Jack"));

	/* There are predefined SAMs in the java.util.function.  */
		Function<String, String> h3 = (String name) -> { return "What's up? " + name; };
		System.out.println(h3.apply("Joe"));
	}
}

/* The body of lambda expression may be an expression or a block.
A lambda expression is evaluated into a value, that is a lambda.
A block is a sequence of statements surrounded in { and }.
Sams are classified by the types of input and output. */
class Classification {
	/* Procedure: accepts nothing, returns nothing  */
	interface Procedure {
		void execute();
	}
	/* println() do not return values. */
	static Procedure procedure = () -> System.out.println("Hello");
	/* null is not an empty expression. {} represent an empty block. */
	static Procedure emptyProcedure = () -> {};

	/* Supplier:  accepts nothing, returns something  */
	interface Supplier {
		String get();
	}
	/* Expression values are automatically returned, 'return' is not allowed. */
	static Supplier hello = () -> "Hello";
	/* A block may have any number of return statements, but only one value is returned. */
	static Supplier hi = () -> { return "Hi"; };

	/* Consumer: accepts something, returns nothing */
	interface Consumer {
		void accept(String name);
	}
	static Consumer g1 =  (String name) ->
				System.out.println("Hello " + name);
	static Consumer g2 =  (String name) -> {
				System.out.print("Hello " + name);
				System.out.println(" how do you do?");
			};
	/* If parameter types can be inferred from the interface, they can be optional. */
	static Consumer g3 =  (name) -> System.out.println("Hi " + name);
	/* If there is only one parameter, the () is optional. */
	static Consumer g4 =  name -> System.out.println("What's up? " + name);

	/* Function or Operator: accepts something and returns something. */
	interface Op {
		int eval(int a, int b);
	}
	/* The result of the expression is automatically returned. */
	static Op add = (int a, int b) -> a + b;
	static Op sub = (a, b) -> a - b;		// Parameter types can be omitted.

	public static void main(String args[]) {
		procedure.execute();
		emptyProcedure.execute();

		System.out.println(hello.get());
		System.out.println(hi.get());

		g1.accept("John");
		g2.accept("Jack");
		g3.accept("Joe");
		g4.accept("Jame");

		System.out.println(add.eval(1, 2));
		System.out.println(sub.eval(1, 2));
	}
}

/* The java.util.function package contains many functional types. */
class FunctionTypes {
	public static void main(String args[]) {
	/* Operator takes T, returns T.
			UnaryOperator<T> 		T apply(T)
			BinaryOperator<T> 		T apply(T, T) 	*/
		UnaryOperator<Integer> uo = x -> ++x;
		System.out.println(uo.apply(1));
		BinaryOperator<Integer> bo = (x, y) -> x + y;
		System.out.println(bo.apply(1, 2));

	/* Function takes T, returns R.
			Function<T,R> 				R apply(T)
			BiFunction<T1, T2, R> 		R apply(T1, T2) 	*/
		Function<String, Integer> f = s -> Integer.parseInt(s);
		System.out.println(f.apply("123"));
		BiFunction<String, String, Integer> bf = (x, y) -> Integer.parseInt(x) + Integer.parseInt(y);
		System.out.println(bf.apply("1", "2"));

	/* Predicate takes T, returns boolean.
				Predicate<T> 				boolean test(T)
				BiPredicate<T1, T2> 	boolean test(T1, T2) */
		Predicate<Integer> p = x -> x != 0;
		System.out.println(p.test(1));
		BiPredicate<Integer, Integer> bp = (x, y) -> x > y;
		System.out.println(bp.test(1, 2));

	/* Consumer takes T, return nothing.
				Consumer<T> 				void accept(T)
				BiConsumer<T1, T2> 		void accept(T1, T2) 	*/
		Consumer<String> c = s -> System.out.println(s);
		c.accept("Hello");
		BiConsumer<String, String> bc = (a, b) -> System.out.println("Hello " + a + " and " + b);
		bc.accept("John", "Jack");

	/* Supplier takes nothing, return R.
			Supplier<R> 			R get()		*/
		Supplier<String> greet = () -> "Hi";
		System.out.println(greet.get());
	}
}

/* There are also function types for primitive types. */
class PrimitiveFunctionTypes {
	public static void main(String args[]) {
	/* Primitive Unary Operators
			IntUnaryOperator			int applyAsInt(int)
			LongUnaryOperator			long applyAsLong(long)
			DoubleUnaryOperator			double applyAsDouble(double) 	*/
		IntUnaryOperator iuo = (int x) -> ++x;
		System.out.println(iuo.applyAsInt(1));
		LongUnaryOperator luo = (long x) -> ++x;
		System.out.println(luo.applyAsLong(2l));
		DoubleUnaryOperator duo = (double x) -> ++x;
		System.out.println(duo.applyAsDouble(2l));

	/* Primitive Binary Operators
			IntBinaryOperator		int applyAsInt(int, int)
			LongBinaryOperator		long applyAsLong(long, long)
			DoubleBinaryOperator	double applyAsDouble(double, double) */
		IntBinaryOperator ibo = (int x, int y) -> x + y;
		System.out.println(ibo.applyAsInt(1, 2));
		LongBinaryOperator lbo = (long x, long y) -> x + y;
		System.out.println(lbo.applyAsLong(1l, 2l));
		DoubleBinaryOperator dbo = (double x, double y) -> x + y;
		System.out.println(dbo.applyAsDouble(1.0, 2.0));

	/* Primitive Predicates
			IntPredicate 				boolean apply(int)
			longPredicate 				boolean apply(long)
			DoublePredicate 			boolean apply(double) 	*/
		IntPredicate ip = (int x) -> x > 0;
		System.out.println(ip.test(1));
		LongPredicate lp = (long x) -> x > 0;
		System.out.println(lp.test(1l));
		DoublePredicate dp = (double x) -> x > 0;
		System.out.println(dp.test(1.0));

	/* Primitive Consumer
			IntConsumer<int> 			void accept(int)
			LongConsumer<long> 			void accept(long)
			DoubleConsumer<double> 		void accept(double) 	*/
		IntConsumer ic = (int x) -> System.out.println(x);
		ic.accept(1);
		LongConsumer lc = (long x) -> System.out.println(x);
		lc.accept(1l);
		DoubleConsumer dc = (double x) -> System.out.println(x);
		dc.accept(1.0);

	/* Supplier
			IntSupplier 			int getAsInt()
			LongSupplier 			long getAsLong()
			DoubleSupplier 			double getAsDouble()	*/
		IntSupplier is = () -> 1;
		System.out.println(is.getAsInt());
		LongSupplier ls = () -> 1l;
		System.out.println(ls.getAsLong());
		DoubleSupplier ds = () -> 1.0;
		System.out.println(ds.getAsDouble());

	/* Primitive Functions
			IntFunction<T> 			T apply(int)
			LongFunction<T> 		T apply(long)
			DoubleFunction<T> 		T apply(double)   */
		IntFunction<String> ifs = (int x) -> x + "";
		System.out.println(ifs.apply(1));
		LongFunction<String> lfs = (long x) -> x + "";
		System.out.println(lfs.apply(2l));
		DoubleFunction<String> dfs = (double x) -> x + "";
		System.out.println(dfs.apply(3.0));

	/* To Primitive Functions
			ToIntFunction<T> 		int applyAsInt(T)
			ToLongFunction<T> 		long apply(T)
			ToDoubleFunction<T> 	double apply(T)	*/
		ToIntFunction<String> tif = (String x) -> Integer.parseInt(x);
		System.out.println(tif.applyAsInt("1"));
		ToLongFunction<String> tlf = (String x) -> Long.parseLong(x);
		System.out.println(tlf.applyAsLong("2"));
		ToDoubleFunction<String> tdf = (String x) -> Double.parseDouble(x);
		System.out.println(tdf.applyAsDouble("3"));

	/* To Primitive Binary Functions
			ToIntBiFunction<T1, T2> 		int applyAsInt(T1, T2)
			ToLongBiFunction<T1, T2> 		long apply(T1, T2)
			ToDoubleBiFunction<T1, T2> 		double apply(T1, T2)   */
		ToIntBiFunction<String, String> tibf = (String x, String y) -> Integer.parseInt(x) + Integer.parseInt(y);
		System.out.println(tibf.applyAsInt("1", "2"));
		ToLongBiFunction<String, String> tlbf = (String x, String y) -> Long.parseLong(x) + Long.parseLong(y);
		System.out.println(tlbf.applyAsLong("1", "2"));
		ToDoubleBiFunction<String, String> tdbf = (String x, String y) -> Double.parseDouble(x) + Double.parseDouble(y);
		System.out.println(tdbf.applyAsDouble("1", "2"));

	/* Primitive To Primitive Functions
			IntToLongFunction 			long applyAsLong(int)
			IntToDoubleFunction 		double applyAsDouble(int)
			LongToIntFunction 			int applyAsInt(long)
			LongToDoubleFunction 		double applyAsDouble(double)
			DoubleToIntFunction 		int applyAsInt(double)
			DoubleToLongFunction 		long applyAsLong(double) 	*/
		IntToLongFunction itl = (int x) -> x;
		System.out.println(itl.applyAsLong(1));
		IntToDoubleFunction itd = (int x) -> x;
		System.out.println(itd.applyAsDouble(1));
		LongToIntFunction lti = (long x) -> (int)x;
		System.out.println(lti.applyAsInt(1));
		LongToDoubleFunction ltd = (long x) -> (double)x;
		System.out.println(ltd.applyAsDouble(1));
		DoubleToIntFunction dti = (double x) -> (int)x;
		System.out.println(dti.applyAsInt(1));
		DoubleToLongFunction dtl = (double x) -> (long)x;
		System.out.println(dtl.applyAsLong(1));
	}
}

/* Lambda expressions can refer to values defined in the outer scope.
Since a lambda may be send out of it's scope, so the referred values
 are 'captured' and go with the lambda.
Local variables/objects of the scope that define the leambda are effectively final.  */
class Capture {
	static int g = 1;
	static IntUnaryOperator getInstance(int p) {
		int l = 1;
		return x -> x + l + p + g;
			// 'p' and 'l' are effectively final but 'x' and 'g' are not.
	}

/* To work around capturing effectively final value. */
	static IntSupplier  getInstance() {
		int count[] = { 0 };  // count is effectively final, but its content is not.
		return () -> ++count[0];
	}
	public static void main(String args[]) {
		IntUnaryOperator fun = getInstance(1);
		System.out.println(fun.applyAsInt(1));
		g = 2;
		System.out.println(fun.applyAsInt(1));

		IntSupplier inc =  getInstance();
		for (int i = 0; i < 5; i++)
			System.out.print(inc.getAsInt() + ",");
	}
}
/* It is not defined in any specifications, but it is known that:
	A non-capturing lambda only needs to be evaluated once.
Since it will return an identical value for the same parameters.
But Capturing lambdas need to be evaluated every time they are encountered.
*/
