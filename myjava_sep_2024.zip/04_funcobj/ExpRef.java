import java.io.*;
import java.util.*;
import java.util.function.*;

/* Java allows existing methods to be used as lambda expression.
	Method Reference:
			<class>::<static method>
			<instance>::<instance method>

Using instance method:
Ex.  System.out is an instance of java.io.PrintStream.
		java.lang.System:
			public static final java.io.PrintStream out;
		java.io.PrintStream:
			public void println(java.lang.String);    */
class InstanceMethod {
	public static void main(String args[]) {
		PrintStream ps = System.out;
		Consumer<String> c1 = ps::println;
		c1.accept("Hello");					// Hello

		Consumer<String> c2 = x -> System.out.println(x);
		c2.accept("Hi");					// Hi

		Consumer<String> c3 = System.out::println;
		c3.accept("What's Up?");			// What's Up?
	}
}

/* Using class method: */
class A {
	static void hello(String name) {
		System.out.println("Hello " + name);
	}
	void hi(String name) {
		System.out.println("Hi " + name);
	}
	static Consumer<String> getHello() { return A::hello; }
	Consumer<String> getHi() { return new A()::hi; }
}
class ClassMethod {
	public static void main(String args[]) {
		A.getHello().accept("John");			// Hello John
		new A().getHi().accept("Jack");		// Hi Jack
	}
}

/* Constructor reference:  <class>::new.	*/
interface Factory<T, U> {
	T create(U u);
}
interface ArrayFactory<T> {
	T[ ] create(int n);
}
interface ListFactory<T> {
	List<T> create();
}
class Student {
	String name;
	Student(String name) { this.name = name; }
	public String toString() { return name; }
}
class ConstructorRef {
	public static void main(String args[]) {
		Factory<Student, String> fac = Student::new;
		Student john = fac.create("John");
		System.out.println(john);		// John

		ArrayFactory<Student> afac = Student[]::new;
		Student sa[] = afac.create(10);
		System.out.println(sa.length);	// 10

		ListFactory<Student> lfac = ArrayList<Student>::new;
		List<Student> l = lfac.create();
		System.out.println(l.size());	// 0
	}
}
