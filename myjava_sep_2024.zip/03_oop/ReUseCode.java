/* C++ allows Multiple Inheritance.
         class A {
            public: void f() { cout << "A\n"; }
        };
        class B {
            public: void f() { cout << "B\n"; }
        };
        class C : public A, public B {
            public: void g() { 	A::f(); B::f(); }
        };

 C++ Diamond Problem
        class A {
            protected:int x;
            public: A() { x = 1; }
        };
        class B : public A {
            public: B() { x = 2; }
        };
        class C : public A {
            public: C() { x = 3; }
        };
        class D : public B, public C {
            public: void f() {
                // cout << x << endl;		// error
                // cout << A::x << endl;	// error
            }
        };

Diamond Problem was solved in C++ by introducing Dynamic Inheritance.
     class B : virtual public A { ... }
     class C : virtual public A { ... }

But there are more problems of Multiple Inheritance.
 e.g. C++ Duplicate Inheritance:
        class X {
            public: void g(){ }
        };
        class A {
            protected: X *x;
            public: A(X *x) { this->x = x; }
        };
        class B {
            protected: X *x;
            public: B(X *x) { this->x = x; }
        };
        class C : public A, public B {
            public: C(X *x): A(x), B(x) { }
            void f() {
                cout << x->g();
            }
        };
 */

/* Java is a Singly Inherite Language.
All classes except 'Object' must have exactly one parent class.
But a Java class is allowed to implement any numbers of interfaces.   */
class MulTypes {
    interface Greeting { abstract public void hello(); }
    interface Farewell { abstract public void bye(); }
    static class MyClass implements Greeting, Farewell {
        public void hello() { System.out.println("Hello."); }
        public void bye() { System.out.println("Bye."); }
    }

	static void test1(Greeting g) { g.hello(); }
	static void test2(Farewell f) { f.bye(); }
	public static void main(String args[]) {
		MyClass s = new MyClass();
		test1(s);
		test2(s);
	}
}
/* Multiple Implementation is a mechanism to create 'multiple type' 
  classes. e.g. MyClass can be handled as Greeting and Farewell.

If we need to inherite(or reuse) from more than one parent classes,
  composition is better. */
class Composition {
    static class Greet { void hello() { System.out.println("Hello."); } }
    static class Farewell { void bye(String msg) { System.out.println("Bye " + msg); } }
    static class User {
        Greet g = new Greet();
        Farewell f = new Farewell();
        void hello() { g.hello(); }		            // forwarding
        void goodbye() { f.bye("see you again."); } // injection
    }

	public static void main(String args[]) {
		User u = new User();
		u.hello();
		u.goodbye();
	}
}

/* Mostly specifications are defined by interfaces.
Existing classes are usually not satisfy the required specification.
'Adaptation' is to create a class from existing classes to satisfy a specification. */
class Adaptation {
/* The specification requires greet() and farewell(). */
	static interface Spec {
		public abstract void greet();
		public abstract void farewell();
	}
/* Suppose there is 'Hello' class with hello(). */
	static class Hello {
		public void greet() { System.out.println("Hello!"); }
	}

/* Extension */
	static class A extends Hello implements Spec {
		public void farewell() { System.out.println("Goodbye."); }
	}

/* Composition */
	static class B implements Spec {
		private Hello h = new Hello();
		public void greet() { h.greet(); }
		public void farewell() { System.out.println("Goodbye."); }
	}

	public static void main(String args[]) {
		A a = new A(); a.greet(); a.farewell();
		B b = new B(); b.greet(); b.farewell();
	}
}
