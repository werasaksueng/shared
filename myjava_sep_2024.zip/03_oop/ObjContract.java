import java.util.*;

/* If the parameter of System.out.print() or System.out.println(a) is
	- a String then it will be sent to System.out.
	- an instance that is not String will be called toString() then sent out.
	- a simple type it will be converted into String then sent out.
java.lang.Object provides the default implmentation of toString().
For our entity class we should override toString() to provide
  the string representation of the instance.
Normally toString() should return the instance state as a string. */
class ToString {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) {
			this.id = id; this.name = name;
		}
		public String toString() { return id + "," + name; }
	}

	public static void main(String args[]) {
		System.out.println(new Student(123, "John Rambo"));	// 123,John Rambo

	/* Standard lib classes have toString() implemented. */
		System.out.println(new String("Hello"));			// Hello
	}
}

/* The operator == compares simple types by value but compares
     reference types by reference.
The java.lang.Object provides equals() but compares by reference.
To compare reference types by value, we must override equals()
  to provide the semantics for equality.

There are some kinds of objects that do not needed to be compared.
  e.g. non-entity objects and function-thread objects.
So we do not need to override equals().
If the equals() should never be invoked at all,
   then it should throw UnsupportedOperationException. */
class Equals {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) {
			this.id = id; this.name = name;
		}
		public boolean equals(Object o) {
			if (o != null && o instanceof Student) {
				Student s = (Student) o;
				if (id == s.id)
					return true;
			}
			return false;
		}
	}

	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		Student b = new Student(123, "John Rambo");
		System.out.println(a == b);				// false
		System.out.println(a.equals(b));		// true

		String x = new String("Hello");
		String y = new String("Hello");
		System.out.println(x.equals(y));		// true
	}
}

/* java.lang.Object provides hasCode() for hashing
 the instances of the class. The contract is:

Whenever hashCode() is invoked on the same object,
  it must return the same integer. The result need not
  to be the same from execution to execution.

If two objects are equal according to equals(),
  then the hashCode() must return the same value.

hashCode() should compute a value from the members
  that used by equals(). */
class HashCode {
	static class Student {
		private int id;
		private String name;
		Student(int id, String name) { this.id = id; this.name = name; }
		// public boolean equals(Object o) {
		// 	if (o != null && o instanceof Student) {
		// 		Student s = (Student) o;
		// 		if (id == s.id)
		// 			return true;
		// 	}
		// 	return false;
		// }
		// public int hashCode() { return id; }
	}

	public static void main(String args[]) {
		Map<Student, String> h = new HashMap<Student, String>();
		h.put(new Student(123, "John Rambo"), "BadGuy");
		System.out.println(h.get(new Student(123, "John Rambo")));

		System.out.println(new String("Hello").hashCode());
		System.out.println(new String("Hello").hashCode());

		Object o = new Object();
		System.out.println(o.hashCode());
		System.out.println(o.hashCode());

	}
}

/* Before an object is garbage collected, its finalize() is called.
 We should override finalize() to provide the last action if needed.
We cannot determine when an object will be a garbage and it can take
 a long time for a garbage to be collected and if the JVM stops ruptly
 some garbages will not be collected. There is no guarantee that
 finalize() will be executed.
  - Nothing time-critical should ever be done by finalize().
  - Never depend on finalize() to update critical persistent state.

 There are only two valid uses of finalize():
	- To act as a "safety net" in case the users of the object
forget to call the explicit termination methods. e.g. InputStream,
OutputStream and Timer have finalize()
	- To garbage collect an instance that uses native code,
because it is not a normal object, the garbage collector
doesn't know about its memory usage.

In case a class needs to perform a post-active activity.
 Define an explicit termination method. Ex.
			 class A {
				........
				public void stop() {
					// perform post-active activity
				}
			}
 Ex.
		java.util.Timer.cancel()
		java.awt.Graphics.dispose()
		java.awt.Window.dispose()
		java.awt.Image.flush()
*/
class Finalize {
	static class A {	 // finalize() is deprecated.
		A() { System.out.println("Hello"); }
		protected void finalize() throws Throwable {
			System.out.println("Bye");
		}
	}

	public static void main(String args[]) {
		A a = new A();
		System.gc();		// request the gc to execute promptly.
	}
}
