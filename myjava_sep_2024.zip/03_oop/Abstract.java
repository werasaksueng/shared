/* A function(or method) consists of 
		- head (specification)
		- body (implementation).

C++ 'Virtual function' is a function that has no bodys.
	e.g	 class A {
				public: virtual void f() = 0;
			};

Java: 'Abstract method' is a method that has no bodys.
So it has just specification but no implementation.
Abstract method must be deined with 'abstract' keyword.

If a class contains at least one abstract method
 then the class must be abstract, but not vice versa.
'Abstract class' is a class defined with 'abstarct' keyword. */
abstract class X {
	abstract void f();
}

/* But an abstract class may or may not have abstract methods. */
abstract class Y { }
abstract class Z {
	int x = 1;
	public void fg() { System.out.println(x); }
}

/* Abstract classes cannot be used for creating an instance.
An abstract class may contain normal members(data and methods).
Abstract classes are used for defining 'non-pure specification'. */
abstract class A {
	abstract public void f();
	abstract public void g();
}
class B extends A {
  	public void f() { System.out.println("f"); }
	public void g() { System.out.println("g"); }

	public static void main(String agrs[]) {
		// new A();
		A a;
		a = new B();
		a.f(); a.g(); 
	}
}

/* Boundary, service or utility classes do not contain 
 state and should not be used to create instance. 
 'abstract' is an effective way for making a class un-newable. */
 abstract class MyMath{
 	static public final double PI = 3.1415;
 	static public double sq(double n) { return n * n; }

	static public void test() {
		System.out.println(MyMath.sq(MyMath.PI));
	}
 }
 /* Alternatively a class with only private constructors
 is un-newable. But it is also un-extendable. */

/* Improving polymorphism */
abstract class Shape {
	abstract public String getName();
	abstract public double getArea();
}
class Rectangle extends Shape {
	private double width, height;
	Rectangle(double width, double height) {
		this.width = width; this.height = height;
	}
	public String getName() { return "rectangle"; }
	public double getArea() { return width * height; }
}
class Triangle extends Shape {
	private double base, height;
	Triangle(double base, double height) {
		this.base = base; this.height = height;
	}
	public String getName() { return "triangle"; }
	public double getArea() { return 0.5 * base * height; }

	static public void main(String args[]) {
		Triangle t = new Triangle(100, 100);
		System.out.println(t.getName() + ", " + t.getArea());
	}
}
//--------------------------------------------------------

/* PlugIn */
abstract class Driver {
	abstract public void print();
}
class Word {
	private Driver d;
	Word(Driver d) { this.d = d; }
	public void setDriver(Driver d) { this.d = d; }
	public void print() { d.print(); }
}
class Epson extends Driver{
	public void print() { System.out.println("Epson"); }
}
class Hp extends Driver{
	public void print() { System.out.println("Hp"); }
}
class PlugIn {
	static public void main(String args[]) {
		Word w = new Word(new Epson());
		w.print();					// Epson
		w = new Word(new Hp());
		w.print();					// Hp
	}
}
//----------------------------------------------------------

/* Using abstract class as specification. */
abstract class Spec {
	abstract public String hello(String name);
	abstract public String hi(String name);
	public static void test(Spec sp) {
		String name = "John";
		if (sp.hello(name).equals("Hello "+name) &&
		    sp.hi(name).equals("Hi "+name))
			System.out.println("Ok");
	}
}
class Impl extends Spec {
	public String hello(String name) {
		return "Hello "+name;
	}
	public String hi(String name) {
		return "Hi "+name;
	}
}
class SpecTest {
	public static void test() {
		 Spec.test(new Impl());
	}
}
