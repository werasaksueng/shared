/* 	Pre-Java8 Interface  */
interface I {
	/* Interfaces are 'pure' specification.
	All members are public by defulat.

	Data members must be static, final, and initialized. */
	// int x;						// error
	static final int y = 1;

	// Data members are public static and final by default.
	int z = 1;		


	/* Method members must be abstract and cannot be static. */
	// void f() { }					// error
	// static abstract void s();  // error
	abstract void g();

	// Method members are public and abstract by default.
	void h();		
}

/* Java 8 interfaces allows:
	1. Default method.
	2. Static methods.
That allows using interfaces as 'non-pure' specifications. */
interface I8 {
	default void f() { System.out.println("default"); }
	static public void g() { System.out.println("static"); }
}

/* Interfaces are specification and can be used as types.
Implementation means making the specification usable.
A class that implements an interface must define all methods
 of the interface and behaves a sub-type of the type(interface). */
class I8Impl implements I8 { }
class I8Test {
	public static void main(String args[]) {
		I8Impl i = new I8Impl();
		i.f();				// default

	/* g() is belong to interface I8, not to the class I8Impl. */
		I8.g();				// static
		// I8Impl.g();		// error
	}
}

/* Extension and Implementation rules.
1. A class may extend exactly one parent class (default is Object).
2. A class may implement any number of interface (including none).

class A { }
interface I { }
interface J { }
class B extends A implements I, J { }						*/

/* 3. Interfaces can be extened, the result is an interface
  with possibly more specification.

interface I { void f(); }
interface J extends I { void g(); }							 */

/* 4. An interfaces can be partialliy implemented(not all methods
 implemented), the result is an abtract class.

interface I { void f(); void g(); }
abstract class A implements I { public void f(){} }
class B extends A { public void g(){} }						*/

//-------------------------------------------------------

/* Java 8 Rules of Interface Implementation:
 1. If the parent class and the interface have the same method, the 'class win'.

class A { public void f() { System.out.println("A.f"); } }
interface I { default void f() { System.out.println("I.f"); } }
class B extends A implements I { }
class Rule1 {
	public static void test() {
		new B().f();				// A.f
	}
}
*/

/* 2. If both interfaces have the same default methods,
  the class must implements its own. e.g.

interface I { default void f() { System.out.println("I.f()"); } }
interface J { default void f() { System.out.println("J.f()"); } }
class A implements I, J {
  public void f() { System.out.println("A.f()"); }
}
*/

/* 3. A method cannot be both abstract and default method in
the same interface. e.g.

interface I {
	public abstract void f();
	// default public void f() { System.out.println("K8.f"); }
}
*/

/* 4. An extended interface can implement abstract methods of the
 parent interface as default methods. e.g.

interface I { void f(); }
interface J extends I {
	default public void f() { System.out.println("J.f"); }
}
*/

//----------------------------------------------------------

/* Java11 introduces private method in interfaces. */
interface I11 {
   private void f() {
      System.out.println("private");
   }
   private static void g() {
      System.out.println("private static");
   }

/* Private methods are visible only within the interface. */
   default void h() {
      f();
      I11.g();
   }
}
//--------------------------------------------------------

/* 'Companion' classes and 'Utility' methods are for working with 
      a class that implements an interface. */
class PreJava8Companion {
	interface A {
		public int get();
		public A add(int x);
	}
	static class AImpl implements A {
		private int x;
		AImpl(int x) { this.x = x; }
		public int get() { return x; }

/* Static method members of a class that can access private state directly. */
		public A add(int x) {
			return new AImpl(x + this.x);
		}
	}
	/* A companion class is a separated class designed to handle 
	    a class, it needs to access private state via setter/getter. */
	static class AComp {
		public static A add(A a1, A a2) {
			return new AImpl(a1.get() + a2.get());
		}
	}

	public static void main(String args[]) {
		A a1 = new AImpl(1);
		A a2 = a1.add(1);
		System.out.println(AComp.add(a1, a2).get());
	}
}

/* Java 8: Using interface static methods, companion needs
 not to be a separated class but included in the interface. */
class Java8Companion {
	interface A {
		public int get();
		static public A add(A a1, A a2) {
			return new AImpl(a1.get() + a2.get());
		}
	}
	static class AImpl implements A {
		private int x;
		AImpl(int x) { this.x = x; }
		public int get() { return x; }
	}

	public static void main(String args[]) {
		A a1 = new AImpl(1);
		A a2 = new AImpl(2);
		System.out.println(A.add(a1, a2).get());
	}
}

