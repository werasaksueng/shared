package com.mypack;

public class C {
	private int x1 = 1;;
	int x2 = 2;
	protected int x3 = 3;
	public int x4 = 4;
	
	public void print() { 
		System.out.println(x1 + x2 + x3 + x4);
	}
}

class SubClassSamePack extends C {
	public void print() { 
		System.out.println(x2 + x3 + x4);
	}
}

class OtherClassSamePack {
	public void print() {
		C c = new C();
		System.out.println(c.x2 + c.x3 + c.x4);
	}
}