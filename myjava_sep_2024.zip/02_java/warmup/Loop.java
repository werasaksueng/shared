import java.util.*;
class For {
	public static void main(String args[]) {
		String s[] = { "John", "Jack", "Joe", "Jim" };

		// Old For-Loop.
		for (int i = 0; i < s.length; i++)
			System.out.print(s[i] + ", ");
		System.out.println();

		// Java 5 Fast For-Loop.
		for (String x : s)
			System.out.print(x + ", ");
		System.out.println();

		// Java 5 collections are modified to support fast for-loop.
		List<String> ls = new ArrayList<String>(Arrays.asList(s));
		for (String x : ls)
			System.out.print(x + ", ");
		System.out.println();

		/* Java 8 introduced 'lambda' and forEach() has been added to 
		the Iterable interface, which is a super-interface of Collection.
   	forEach() accepts a 'lambda' to be performed on each elements
		and returns no values.  */
		ls.forEach(x -> System.out.print(x + ", "));
	}
}
