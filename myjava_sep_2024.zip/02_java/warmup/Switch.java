class Switch {
	public static void main(String args[]) {
	/* Java7 allows String to be a switcher in Switch Statements.
	Strings in cases must be literals, not references.
	No duplicate nor null. */
		String h = "hello";
		switch (h) {
			case "hello": System.out.println("Hello how do you do?");
				break;
			case "hi": System.out.println("Hi what's up?");
				break;
			default: System.out.println("Invalid.");
		}

	/* Java 11 allows switch expression. */
		int n = 2;
		String ns = switch(n) {
			case 0 -> "zero";
			case 1+1 -> "two";
			case 1, 3 -> "few";
			default -> "many";
		};
		System.out.println(ns);
	
	/* Java 17 introduced Pattern Matching for 'switch' as a preview feature.
		Object o = 123L;;
		String r = switch (o) {
            case Integer i -> "Integer: " + i;
            case Long l -> "Long: " + l;
            case Double d -> "Double: " + d;
            case String s -> "String: " + s;
            default -> "Unknown type";
		};
		System.out.println(r);
		 */  
	}
}
/* To enable preview features:
javac --enable-preview --release 20 Switch.java
java --enable-preview Switch
*/
