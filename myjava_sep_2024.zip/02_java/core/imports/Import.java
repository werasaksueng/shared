/* To avoid using qualified name.
'import' statements tell the class loader where to look for and 
  load classes so that the class names can be used.

'import' statements must be defined at top level in file scopes
  and before class definitions.
Classes can be imported individually or using * wildcard for the whole 
  package but only public classes can be imported, not the default ones.
If more than one packages contain classes with the same name,
  wildcard importing is not allowed, qualified name must be used.  */

import com.mypack.*;			// error
// import com.mypack.A;
import com.yourpack.*;
class Import {
	public static void main(String args[]) {
		// A a1 = new A();
		// a1.f();

/* In cases of ambiguous.  */
		com.yourpack.A a2 = new com.yourpack.A();
		a2.f();
	}
}


