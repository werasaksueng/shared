import java.io.*;
import java.sql.*;

/* 'Exception Handling' is a mechanism to handle error at runtime
  without stopping the execution.
Java has exception handling built into the language and provides:
	java.lang.Throwable
 		java.lang.Error
 		java.lang.Exception
 			java.lang.RuntimeException
 				java.lang.ArrayIndexOutOfBoundsException
 				java.lang.ArithmeticException
 				.....
 			java.io.IOException
 			java.sql.SQLException
			.....
A throwable may be 'thrown' by the JVM (default) or user programs.
'Throwing' a throwable allows it can be catched and handled.
When JVM found an illegal operation, an error/exception is creted and thrown.
It will be propagated up the calling stack until catched, if not catched
  jvm will handle by default: 
	- Print: thread, exception class, message and calling stack.
	- Terminate the JVM.		   */

class DefualtHandle {
	public static void main(String args[]) {
		int a[] = {1, 2, 3};
		System.out.println("Hello!  " + a[3]);
	} // java.lang.ArrayIndexOutOfBoundsException
}

class TryCatch {
	public static void main(String args[]) {
		try {
			System.out.println("Hello!  "+ args[0]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Hello! whoever you are. ");
		}
/* When an exception is handled, the next statement is continued. */
		System.out.println("Goodbye.");
	}
}

/* A try block may be followed by multiple catch bolcks,
  since it can throw more one kind of exceptions.
But only the first one is actually thrown. */
class MultipleCatch {
	static void div(String x, String y) {
		try {
			int a = Integer.parseInt(x);
			int b = Integer.parseInt(y);
			System.out.println(a / b);
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public static void main(String args[]) {
		div("2", "1");
		div("2", "0");
		div("2", "a");
		div("2", null);
	}
}
/* Bad :
		try {
			int i1 = Integer.parseInt("10");
			int i2 = Integer.parseInt("2");
			System.out.println(i1 / i2);
		} catch(Exception e) {
			if (e instanceof NumberFormatException)
				// handle NumberFormatException
			else if (e instanceof ArithmeticException)
				// handle ArithmeticException
			.......
		}
*/

/* Try-Catch-Finally:
				try {
					// try block
				} catch(Ex1 e) {
					// catch block
				} catch(Ex2 e) {
					// catch block
				}
				....
				[ finally {
					// finally block
				} ]
A 'try' may follwed by at least one 'catch' and ended with
 one optional 'finally'.
If a 'try' has a 'finally' the 'catch' is optional.
If a 'try' is executed, the 'finally' must be executed before
 going on, even there is a 'return' or a nested execption is thrown.
*/
class Finally {
	static void hello(String name) {
		try {
			if (name.equals("John"))
				// throw new Exception();
				return;
			System.out.println("Hello! " + name);
		} catch (Exception e) {
			System.out.println("Catch");
		} finally {
			System.out.println("Finally");
		}
		System.out.println("End");
	}
	public static void main(String args[]) {
		hello("John");
		// hello("Jack");
	}
}

/* Do not use exceptions for controls, 'if' is better.
		if (name.equals("John"))
			System.out.println("Bye.");
		else
			System.out.println("Hello! " + s);    */
class BadThrow {
	static void hello(String name) {
		try {
			if (name.equals("John"))
				throw new Exception();
			System.out.println("Hello! " + name);
		} catch (Exception e) {
			System.out.println("Bye.");
		}
	}
	public static void main(String args[]) {
	// 	hello("John");
		hello("Jack");
	}
}

/* Throw statement and its try-catch block should be in different scope.
Exceptions may carry error information from the callee to the caller.  */
class GoodThrow {
	static void hello(String name) {  //  throws RuntimeException {
		if (name.equals("John"))
			throw new RuntimeException();
		System.out.println("Hello! " + name);
	}
	public static void main(String args[]) {
		hello("Joe");
		// try {
		// 	hello("John");
		// } catch (RuntimeException e) {
		// 	System.out.println("Bye.");
		// }
		// try {
		// 	hello("Jack");
		// } catch (RuntimeException e) {
		// 	System.out.println("Bye.");
		// }
	}
}
//----------------------------------------------------------

/* 'throws' expressions just tell the compiler that there can be
  these kinds of exception thrown from these method.
A method may throws any number of exception types, including zero,
  sequence is no matter, but there will be no more than one exception
  that actually thrown.

A statement that calls a method which throws exceptions must be
 in the try block that catch the exceptions.  */
class Throws {
	static void greet(String name) throws IOException, SQLException {
/* The declared throw exceptions may not actually thrown inside the method. */
		if (name.equals("John"))
			throw new IOException();
		System.out.println("Hello! " + name);
	}
	public static void main(String args[]) {
		try {
			greet("John");
/* All declared throw exceptions must be catched. */
		}  catch (SQLException e) {  
			System.out.println("SQL.");
		} 
		catch (IOException e) {
			System.out.println("IO.");
		} // Use Exception for default catching.

/* Java 7 Catching Multiple Exceptions in a Single Catch Block.
		catch(SQLException | IOException e) {
			// handle e
		}									 */
	}
}

/* 'Un-checked Exceptions' are exceptions that may or may not be declared and catch.
		Error
		RuntimeException     */
class Uncheck {
	static void greet(String name) {
		if (name.equals("John"))
			throw new RuntimeException();
		System.out.println("Hello! " + name);
	}
	public static void main(String args[]) {
		greet("John");
	}
}

/* By default, throwable objects may contains a string representing error message. 
If not enough we can define our Exception. */
 class MyException extends Exception {
 	private int x;
 	MyException(String msg, int x) { super(msg); this.x = x; }
 	public int getX() { return x; }
 }
 class MyExceptionTest {
 	static void hello(String n) throws MyException {
 		if (n.equals("John"))
 			// throw 
			new MyException("bad", 1);
 		System.out.println("Hello! " + n);
 	}
 	public static void main(String args[]) {
 		try {
 			hello("John");
 		} catch (MyException e) {
 				System.out.println(e.getMessage() + "," + e.getX());
 		}
 	}
}

/* Assertion is a mechanism for program validation and used 
  only during development.
'assert' injects a boolean expression into program codes.
If the expression is evaluated to be true, notthing happens,
  but if it is false an AssertionError with <error message> is thrown.
		assert <expression>: <error message>
Normal runtime ignores all 'assert', we must enable with -ea.
  e.g.      java -ea Assert						*/
class Assert {
	public static void main(String args[]) {
		int x = Integer.parseInt("0");

		assert x == 1 : "Bad Value";
		// if (!(x == 1)) throw new AssertionError("Bad Value");
	}
}
