/* A class is a type.
An object is a variable(or instance) of a class.

'Entity objects' are objects that have their own state.
'data members' store the state of an object.
'method members' are actions (or behaviour) of an object.
Objects of the same class have the same behaviour but have their own state.  */
class Student {
	int id;
	String name;
	Student(int _id, String _name) { id = _id; name = _name; }
	void print() { System.out.println(id + ": " + name); }
}
class StudentTest {
	public static void main(String args[]) {
		Student john = new Student(1, "John");
		Student jack = new Student(2, "Jack");
		john.print();			// 1: John
		jack.print();			// 2: Jack
	}
}

/* 	Class Object:
Every classes(types) has its own class and represented as a class object.
When a class is loaded, its 'class object' is created
  for holding information and creating instances of the class.
Java provide 'Class' class for creating class objects.  */
class A { }
class ClassObj {
	public static void main(String args[]) {
/* <instance>.getClass() returns reference to class object of the instance.
References to class objects are normal reference(4 bytes). */
		A a = new A();
		Class<? extends A> c1 = a.getClass();
		System.out.println(c1.getName());		// A

/* forName(<class name>) where <class name> is a string, loads the class
  and returns reference to class object. */
		try {
			Class<?> c2 = Class.forName("A");
			System.out.println(c2.getName());	// A
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

/* <class>.class is an operator that returns the class object reference of the <class>.
.class is allowed applying to simple types. ex. int.class .
It is used mostly as the class identifier(id) of the class.*/
		Class<A> c3 = A.class;
		System.out.println(c3.getName());		// A
	}
}

/* 'Constructor' is a mechanism for initializing object state.
A constructor has parameters and body like methods but no 'return type',
  its name is the same name as the class. */
class B {
  	int x;
  	B(int _x) { x = _x; }
}
class Constructor {
	public static void main(String args[]) {
/* A constructor must be activated with 'new' only. */
		// B x = B(0);     // Error

/* The result of'new' is the reference to the newly created object. */
		B b = new B(1);
		System.out.println(b.x);

/* The returned reference may be ignored. */
		new B(2);

/* Constructors cannot be invoked via object reference. */
		// b.A(2);			// error
	}
}

/* Constructors cannot be static, final, synchronized nor native.
A class without a constructor would have a default constructor
  which has empty parameters and body.
A 'public' class would have a 'public' default constructor and
  a 'default' class would have a 'default' default constructor.*/
class C { } 				// Try: javap C

/* A class with at least one constructor will not have the default one. */
class D { D(int x) {} }

/* Constructors should not return anything. But some compilers allow and
  ignore the consequence. */
class E { int E() { return 1; } }

/* Some Java compiler allow a constructor to return 'void', but not all. */
class F { void F() { } }

