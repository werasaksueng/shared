/* Static Singleton
The class is designed so that the class instance is created only once
  at class loading time.
The class must not be extensible, clonable nor serializable. */
final class A {
	private A() { }
	private static final A a = new A();
	public static A getA() { return a; }
}
class ATest {
	public static void main(String args[]) {
		A a1 = A.getA();
		A a2 = A.getA();
		System.out.println(a1 == a2);
	}
}

/*  Runtime Singleton:
A singleton class may provides a factory method that synchronizes
  the creation of the instance. */
class John {
	static int c = 0;	// A counter for how many instance is created.
	static private John j = null;
	John() { ++c; }
	public static John getInstance() {
		if (j == null)
			synchronized(John.class) {
				j = new John();
			}
		return j;
	}
}
class JohnTest {
	public static void main(String args[]) {
		for(int i = 0; i < 1000; i++)
			new Thread(() -> {
				John.getInstance();
			}).start();
		System.out.println(John.c);
	}
}
/* 'John' class is not singleton. Suppose thread 1 enters the 
  synchronized block, and before it can assign the member variable, 
  the thread is preempted. Subsequently, another thread can enter the if block.
The second thread will wait for the first thread to finish, but
  it will create another instance.	*/

/*  Runtime Singleton needs a class lock. */
class Jack {
	static int c = 0;
	static private Jack j = null;
	Jack() { ++c; }
	public static Jack getInstance() {
		if (j == null)
			synchronized(Jack.class) {
				if (j == null)
					j = new Jack();
			}
		return j;
	}
}
class JackTest {
	public static void main(String args[]) {
		for(int i = 0; i < 1000; i++)
			new Thread(() -> {
				Jack.getInstance();
			}).start();
		System.out.println(Jack.c);
	}
}
/* 'Jack' class is singleton, suppose thread 1 enters the synchronized
  block and preempted. Then thread 2 enters the if block.
  When thread 1 exits the synchronized block, thread 2 makes a
  second check to see if the instance is still null. Since
  thread 1 set the member variable, thread 2's second check
   will fail, and a second instance will not be created. */
