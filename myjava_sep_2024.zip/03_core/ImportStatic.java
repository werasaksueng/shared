/* 'import static' allows importing the members and accessing without
  the class name. */
import static com.mypack.C.*;
public class ImportStatic {
	public static void main(String args[]) {
		System.out.println(GREET);
	}
}
/* Compared with Import Non-static :

import com.mypack.C;
public class StaticImport {
	public static void main(String args[]) {
		System.out.println(C.GREET);
	}
}
*/
