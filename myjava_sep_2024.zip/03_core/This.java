/* All OOP languages provide 'self reference' for objects to refer to itself.
Java provides 'this' reference as built-in.
Java allows accessing object state without qualified name.
'this' can be used to distinguish between object member and local name.  */
class A {
	int x;
	A(int x) { this.x = x; }
	void setX(int y) { 
        x = y;
        // this.x = y;
    }
}

/* 'this' can be passed as parameter to methods.
'CallBack' is the situation that an object send its reference to 
  other object so that the reference can be used for calling back
  to the sender object. */
class B {
	void f(C c) { c.h(this); }
	void g() { System.out.println("B.g"); }
}
class C {
	void h(B b) { System.out.println("C.h"); b.g(); }
}
class CallBack {
	public static void main(String args[]) {
		B b = new B();
		C c = new C();
		b.f(c);
	}
}

/* 'this' can be used in two contexts, reference and constructor.
'this' constructor allows a constructor to call other constructors
  in the same class. It is allowed in constructor only, not in methods.
It must be the first statement in a constructor and once only. */
class D {
 	D() {   /* this() must be first statement in constructor. */
      // System.out.print("Hello");
		this(0);
		// this(0);         /* allow once only */ 
	}
 	D(int x) {
		// this();    // Circular calls can be detected by compiler.
	}
	// void f() { this(0); }  /* this() cannot be called in methods. */
}

/* Constructors should be overloaded to provide more than one
  ways to 'new' an instance, but all must be consistent
  that means the result should be the same semantic.
To make thing simple, we choose one as a 'designated constructor'
  to performs all the initialization and all other constructors
  must call to the designated constructor. */
class E {
	int x;
	E() {	this(0);	}
	E(int x) { this.x = x; }
}
class This {
    public static void main(String args[]) {
        E e = new E();
		  System.out.println(e.x);
    }
}