/* 'static' is 'ownership' modifier, that makes the member belonged the class.
Non-static members are belong to instance and have the instance lifetime.
Static members are belong to class and have the class lifetime.
A class lifetime begins when the the class is loaded and ends when
 the class is out of reached.

Instances have their own state and be accessed via the instance reference.
Classes have static data to hold the class state, one copy per class and
  be accessed via the class name.
All instances of a class may access its class static members.

Unlike C++, Java allows static data to have any access modifier and
  may be initialized locally.						 */
class A {
	int x;					// Instance data
	static int s = 0;   	// Static data
	A(int a) { x = a; s++; }
}
class StaticData {
	public static void main(String args[]) {
		A a1 = new A(1);
		A a2 = new A(2);
		System.out.println(a1.x + "," + a1.s);  // 1,2
		System.out.println(a2.x + "," + a2.s);	 // 2,2
		System.out.println(A.s);				    // 2
	}
}

/* All methods are created on the class object, not on the instance.
Static methods are active when the class is loaded, they can be accessed
  with class name, but Java allows using instance reference.
Non-static methods are active when the instance is created and must be
  accessed with the instance reference. */
class B {
	void f() { System.out.println("f"); }
	static void g() { System.out.println("g"); }
}
class StaticMethod {
	public static void main(String args[]) {
		B.g();							// g

		B b = new B();
		b.f();							// f
		// Java allows calling static method via instance reference.
		b.g();							// g
	}
}

/* Lifetime:
When X needs to access Y, Y must be available. */
class C {
	int x = 1;
	// static int getX() { return x; }  	// error

	// static y = f();						// error
	int f() { return 1; }
}

/* When JVM loaded the first class, the class must have a static
   main() since the JVM does not create object of the class. */
class D {
	int x = 1;
	public static void main(String args[]) {
		// System.out.println(x);			  // error
		System.out.println(new D().x);
	}
}

/* 'Static blocks' are executed ownce after the class is loaded.
Static blocks have access to only static members.
Static blocks are used mostly for doing something after the class loading.

Instance blocks are executed before constructor for every instance creating.
There is no parameters to static blocks nor instance blocks. */
class E {
	static { System.out.println("static block");	}
	{ System.out.println("instance block"); }
	E() { System.out.println("constructor"); }

	public static void main(String args[]) {
		new E();
		new E();
	}
}

/* Entities(or Model) objects have their own responsibilities,
  their methods operate on their state.

Encapsulation means the object hides its implementation.
An approach is making all data members private and expose
  only methods that handle the object state.

For a data member x of type T,
  	- accessor(getter) is
  			public T getX() { return x; }
   - multator(setter) is
  			public void setX(T x) { this.x = x; }  */
class GoodObject {
	private int x;
	public int getX() { return x; }
	public void setX(int x) { this.x = x; }
}

/* If the object has state, it should not expose methods
  that do not handle its state. */
class BadObject {
	private int x;
	public double sq(double n) { return n * n; }
}

/* All public methods should be exposed permanently and
  never be changed, that called the class API (Application
  Programming Interface).
All private data and methods may change as the API stay the same. */
class Ball1 {
	private double mass, velocity;
	public Ball1(double m, double v) {  mass = m; velocity = v; }
	public double getVelocity() { return velocity; }
	public void setVelocity(double v) { velocity = v; }
	public double getMomentum() { return mass * velocity; }
	public void setMomentum(double mm) { velocity = mm / mass; }
}
class Ball2 {
	private double mass, momentum;
	public Ball2(double ma, double mo) {  mass = ma; momentum = mo; }
	public double getVelocity() { return momentum / mass; }
	public void setVelocity(double v) { momentum = mass * v; }
	public double getMomentum() { return momentum; }
	public void setMomentum(double mm) { momentum = mm; }
}
class BallTest {
	public static void main(String args[]) {
		Ball1 b = new Ball1(1.0, 10.0);
		// Ball2 b = new Ball2(1.0, 10.0);
		System.out.println(b.getMomentum());	// 10.0
		b.setMomentum(5.0);
		System.out.println(b.getVelocity());	// 5.0
		b.setVelocity(20.0);
		System.out.println(b.getMomentum());	// 20.0
	}
}

/* Boundary, Services or Utility classes that do not represent entitiy.
They have no data member for storing state. 
So they should never be instantiated and their methods should be static. */
class MyMath{
	private MyMath() { }
	static public final double PI = 3.1415;
	static public double sq(double n) { return n * n; }
	static public double half(double n) { return n / 2; }
}
// Try: javap java.lang.Math
