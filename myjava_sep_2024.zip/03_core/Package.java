/* Package is a directory scope.
Classes in the same directory is considered in the same package.
Packages allow organizing hierarchy classes of related topic.

Classes in a package must specify its package path at the
  beginning of the file using 'package'.

The class loader starts looking for classes from the CLASSPATH.
So package paths should begin from the directories in the CLASSPATH.

A class may be either public or default
 - Default classes are visible inside the package.
 - Public classes are visible from outside packages.	*/
class Package {
	public static void main(String args[]) {
/* Qualified name mean specifying package path to the class name.  */
		com.mypack.A a1 = new com.mypack.A();
		a1.f();					// f() is a public method.
		// a1.g();				// g() is a default method.
		// com.mypack.B b = new com.mypack.B();  // B is a default class.

/* Packages define its own namespace. There can be the same name 
  classes in different packages. */
		com.yourpack.A a2 = new com.yourpack.A();
		a2.f();
	}
}

/* To prevent ambiguous, your package name/path should be unique.
Java suggested using reversed domain name as package name.
	e.g.    myproject.mydepartment.mycompany.com
		=>   com.mycompany.mydepartment.myproject
*/

