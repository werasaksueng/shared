/* Scope is an area in source code where a set of names is valid(visible).
Scope rules are rules that determine which item is a name refers to.
Scopes in Java are defined by  file{ },s, packages and modules.

1. Classes are visible through the source file and can be extended by importing.
A class is compiled into a .class file.
Only class definitions are allowed at top level.
Variables/objects and methods definitions are not allowed at top level. */
// int x = 1;
// void f() { }

class A {}
class B {
	A a = new A();
	C c = new C();
}
class C {}

/* 2. Class members are visible through the class definition.
Java does not need forward declarations.
Visibility to members of a class from outside can be defined by modifiers */
class D {
	void f() { g(); }
	int x = 1;
	int g() { return x + y; }
	int y = 2;
}

/* 3. 'Control' structures e.g. 'if', 'else', 'for', 'while' and 'switch'
  have their own scope, a single statement by default.
The { } is needed if the body has more than one statements.
Opening a scope(with { }) has overhead, necessary scopes are wasted.  */
class E {
	void f() {
		if (true)
			System.out.print("Hello");
		else {
			int x;
			System.out.print("Hi");
			System.out.print("Bye");
		}
	}
}

/* 4. Local variables are visible only inside its scope. */
class F {
	/* Parameters are condsidered local to the method. */
	void f(int p) {  	/* Method block */
		int x = 1;
		/* p and x are visible here. */
		if (x == 1) {  /* 'if' block */
			int y = 2;
		}
		// System.out.print(y); 	// error.

		/* 'for' loop indexes are local to the block.  */
		for(int i = 0; i < 5; i++) {
			System.out.print(i);
		}
		// System.out.print(i);			// error
	}

/* Unlike class scopes, local variables must be defined before visible. */
	void f() {
		// System.out.print(t);			// error
		int t = 1;
		System.out.print(t);

		if (t == 1) {
			// System.out.print(s);		// error
			int s = 2;
			System.out.print(s);
		}
	}
}

/* 5. Java does not allow nested methods.  */
class G {
	void f() {
		// void g() { }			// error

		// Nested contorl blocks are allowed.
		if (true) {
			while(true) { }
		}
	}
}

/* 6. The names defined in outer scope are visible in nested scopes. */
class I {
	int x = 1;
	void f(int y) {
		if (x == 1) {
			 y = x;
		}
	}

/* An inner scope may shadow names in outer scopes. */
	void g() {
		System.out.print(x);		// 1
		int x = 2;
		System.out.print(x);		// 2
	}
}

/* 7. Java adopts lexical scope rule.  */
class J {
	class K {
		int x = 1;
		void f() {
			System.out.print(x);		// 1
		}
	}
	void g() {
		int x = 2;
      	new K().f();
	}
}
