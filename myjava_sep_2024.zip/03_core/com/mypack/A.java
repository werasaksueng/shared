package com.mypack;

public class A {
	public void f() {
		System.out.println("com.mypack.A.f()");
	}
	void g() {
		System.out.println("com.mypack.A.g()");
	}
}