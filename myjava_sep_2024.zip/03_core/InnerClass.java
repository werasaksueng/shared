/* Java allows nested class which allow extending namespaces.
There are three kinds of nested classes:

1. Static inner classes which are static members of a class. */
class A {
	static class B {
		void f() {
			System.out.println("Hello");
		}
	}
	public static void test(){
		new B();
	}
}
class StaticInner {
	public static void main(String args[]) {
/* The class path is qualified statically. */
		A.B b = new A.B();            // Try: new A$B();
		b.f();
	}
}
/* Visibility Rules:
Static inner class can access all static members of the outter class and
 all static members of other static inner classes in the same class.

class A {
	int x = 1;
	static private int y = 2;
	static class B {
		void print() {
			// System.out.println(x);		// x is not static
			System.out.println(y + C.z);
		}
	}
	static class C {
		static private int z = 3;
	}
}
*/

/* 2. Member classes are non-static class members. */
class X {
	class Y {
		void f() { System.out.println("Hello");	}
	}
}
class MemberClass {
	public static void main(String args[]) {
/* An outter class instance must be created and its reference
	is used for creating the member class instance. */
		X x = new X();
		X.Y y = x.new Y();
		y.f();
	}
}
/* Visibility Rules:
class X {
	private int a = 1;
	Y y = new Y();		// 

// Outer class can access private members of the member class.
	void print() { System.out.println(y.b); }
	
	class Y {
		private int b = 2;
// Member class can access private members of the outer class.
		void print() { System.out.println(a); }
	}

	class Z {
		Y y = new Y();
// Member class can access private members of another member class.
		void print () { System.out.println(y.b); }
	}
}
*/

/* 3. Local classes are classes that defined locally inside
  a method or control block and visible within the block. */
class LocalClass {
	public static void main(String args[]) {
		// new _A();  // Local class must be defined before referenced.
		class _A { }
		new _A(); 

		for (int i = 0; i < 10; i++) {
			class _B { }
			new _B(); 		
		}
		// 'B' is not visible here.
		// new _B();
	}
}
/* Visibility Rules
Local classes can access members of the outer class and
  final local variables of the block.

class A {
	private int a = 0;
	void f(final int w, int x) {
		int y = 3;
		final int z = 4;
		class B {
			B() { System.out.println(a + w + z); }  // cannot access x and y
		}
	}
}
*/