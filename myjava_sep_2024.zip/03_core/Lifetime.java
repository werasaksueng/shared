/* 'Lifetime' is the duration when a variable/object is valid.
  - 'active' when its value is allocated.
  - 'dead' when its value is de-allocated or its reference is no longer available.
'garbage' is a value that has no reference, which means unusable.

lifetime of variable/pointer in C:
		void f() {
			int a;			// 'a' value is created on stack and active.
			int *b = (int *)malloc(sizeof(int));	
					  // 'b' value is allocated on the heap and active.
			free(b);		   // 'b' is de-allocated.
		} 	/* a is poped when out of scope.
Using stack is more efficient and automatic reusable memory.
Using heap must handle deallocation properly.
If 'b' is not de-allocated it will be a garbage.
It is the programmers responsibility to prevent garbages.

Java does not support references for value types.
It is not possible to allocate a simple type value on the heap
  and cannot de-allocate variables. */
class A {
/* Simple type variables are created and destroyed within its scope. */
	int x;
/* 'y' is local to f() so it is created and destroyed within f(). */ 
	void f() { int y; }
}

/* Java has no mechanism to de-allocate but provides a garbage collector(gc)
  for automatically garbage collect.
For memory concerned, some classes may have release() which is mostly
  written in native code to de-allocate memory. */
class B {
	A x = new A();	// 'x' is created when a 'b' instance is created.
	void g() {
		A y;			   // 'y' is not active yet.
		y = new A();	// 'y' value is created on the heap.
		// y = null;	// 'y' value has no references.
	}  					// 'y' is out of scope.
}

/* The 'gc' is activated when the heap is run out.
java.lang.Runtime provides gc() to activate the gc. */
class Gc {
	public static void main(String args[]) {
		Runtime rt = Runtime.getRuntime();
		System.out.println("Intially:\t" + rt.freeMemory());

		A a[] = new A[1000000];
		for(int i = 0; i < a.length; i++)
			a[i] = new A();
		System.out.println("After a[]:\t" + rt.freeMemory());
		for(int i = 0; i < a.length; i++)
			a[i] = null;
		System.out.println("After nulls:\t" + rt.freeMemory());
		rt.gc();
		System.out.println("After gc():\t" + rt.freeMemory());
	/* Later JDK versions apply Lazy Memory Reclamation to avoid unnecessary
        gc() until it is absolutely necessary. */  
	}
}
//-----------------------------------------------------

/* Dangling Reference is the situation when accessing a value 
  with invalid reference/pointer.
    -- before the value is active or after the value is dead.
 	-- the reference type is invalid.
	-- the reference does not have the right to access the value.

Dangling References in C:
  1. C pointers can be assigned with any value.
  		int *p = 1000;
  2. C does not check array index out of bound.
   		int x, a[10];
 			a[10] = 1;
  3. C allows de-allocation value on the heap.
	 		int *p, *q;
	 		p = (int *) malloc(sizeof(int));
	 		*p = 123;
	 		q = p;
	 		free(p);
  4. C allows returning a local pointer out of its creation scope.
	  		int * f() {
	 			int x = 1;
	 			return &x;
	 		}
	 		main() {
	 			int *p = f();
	 			printf("%d", *p);
	 		}
  */
class Dangling {
	static class A { }
	static A getA() {
	  A a = new A();
	  return a;
	}
	public static void main(String args[]) {
  		/* 1. Java references can only assigned with:
  		 	- null
  		 	- the result of new from a compatible type.
  		 	- a reference of a compatible type.  */
		// A a = 1000;				// error

 		/* 2. Java checks array index out of bound at runtime. */
		int a[] = new int[10];
  		// a[10] = 1;	// runtime execption  ArrayIndexOutOfBoundsException

		/* 3. Java does not allow de-allocatation.
		   4. There is no * and &, simple types will not be garbages.
			 All reference types are allocated on heap so their references
			   can be passed around. */
  		A ax = getA();
  	}
}

/* 'Obsolete' object is an object that inaccessible but not a garbages
  and cannot be garbage collected. */
class Obsolete {
	private A a;
	public void bad() {
		a = new A(); // a is used here and may be in other methods.
	} /* This create dependency that bad() must be called before using a.
	While the insatnce is alive, if no other methods use a then it is
	 an obsolete object. We can provide a nullify method, but it made
	 programming more complicated. */
	public void nullA() { a = null; }

	// If a is used only in the method then it should be local.
	public void good() {
		A a = new A(); 	// a is used here only.
	}
}

/* Memory leak is the situation that the heap is losing more and more
  memory and eventually it will run out.
Simple rules:
 - We do not need to manage memory if we do not create our own data structures.
 - When deleting an object, make sure the object is garbage collectible. */
class Stack {
	private Object [] a;
	private int top = 0;
	public Stack(int n) { a = new Object[n]; }
	public void push(Object o) { a[top++] = o; }
	public Object pop() { return a[--top]; }
/*	public Object pop() {
		Object o = a[--top];
		a[top] = null;
		return o;
	}
*/
}
