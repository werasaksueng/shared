/* 'Type' is information about how a value is organited and accessed
 which implies the set of operations allowed on the values.

Java is not a pure object-oriented language.
There are two kinds of types in Java:
 - Value type: (built-in, simple or primitive Types) e.g.
	 byte, short, int, long, float, double, char and boolean.
	They are handled by value. 
 - Reference types: are types that defined by classes.
	They are handled by reference.  */
class Types {
	static class A { int x = 1; }
	public static void main(String args[]) {
	/* Variables are created as value types.
		It's address and value are fixed for the whole lifetime.
		If a variable is created without initialization, it has default value.
		Java has no & operator, there is no pointers to value types. */
		{ // Create a local scope.
			int x;
			x = 1;		// 'x' is a variable of 'int' type.

	/* Objects are created as reference types. 
		It's address and value are independent.
		Values must be created with 'new'.
		Objects without reference are garbage, it's value cannot be accessed.
		Java does not need * to define references and use . instead of -> for projection. */
			A a;		     // 'a' is a reference to instance of class A.
			a = new A();  // 	'new' creates and return the reference of object.
			System.out.print(a.x);
		}
	}
}
/* C and C++ need * to declare pointers.
		A a;			// 'a' is a variable of class A.
		A *p;			// 'p' is a pointer to instance of class A.
Java reference are automatic de-referenced when accessing value.

By Value VS By Reference:  */
class A {
	int x;
	A(int x) { this.x = x; }
	void inc() { ++x; }
}
 class Compare {
	public static void main(String args[]) {
	/* Value types(variables) are compared by value. */
		int x = 1, y = 1;
		System.out.println(x == y);		// true

	/* Reference types(objects) are compared by reference. */
		A a1 = new A(1);
		A a2 = new A(1);
		System.out.println(a1 == a2);	  // false
	}
 }

class Assign {
	public static void main(String args[]) {
	/* Value types are assined by value.  */
		{
			int x = 1, y = 2;
			x = y;
			System.out.println(x + ", " + y);	   // 2, 2
			y = 3;
			System.out.println(x + ", " + y);	   // 2, 3

	/* Reference types are assigned by reference.  */
			A a1 = new A(1);
			A a2 = new A(2);
			a1 = a2;
			System.out.println(a1.x + ", " + a2.x);	// 2, 2
			a1.inc();
			System.out.println(a1.x + ", " + a2.x);	// 3, 3
		}
	}
}

class ParamPass { 
	static void f(int p) { ++p; }
	static void g(A a) { a.inc(); }
	public static void main(String args[]) {
	/* Value type are passed by value.  */
		{
			int x = 0;
			f(x);		// pass value
			System.out.println(x);		// 0

	/* Reference type are passed by reference.  */
			A a = new A(0);
			g(a);		// pass reference
			System.out.println(a.x);	// 1
		}
	}
}
