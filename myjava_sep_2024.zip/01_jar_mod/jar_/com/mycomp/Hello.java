package com.mycomp;

public class Hello {
	public void hello() {
		System.out.println("Hello");
	}
}
