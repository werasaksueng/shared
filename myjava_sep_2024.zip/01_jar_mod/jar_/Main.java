import com.mycomp.Hello;
class Main {
	public static void main(String[] args) {
		(new Hello()).hello();
	}
}
