// com.hello/com/hello/Main.java
package com.hello;
public class Main {
   public static void main(String[] args) {
      System.out.println("Hello");
   }
}