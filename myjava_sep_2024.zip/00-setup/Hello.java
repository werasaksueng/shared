class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, I am Jdk-" + System.getProperty("java.version"));
	}
}
// Java 9+
// java Hello.java