import java.util.concurrent.ArrayBlockingQueue;

/* Some object methods need to executed 'in turn'.
Bad.
		class Buffer {
			private int x;
			synchronized public void setX(int i) { x = i; }
			synchronized public int getX() { return x; }
		}
*/
class Buffer {
	private int x;
	private boolean writeEnable = true;
	synchronized public void setX(int i) {
		while (!writeEnable) {
			try { wait(); } catch (Exception e) { }
		}
		x = i;
		writeEnable = false;
		notify();
	}
	synchronized public int getX() {
		while (writeEnable) {
			try { wait(); } catch (Exception e) { }
		}
		writeEnable = true;
		notify();
		return x;
	}
}
class QueueBuffer {
	public static void test() {
		Buffer b = new Buffer();
		Runnable pro = () -> {
			for (int i = 0; i < 10; i++) {
				b.setX(i);
				System.out.println("write: " + i);
				try { Thread.sleep((long)Math.random()); } catch (InterruptedException e) { }
			}
		};
		Runnable con = () -> {
			for (int i = 0; i < 10; i++) {
				try { Thread.sleep((long)Math.random()); } catch (InterruptedException e) { }
				System.out.println("read: " + b.getX());
			}
		};
		new Thread(pro).start();
		new Thread(con).start();
	}
}

/* Java 7 introduces ArrayBlockingQueue. */
class BlockQueue {
	public static void test() {
		ArrayBlockingQueue<Integer> bq = new ArrayBlockingQueue<>(10);
		Runnable pro = () -> {
			for (int i = 0; i < 10; i++)
				try {
					bq.put(i);
					System.out.println("write: " + i);
					Thread.sleep((long)Math.random());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		};
		Runnable con = () -> {
			for (int i = 0; i < 10; i++)
				try {
					int j = bq.take();
					System.out.println("read: " + j);
					Thread.sleep((long)Math.random());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		};
		new Thread(pro).start();
		new Thread(con).start();
	}
}

class ProdCons {
	public static void main(String agrs[]) {
		QueueBuffer.test();
		// BlockQueue.test();
	}
}