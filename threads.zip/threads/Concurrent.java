/* Concurrent means there are more than one threads execute
 a function or block at the same time.
Java provides 'synchronized' to enforce single thread to be
 executed in the function or block. */
 class Synchronized {
	public static void test() {
		class A {
			void f() {
			// synchronized void f() {
				String t = Thread.currentThread().getName();
				System.out.println(t + ": " + "enter f()");
				try { Thread.sleep(1000); } catch(Exception e) { }
				System.out.println(t + ": " + "leaving f()");
			}
		}

		A a = new A();
		Runnable r = () -> { a.f(); };
		new Thread(r, "A").start();
		new Thread(r, "B").start();
	}
}

/* Thread unsafe is undesirable results from allowing concurrent. */
class UnSafe {
	public static void test() {
		class Counter {
			long x = 0;
			void inc() { ++x; }
			// synchronized void inc() { ++x; }
		}

		Counter c = new Counter();
		Runnable r = () -> { c.inc(); };
		for (int i = 0; i < 10000; i++)
			new Thread(r).start();
		try { Thread.sleep(100); } catch(Exception e) { }
		System.out.println(c.x);
	}
}

/* Data Corruption is a kind of unsafe thread that results invalid data. */
class DataCorrupt {
	public static void test() {
		class Student {
			String first, last;
			void setName(String first, String last) {
			// synchronized void setName(String first, String last) {
				this.first = first;
				if (first.equals("John"))
					try { Thread.sleep(100); } catch(Exception e) { }
				this.last = last;
			}
		}

		Student s = new Student();
		new Thread(() -> { s.setName("John", "Rambo"); }).start();
		new Thread(() -> { s.setName("Jack", "Ripper"); }).start();
		try { Thread.sleep(300); } catch(Exception e) { }
		System.out.println(s.first + ", " + s.last);
	}
}
//----------------------------------------------------

class MyUtil {
	public static void run(String n) {
		String t = Thread.currentThread().getName();
		System.out.println(t + ": " + "enter " + n);
		try { Thread.sleep(1000); } catch(Exception e) { }
		System.out.println(t + ": " + "leaving " + n);
	}
}

/* If threads perform read-only there should be no problems.
But if threads perform any write, thread unsafe may happen
 we must prevent with locking(using 'synchronized').

There are two kinds of locking.
1. Instance Lock. */
class InstanceLock {
	public static void test() {
		class A {
			synchronized void f() { MyUtil.run("f()"); }
			synchronized void g() { MyUtil.run("g()"); }
		}

		A a1 = new A();
		A a2 = new A();
		new Thread(() -> { a1.f();}, "A").start();
		new Thread(() -> {
				a1.f();
				// a1.g();
			}, "B1").start();
		new Thread(() -> {
				a2.f();
				// a2.g();
			}, "B2").start();
	}
}

/* 2. Class Lock */
class ClassLock {
	public static void test() {
		class A {
			synchronized static void f() { MyUtil.run("f()"); }
		}

		A a1 = new A();
		A a2 = new A();
		new Thread(() -> { a1.f(); }, "A1").start();
		new Thread(() -> { a2.f(); }, "A2").start();
	}
}

//----------------------------------------------------

/* Java provides two sides of locking:

1. Callee lock: happen at the called method which locks the whole method. */
class Lock {
	public static void test() {
		class A {
			/* Callee Lock */
			synchronized void f() { MyUtil.run("f()"); }

			/* Class/Object Lock */
			void g() { synchronized(MyUtil.class) { MyUtil.run("g()"); } }

			/* Caller Lock */
			void h() { MyUtil.run("h()"); }
		}

		A a = new A();
		a.f();
		a.g();
		synchronized(a) { a.h(); }
	}
}

class Concurrent {
	public static void main(String agrs[]) {
		Synchronized.test();
		// UnSafe.test();
		// DataCorrupt.test();
		// InstanceLock.test();
		// ClassLock.test();
		// Lock.test();
	}
}