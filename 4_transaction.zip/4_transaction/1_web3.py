# Start: Ganache or Anvil

from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

def get_accounts():
    for a in w3.eth.accounts:
         print(a, w3.eth.get_balance(a))
# get_accounts()

john = w3.eth.accounts[0]
jack = w3.eth.accounts[1]

# Most wallets, Ganache and Anvil provides automatic tx filling and signing.
def send_tx():
# A tx may be created from as a Python dict.
    tx = { 'from': john, 'to': jack, 'value': 1 }
    print(w3.eth.send_transaction(tx).hex())
# send_tx()
tx_hash = '0x0dfe26ebc0a7b985d05201c4828b0b121117c3fe3383158c35a0e8b7f63644f4'
# Try: Look up the tx hash in Ganache.

## Check balances of a1 and a2.
def balances():
    print("john:", w3.eth.get_balance(john))
    print("jack:", w3.eth.get_balance(jack))
# balances()

## Get number of tx sent from a1 and a2.
# print(w3.eth.get_transaction_count(john))
# print(w3.eth.get_transaction_count(jack))

import json
def print_json(tx):         # AttributeDict
    st = w3.toJSON(tx)      # str
    js = json.loads(st)
    print(json.dumps(js, indent=4, sort_keys=True))

def print_tx(tx_hash):
    tx = w3.eth.get_transaction(tx_hash)
    # tx = w3.eth.get_transaction_receipt(tx_hash) # Try:
    print_json(tx)
# print_tx(tx_hash)
   
#------------------------------------------------------------

## Infura does not provide wallets.
URLi = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3 = Web3(Web3.HTTPProvider(URLi))

''' To create a raw tx, we need:
'chainId' is used for prevent sending tx acorss chains.
'nonce' is used for prevent sending a tx more than once,
   mostly it is the number of tx sent by the address.
'gasPrice' is the price offered by the sender, mostly
   obtained from the last block, but may not enough in bussy hours.
'gas' is the max gas allowed to execute this tx, the minimum is 0x21000. '''

## Copy addresses from Metamask.
account1 = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
me = '0x5E98B03695d98eD2A6563cCE88693b494aA2df64'
account1_privatekey = 'ebac496b7df4d594c138b0a992cd9094b25ae27315f07e26d0b520976a9db423'

def infura_balances():
    print("account1:", w3.eth.get_balance(account1))
    print("me:", w3.eth.get_balance(me))
# infura_balances()

def get_info():
    cid = w3.eth.chain_id
    nonce = w3.eth.get_transaction_count(account1)
    block = w3.eth.get_block("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, currGas
# print(get_info())

# Send raw tx from 'account1' to 'me'.
def send_raw_tx():
    cid, nonce, currGas = get_info();
    tx = {
        'to': me,    # receiver address
        'value': w3.toWei("0.0001", "ether"),     # in wei
        'nonce': nonce,
        'chainId': cid,   # EIP-155 requires chainId.
        'gas': "0x21000",    # minimum gas
        'gasPrice': currGas, # Sometime currGas is not enough.
    }
    # print(tx)

# Sign the tx with john private key.
    signed_tx = w3.eth.account.sign_transaction(tx, account1_privatekey) 

# Send the tx.
    tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
    print(tx_hash.hex())
# send_raw_tx()
h = '0xfb1ed5ae59a3c74362687400e13ce973af6d981d5b142ba074c66bb08c6f40fa'
# print_tx(h)

''' The success rate of sending tx depended on the Blockchain.
Check Etherscan: wait while pending until transferred.   '''
# infura_balances()

## Try: Send raw tx in Ganache
## Look up john private key in Ganache.
# john_private_key = '5173c555cd54e3d2e6289c97cda1d786cf8b837af3f3c4a9c006f4abb9467169'
