## The test file and test function start with 'test'.
def test_1(accounts):
    assert len(accounts) == 3

def test_2(accounts):
    assert accounts[0].balance() == 99999999999999999990


