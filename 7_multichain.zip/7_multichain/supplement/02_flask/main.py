## pip install flask
from flask import Flask, render_template, request
app = Flask(__name__)

## route() is a Flask decorator.
## A route path is mapped to a 'view' function by annotation.
## Flask dispaths requests to 'view' function according to the route path.
## A 'view' function may have more than one route paths.
@app.route('/')
@app.route('/index')
def index():
    return 'I am index.html.'
## http://127.0.0.1:8080
## http://127.0.0.1:8080/index
## curl 127.0.0.1:8080

@app.route('/hello')
def hello():
    return 'Hello!'
## http://127.0.0.1:8080/hello
## curl 127.0.0.1:8080/hello

## Parameters to 'view' functions can be passed in the request path.
## The parameter names are denote as <variable> which must be the
##   same as parameters to the 'view' function.'''
@app.route('/hi/<name>')
def hi(name):
    return 'Hi ' + name
## http://127.0.0.1:8080/hi/john
## curl 127.0.0.1:8080/hi/john

## Parameters are str by default.
## But can be type annotated as 'int' or 'float'.
## Return values may be str, dict, tuple, or Response.
@app.route('/add/<int:x>/<int:y>')
def add(x, y):
    return str(x + y)
## http://127.0.0.1:8080/add/1/2
## curl 127.0.0.1:8080/add/1/2

#--------------------------------------------------

if __name__ == '__main__':
##    app.run(host, port, debug, options)
##    app.run()	   	# http://127.0.0.1:5000
##    app.run(port=80)  # http://localhost
      app.run(port=8080, debug=True) # http://127.0.0.1:8080

''' 
host: Defaults is 127.0.0.1 (localhost).
       ‘0.0.0.0’ to have server available externally.
port: Defaults is 5000.
debug: Defaults is False.
'''