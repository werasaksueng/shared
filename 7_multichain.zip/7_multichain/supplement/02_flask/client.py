import requests
print(requests.get('http://127.0.0.1:8080').text)
print(requests.get('http://127.0.0.1:8080/hello').text)
print(requests.get('http://127.0.0.1:8080/hi/john').text)
print(requests.get('http://127.0.0.1:8080/add/1/2').text)