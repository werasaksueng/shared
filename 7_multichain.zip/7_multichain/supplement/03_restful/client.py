import requests
print(requests.get('http://127.0.0.1:8080/doHello/john').text)
print(requests.get('http://127.0.0.1:8080/doGet?name=jack').text)
print(requests.post('http://127.0.0.1:8080/doPost', data={"name": "joe"}).text)
print(requests.put('http://127.0.0.1:8080/doPut', data={"name": "jame"}).text)
print(requests.delete('http://127.0.0.1:8080/doDelete', data={"name": "jim"}).text)
