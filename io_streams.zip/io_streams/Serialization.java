import java.io.*;

/* 'Serialization' is the process of converting an object to a stream of binary.
A class to be serialized must implements 'Serializable' interface.
A sub-class of Serializable is also Serializable.
Serialization is not safe since a serializable object can be cloned. */
class A implements Serializable {
    static int s = 1;
    int x;
    A(int x) { this.x = x; }
}
class MyUtil {
	public static void write(Object o, String f) {
		try (   // serialization
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
		) { oos.writeObject(o); }
		catch(IOException e) {
			e.printStackTrace();
		}
	}

	public static Object read(String f) {
		try (   // de-serialization
			FileInputStream fis = new FileInputStream("tmp");
			ObjectInputStream ois = new ObjectInputStream(fis);
		) { return ois.readObject(); }
		catch(IOException |ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
//-----------------------------------------------------

class Serial {
	public static void test() {
		MyUtil.write(new A(2), "tmp");
		System.out.println("Serial Ok");
	}
}
class DeSerial {
	public static void test() {
		A a = (A) MyUtil.read("tmp");
		System.out.println(a.x + ", " + A.s);
	}
}

/* Serialization is 'deep' that means all object membersare also serialized. */
class B implements Serializable {
	int y;
	A a;
	B(A a, int y) { this.a = a; this.y = y; }
}
class Deep {
	public static void test() {
		B b1 = new B(new A(2), 3);
		MyUtil.write(b1, "tmp");
		B b2 = (B) MyUtil.read("tmp");
		System.out.println(b2.a.s + ", " + b2.a.x + ", " + b2.y);
	}
}

/* Serialization preserves shared object members. */
class Share {
	public static void test() throws Exception {
		A a = new A(1);
		FileOutputStream fo = new FileOutputStream("tmp");
		ObjectOutputStream oo = new ObjectOutputStream(fo);
		oo.writeObject(new B(a, 2));  // Two B objects share the same 'a'.
		oo.writeObject(new B(a, 3));
		oo.close();

		FileInputStream fi = new FileInputStream("tmp");
		ObjectInputStream oi = new ObjectInputStream(fi);
		B b1 = (B) oi.readObject();
		B b2 = (B) oi.readObject();
		System.out.println(b1.a.x + "," + b2.a.x);
		b1.a.x = 4;
		System.out.println(b1.a.x + "," + b2.a.x);
		oi.close();
	}
}

/* 'transient' members are not serialized. */
class T implements Serializable {
	int x;
	transient int y;
	T(int x, int y) { this.x = x; this.y = y; }
}
class Transient {
	public static void test() throws Exception {
		MyUtil.write(new T(1,2), "tmp");
		T t = (T) MyUtil.read("tmp");
		System.out.println(t.x + ", " + t.y);	// 1, 0
	}
}

/* 'Externalizable' allows defining what to be serialized
 and what to do when perform serialization/deserialization.
Classes that implements Externalizable must have public empty constructor. */
class E implements Externalizable {
	private int x = 0;
	private String msg = null;
	public E() {  }
	public E(int x, String msg) { this.x = x; this.msg = msg; }
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(msg);
		out.writeInt(encode(x));
	}
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		msg = (String) in.readObject();
		// x = decode(in.readInt());
      x  = in.readInt();
	}
	public int getX() { return x; }
	public String getMsg() { return msg; }
	private int encode(int x) { return ++x; }
	private int decode(int x) { return --x; }
}
class ExtSerial {
	public static void test() throws Exception {
		MyUtil.write(new E(123, "Hello"), "tmp");
		E e = (E) MyUtil.read("tmp");
		System.out.println(e.getX() + "," + e.getMsg());
	}
}
//------------------------------------------------

/* All Serializable object have 'serialVersionUID' created
 by the compiler if not already defined.
 				serialver A
The class that used for deserialization must have the same 
  serialVersionUID as when serialization.
*/
class S implements Serializable {
	int x;
	// int y;
	// private static final long serialVersionUID = 12345L;
	public void f() {
		// System.out.println("f");
	}
}
class SerUID {
	public static void test() {
		MyUtil.write(new S(), "tmp");
		System.out.println("Serial Ok");
	}
}
class DeSerUID {
	public static void test() {
		// MyUtil.write(new S(), "tmp");
		// System.out.println("Serial Ok");
		S a  = (S) MyUtil.read("tmp");
		System.out.println("DeSerial Ok");
	}
}
class Serialization {
	public static void main(String[] args) throws Exception {
		Serial.test();
		// DeSerial.test();
		// Deep.test();
		// Share.test();
		// Transient.test();
		// ExtSerial.test();
		// SerUID.test();
		// DeSerUID.test();
	}
}