import java.io.*;

/* Streams that write/read simple types and object as binary.

public class java.io.DataOutputStream extends java.io.FilterOutputStream implements java.io.DataOutput
  .....
  public java.io.DataOutputStream(java.io.OutputStream);
  public final void writeBoolean(boolean) throws java.io.IOException;
  public final void writeByte(int) throws java.io.IOException;
  public final void writeShort(int) throws java.io.IOException;
  public final void writeChar(int) throws java.io.IOException;
  public final void writeInt(int) throws java.io.IOException;
  public final void writeLong(long) throws java.io.IOException;
  public final void writeFloat(float) throws java.io.IOException;
  public final void writeDouble(double) throws java.io.IOException;
  public final void writeBytes(java.lang.String) throws java.io.IOException;
  public final void writeChars(java.lang.String) throws java.io.IOException;
  public final void writeUTF(java.lang.String) throws java.io.IOException;
  static int writeUTF(java.lang.String, java.io.DataOutput) throws java.io.IOException;
*/
class DataWrite {
	public static void test() throws IOException {
		DataOutputStream dos = new DataOutputStream(System.out);
		int x = 12345;
		double y = 1.2345;
		dos.writeInt(x);
		dos.writeDouble(y);
		dos.close();
	}
} // Try: java Data >tmp

class DataRead {
	public static void test() throws IOException {
		DataInputStream dis = new DataInputStream(System.in);
		int x = dis.readInt();
		double y = dis.readDouble();
		System.out.println(x);
		System.out.println(y);
	}
} // Try: java Data <tmp

class Data {
	public static void main(String args[]) throws IOException {
		DataWrite.test();
		// DataRead.test();
	}
}
