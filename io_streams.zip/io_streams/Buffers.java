import java.io.*;

/*	Stream with Buffer:
	   BufferedInputStream
	 	BufferedOutputStream

		BufferedReader
		BufferedWriter

BufferedReader.readLine()		reads to end of line into a string.
BufferedWriter.write(String)  */
class ByteBuffer {
	public static void test() throws IOException {
		BufferedInputStream bis = new BufferedInputStream(System.in);
		BufferedOutputStream bos = new BufferedOutputStream(System.out);
		int c;
		while ((c = bis.read()) != -1)
			bos.write(c);
		bis.close();
		bos.close();
	}
} // Try: java Buffers <Buffers.java

class CharBuffer {
	public static void test() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		String s;
		while ((s = br.readLine()) != null)
			bw.write(s + "\n");
		bw.close();
	}
} // Try: java Buffers <Buffers.java

class Buffers {
	public static void main(String args[]) throws IOException {
		// ByteBuffer.test();
		CharBuffer.test();
	}
}
