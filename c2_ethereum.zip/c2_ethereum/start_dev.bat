C:\mycrypto\etc\Geth\geth --dev --datadir ./ethereum --http --http.api web3,eth,net,personal,admin,miner



