''' Geth/dev just pre-creates one account, adding more is not automatic.

'ganache' is a local Blockchain (similar to geth/dev but supports GUI).
It was introduced by trufflesuite.com that created 'truffle' a very 
 famous smart contract development tools.

Download:  https://trufflesuite.com/ganache/
    		Ganache-x.y.z-win-x64.appx

Start Ganache
     Quickstart Ethereum

Ganache pre-creates 10 accounts each 100 tETH balance (by default).
Ganache resets accounts and balances when started.
To avoid resetting, current accounts can be saved and reloaded.
To reduce start-up time:
     Reduce the number of pre-creates accounts:
	   Setting -> ACCOUNTS & KEYS -> TOTAL ACCOUNTS TO GENERATE

Geth/dev opens port 8545 but Ganache opens port 7545 by default.
We may change port 7545 -> 8545.
	   Setting -> Server
    -----------------------------------

Geth console and Ganache:  (Assume port 8545 at localhost).
attach.bat
    geth attach http://127.0.0.1:8545

web3.version
eth.accounts     ## Check with Ganache.
eth.getBalance(eth.accounts[0])
exit
-----------------------------------   '''

## 'ganache' supports both json_rpc and web3.py.
from web3 import Web3
URL = 'http://127.0.0.1:8545'    ## Same as Geth/dev.
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.accounts)

''' We need two addresses to play with sending tx.
Define john and jack addresses.  '''
john = w3.eth.accounts[0]
jack = w3.eth.accounts[1]

def balances():   ## in wei
    print('john:', w3.eth.get_balance(john))
    print('jack:', w3.eth.get_balance(jack))
# balances()

## Ex. john sends 1 wei to jack.
def send_tx(sender, wei, receiver):
    ## Create a tx as a Python dict.
    tx = { 'from': sender, 'to': receiver, 'value': wei }

    ## Send (auto signed) tx and return tx_id (in hex).
    return  w3.eth.send_transaction(tx).hex()
# tx_id = send_tx(john, 1, jack)
# print(tx_id)
tx_id = '580b676369dafcf5b733fb2ab336ef4774c6e630092d0f41c3a1a9b9cdf389c7'
## Ganache commit tx immediately (to simplify development).
## Try: check balances() again.

## Checking the Tx, we need the tx_id.
from pprint import pprint
tx = w3.eth.get_transaction(tx_id)
## pprint(str(tx))

## Check the sending amount of wei.
# print(tx['value'])