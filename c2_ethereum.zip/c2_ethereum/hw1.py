We need tETH (for testing) to play with Testnet Ethereum.
Faucets are web sites that give tETH for free.
     https://sepoliafaucet.com/
     https://alchemy.com/faucets/ethereum-sepolia
     https://docs.metamask.io/developer-tools/faucet
     https://faucet.quicknode.com/ethereum/sepolia
     https://faucet.payram.com
     https://faucet.free
     https://testnet.help/en/ethfaucet/sepolia
     https://tatum.io/faucets/sepolia
     https://getblock.io/faucet/eth-sepolia

     No signup:
     https://cloud.google.com/application/web3/faucet/ethereum/sepolia
     https://metamask.github.io/phishing-warning/v5.1.0/#hostname=www.ethereumsepoliafaucet.com&href=https%3A%2F%2Fwww.ethereumsepoliafaucet.com%2F%3Futm_source%3Dchatgpt.com

Make sure the tETH is for Sepolia Testnet. 
We can only get a small amount at a time for free.
Most faucets require registation (sign up). 
Some may be hard to access or not always in service.
Many faucets require mainnet ETH (to anti-spam), just ignore them.

Homework1:
Get some tETH to your address in Metamask.
Print the Metamask screen that shows your address balance in paper.
Make sure the paper has your name and id, in English please.
Due date: 2 weeks from now.



