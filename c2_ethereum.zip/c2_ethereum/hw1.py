''' Register Infura for your account:
	https://infura.io/
   Save your password and api key.
This is my api key, please create your own (it is free).  '''
API_KEY = '86bf0e4aba984b6e9da45dc3df569558'

## Create url to sepolia.infura:
URL = 'https://sepolia.infura.io/v3/' + API_KEY

## Test connection.
from web3 import Web3  
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)

## But sepolia.infura does not support wallet.
# print(w3.eth.accounts)   ## No pre-created accounts

## Create your own account.
def create_account():
    ac = Web3().eth.account.create()
    print("Address:", ac.address)
    print("Private Key:", ac.key.hex())
# create_account()
## These are mine, use your own.
my_addr = '0x013333BE75c2Cb381482ba39ddc9c1ee518fEca9'
my_prik = '66bd36875651d678b070177bb5a96bbef9d78a4c5fbfe78dc89a20e955014daf'

## Check my balance:
## print(w3.eth.get_balance(my_addr))    ## in wei

''' We need tETH (for testing) to play with Testnet Ethereum.
Faucets are web sites that give test coins for free.
Request tETH from the following faucet:
     https://cloud.google.com/application/web3/faucet/ethereum/sepolia  (no login)
     https://www.alchemy.com/faucets/ethereum-sepolia
     https://docs.metamask.io/developer-tools/faucet
     https://faucet.quicknode.com/ethereum/sepolia
Make sure the tETH is for Sepolia Testnet. 
We can only get a small amount. For example 0.05 tETH at a time.
Mostly they require registation. But some may be hard to access.

*** Get some tETH to your address and show your address balance.
'''
#################################################################

## Exercise:
## Convert wei to eth: 1 eth = 10**18 wei 
my_bal = 50000000000000000   
# print(w3.from_wei(my_bal, 'ether'))  ## 0.05

## Sending JSON RPC to sepolia.infura:
## Using json_rpc() (copy from c1_bitcoin/3_client.py).

import requests
def json_rpc(url, method='web3_clientVersion'):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   HEADERS = {'Content-type': 'application/json'}
   return requests.post(url, data=DATA,  headers=HEADERS).json()

from pprint import pprint
# pprint(json_rpc(URL)) 

''' Try the following commands:
admin_nodeInfo  Node information
net_version  	Network ID (e.g., 1 for mainnet, 5 for goerli). 
net_peerCount  	Number of peers currently connected.
net_listening  	If listening for network connections.
eth_syncing    	Items being synced.
eth_blockNumber Number of the most recent block.
eth_gasPrice  	Current price per gas in wei.
eth_mining   	If the node is actively mining.

sepolia.infura also provides web api.  '''
# print(w3.client_version)
# print(w3.eth.chain_id)        
# print(w3.eth.gas_price)       ## in wei. 
# print(w3.eth.block_number)    ## Most recent block number.
# print(w3.eth.get_block(0))    ## Get block by number Try: 'latest'.
#---------------------------------------------------------------

''' 'tatum.io' also provides connection to Sepolia.
Register: https://co.tatum.io/signup
'''
API_KEY = 't-64f72e240c34f3d88dec9efe-f911f20459a04eb6a13695d8'
URL = 'https://api.tatum.io/v3/blockchain/node/ethereum-sepolia/' + API_KEY

## 'tatum.io' accepts JSON RCP and web api.
# pprint(json_rpc(URL))
# w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)




