''' Connecting to Geth using Python Client.
'web3.py' is a Python lib to connect to Ethereum providers.  '''
from web3 import Web3    ## pip install web3

## start Ganache
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)

## Ganache provides pre-created accounts with balances.
# print(w3.eth.accounts)

## Check balances
def balances():
    [print(w3.eth.get_balance(a)) for a in w3.eth.accounts]
balances()

## Save john and jack addresses.
john_addr = w3.eth.accounts[0]
jack_addr = w3.eth.accounts[1]

''' A tx must be signed with the sender private key.
Ganache supports 'wallets' service, it maintains 
  private keys of all its accounts.
And supports auto-signed tx.  '''
def send_tx(sender, wei, receiver):
    ## A tx can be expressed as a Python dict.
    tx = { 'from': sender, 'to': receiver, 'value': wei }
    return  w3.eth.send_transaction(tx).hex()    ## tx_id

## Ex. john send 1 ETH to jack.
# wei = w3.to_wei(1.0, 'ether')  	## Converts eth to wei.
# tx_id = send_tx(john_addr, wei, jack_addr)
# print(tx_id)

## Ganache commits tx instantly.
## The fee for sending tx is deducted form john balance.
## Check: Ganache Logs or Transactions.
# balances()
