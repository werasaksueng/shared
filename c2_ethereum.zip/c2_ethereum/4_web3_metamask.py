## Create ethereum account.

## 1. Using web3.py: (in local machine):
from web3 import Web3 
def create_account():
    ac = Web3().eth.account.create()
    print("Address:", ac.address)
    print("Private Key:", ac.key.hex())
## create_account()
my_addr = '0xcE586a0030F5B5947c1ff3A180B44B8A6D1C607d'
my_prik = '24dd53b7e50e65c7ef52764508704a41d0e58db4cbd0967b98312625532e0baf'

''' 2. Using 'metamask':
A browser extension for accessing Bitcoin/Ethereum networks.

Install 'metamask' extension in Chrome.
    		https://metamask.io/download/
Save username/password.
Setting is on the top-right.

- Open full screen is more convenient.
	Setting -> Open full screen.

- If 'test' networks are not shown, enable them.
    Setting -> Advanced -> Show test network

- Connect to Sepolia.
    Select network -> sepolia.

- There is one account pre-created, to create more:
    Accounts -> + Add account.

- You can import an off-wallet address into Metamask.
    Add wallet -> Import an account.
    	The private key is needed.
'''
## This is my account, use your own.
account1 = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
#-------------------------------------------------------

''' Check Balance:
1. Metamask always show account balance.

2. Explore: Ethereum sepolia account:
	https://sepolia.etherscan.io
Try: account1 and check balance.
   Then check my_addr.

3. Using web3.py with a public provider.
'infura.io' offers connection to sepolia (it is free).
Register Infura and create your api key.
	https://infura.io/
   Save your password and api key.

This is my api key, please create your own  '''
API_KEY = '86bf0e4aba984b6e9da45dc3df569558'
# API_KEY = '1c33caf701824d43882200b69d5e0849'

## Url to Ethereum 'mainnet'. 
URL = 'https://mainnet.infura.io/v3/' + API_KEY
## Url to sepolia.infura:
URL = 'https://sepolia.infura.io/v3/' + API_KEY

## Test a web3 connection.
# w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.accounts) ## Infura does not support wallet.

## Check balances:     ## in wei
# print(w3.eth.get_balance(my_addr))
# print(w3.eth.get_balance(account1))
#-------------------------------------------------------

''' Alternatively:
'tatum.io' also provides connection to sepolia.
Register: https://co.tatum.io/signup

This is my api key, please use your own. '''
API_KEY = 't-64f72e240c34f3d88dec9efe-f911f20459a04eb6a13695d8'
URL = 'https://api.tatum.io/v3/blockchain/node/ethereum-sepolia/' + API_KEY
# w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.get_balance(my_addr))
# print(w3.eth.get_balance(account1))
#-----------------------------------------------------------------

## Supplement:
## Convert wei to eth:         10**18 wei = 1 eth 
my_wei = 50000000000000000   
# print(Web3().from_wei(my_wei, 'ether'))  ## 0.05 (no connection needed).

