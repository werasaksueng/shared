''' Geth 
The reference implementation of Ethereum node (writen in Go).
   Alternative: Netherlands(C#/.net), Rget(Rust) and Besu(Java).

Download: https://geth.ethereum.org/downloads/
	       geth-windows-amd64-x.y.z-.zip
Unzip to:
	C:/mycrypto/etc/Geth	(Rename to shorter name)

setp.bat
geth version
geth help
   https://geth.ethereum.org/docs/interface/command-line-options
------------------------------------------------------

To Start (default) Geth Node:
geth
    The Blockchain is stored at:
	C:/Users/<USER>/AppData/Local/Ethereum

To start Geth with specific data directory:
geth --datadir "./ethereum"

Ethereum Bootstrap: (similar to Bitcoin)
Load config, init database/network, sync Blockchain, load accounts
  start JSON RPC service (if enabled).
It takes too long to download the entire blockchain.
------------------------------------------------------

Working with Ethereum tx requires custom and tweak gas,
  we need a developing enviroment that close to the 'mainnet'.

Geth Public Providers: offer connection to Ethereum Test network:
'goerli', 'rinkeby', 'ropsten' and 'kovan' are stop running.
'sepolia' and 'holesky' are still running.

Start Geth with connection to 'sepolia'.
geth --sepolia

To enable Http service: 
  Enable Http Server:  --http
  Define port:  	--http.port <port> (default is 8545).
  Enable access from any domains: --http.corsdomain '*' .
  Enable APIS:  	--http.api <package list>

geth --datadir ./ethereum --sepolia --http --http.api personal,admin,miner
   ------------------------------------------------------

For learning and presentations that do not concern gas, 
  a private Blockchain is more convenient.

Geth Private Mode: (geth/dev)
Private Blockchain, no peers, no downloading.
Txs are committed instantly.
It creates one account with pre-funding.

Start geth/dev:
geth --dev
     --datadir    <dir>
     --http       to enable port 8545.
     --http.api   <enabled apis>

start_dev.bat
   geth --dev --datadir ./devdatadir --http --http.api web3,eth,net,personal,admin,miner

Deleting the datadir, reset the Blockchain.
   ------------------------------------------------------------

Geth Console:   (Similar to bitcoin-cli)
Mostly used by developers for quickly test Ethereum nodes.

geth/dev opens port 8545 on local host to service RPC with Javascript command.
	   https://geth.ethereum.org/docs/rpc/ns-eth

start_dev.bat
attach.bat:    
        geth attach http://127.0.0.1:8545

web3.version
admin.nodeInfo    (must be enabled with --http.api)
net.peerCount
eth.blockNumber   (no services untill catch up completed).

Check: pre-fabricates 1 accounts and its balance.
eth.accounts
eth.getBalance(eth.accounts[0])
exit		(exit Geth console).
 ------------------------------------------------------

Python Client to connect to Geth node.
'web3.py' is a Python lib for connection to Ethereum nodes.
'''
from web3 import Web3    ## pip install web3

## Geth open port 8545 at localhost for Http service.
## start-dev.bat
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)

## Geth/dev provides a pre-created account with balances.
# print(w3.eth.accounts)
# print(w3.eth.get_balance(w3.eth.accounts[0]))
