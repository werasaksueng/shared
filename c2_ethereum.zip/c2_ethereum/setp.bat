set PYTHON_HOME=C:\python\Python312;C:\python\Python312\Scripts
set PATH=%PYTHON_HOME%;;C:\mycrypto\etc\Geth