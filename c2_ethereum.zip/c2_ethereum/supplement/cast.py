
## 'Foundry' also provides 'cast'.
## Cast: is tool for command line to interact with local or 
remote Ethereum nodes without writing codes.
	https://book.getfoundry.sh/cast/index.html

cast -help

'cast' sends command to 127.0.0.1:8545 by default.
	cast <command> --<option> <args>
cast client
cast chain-id
cast block-number
cast block 0
cast age --block 0
cast gas-price
cast rpc eth_accounts    # Send rpc command.

set ADDR=0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266
cast balance %ADDR%

## 'cast' may send command to remote nodes.
set URL=https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558
cast client --rpc-url %URL%

## Check balance of a sepolia address.
set ADDR=0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5
cast balance %ADDR% --rpc-url %URL%
'''
