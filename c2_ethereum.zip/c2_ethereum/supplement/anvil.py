''' Foundry is a tool set for writing, testing, and deploying smart contracts. 
Anvil is a local Ethereum node written in Rust similar to Ganache.
	https://book.getfoundry.sh/anvil/index.html

## Download:
	https://github.com/foundry-rs/foundry/releases

## Unzip to:
 	C:/mycrypto/etc/Foundry

## Set Path: 
	set PATH=%PATH%;C:/mycrypto/etc/Foundry

anvil -V
anvil -help

## Start default anvil: 10 accounts with 10000 eth each.
anvil		

## Start with specific account number and balance
anvil --accounts 3 --balance 10

## Default Listening on 127.0.0.1:8545
## Anvil accepts checksum addresses.
--------------------------------------------

## ## Using Geth console to connect to Anvil. 
setp
geth attach http://127.0.0.1:8545
web3.version
eth.accounts 
exit

-------------------------------------------- 

'''
## Using web3.py with Anvil.
from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.accounts)

## Anvil accepts only checksum addresses.
addr = Web3.to_checksum_address("0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266")
print(w3.eth.get_balance(addr))

'''
------------------------------------------------
