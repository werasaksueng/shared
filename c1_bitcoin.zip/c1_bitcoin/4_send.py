from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException  ## pip install python-bitcoinrpc

## Start start_regtest.bat
URL = 'http://john:hello@127.0.0.1:18443'
api = AuthServiceProxy(URL)
from pprint import pprint
# pprint(api.getblockchaininfo())

''' Create wallets:
createwallet() arguments:
 - wallet_name (string, required)
 - disable_private_keys (bool, optional, default is False.): If True, 
    the wallet will not generate private keys, making it a watch-only wallet. 
 - passphrase (string, optional): A passphrase for encrypting the wallet.
 - avoid_reuse (bool, optional, default is False.): If True,
    mark reused addresses as "dirty" to prevent reusing them. '''
def create_wallets():
    print(api.createwallet('john'))
    print(api.createwallet('jack'))
# create_wallets()

## Create apis(connection point) to john and jack wallet.
john_api = AuthServiceProxy(URL + '/wallet/john')
jack_api = AuthServiceProxy(URL + '/wallet/jack')

## Create john and jack addresses.
def create_addresses():
    print('john addr:', john_api.getnewaddress())
    print('jack_addr:', jack_api.getnewaddress())
# create_addresses()
john_addr = 'bcrt1qud95789022xdttp4quz9jyadyegc67j5783vyf'
jack_addr = 'bcrt1q5q8tqva7c4he2y536qqdjz8d653q5dkkmju470'

## Check 'john' and 'jack' balances:
def balances():   ## Using f-string to format float to int.
    print(john_api.getbalance())
    print(jack_api.getbalance())
# balances()

''' There is no faucets for regtest and you do not need one.
You need to earn rBTC from mining incentive.
The first 100 blocks rewards 50 BTC and then 50 BTC for a new block. 
But we needs at least 100 confirmations before spending the BTC. '''
def gen101():
    ## We need an api with longer timeout. 
    john_apiX = AuthServiceProxy(URL + '/wallet/john', timeout=240)

    ## Generate 101 blocks to john address. It will take a while.
    print(john_apiX.generatetoaddress(101, john_addr))

    ## Check john wallet balance.
    print(john_api.getbalance())
# gen101()

''' Wallets simplify tx services:
         create tx, calculate fee, and sign tx.

Auto-signed tx limited sending from the sender's wallet to recievers.
To send from any account to any account we need raw tx. 

Send tx to an address:
sendtoaddress() arguments:
 - address (string, required): address to send to.
 - amount (numeric, required): BTC to send (in BTC).
 - comment (string, optional) about the transaction.
 - comment_to (string, optional): A comment to add about who the transaction is sent to.
 - subtractfeefromamount (bool, optional): If true, the fee will be subtracted from the amount instead of being added on top.
 - conf_target (integer, optional): Defines how quick the transaction should be confirmed (in blocks)
 - n: Aiming for confirmation within n blocks.
  	Lower values may result in higher fees,
 - estimate_mode (string, optional): The fee estimation mode. Options:
  	UNSET: Default mode.
  	ECONOMICAL: Lower fees, slower confirmation.
  	CONSERVATIVE: Higher fees, faster confirmation. '''
def send(api, amount, rec_addr):
    ## To avoid fee estimation, set a small amount of fixed fee.
    api.settxfee(0.0001)	    ## Set a manual fee
    txid = api.sendtoaddress(rec_addr, amount,
        "Payment for my services",  ## Comment for payment
        "Jack Ripper",              ## Comment for recipient
        False)   ## Do not subtract fee from the amount
    return txid
# txid = send(john_api, 1, jack_addr)  ## Ex. John sends 1 BTC to Jack.
# print(txid)	
txid = '119911a2a720d66681c91c33c157c802718236644de571ea8376d522a626eb28'

''' To check if the tx sending was success:
	- Check john and jack balances.
	- Check the transaction confirmations.  '''
# balances()

# pprint(jack_api.gettransaction(txid))
## Check: 'confirmations': 0    ## the tx is not confirmed yet.

''' Even tx sending was success, but if the tx is not confired yet,
  the reciever balance is not updated.

To force tx confirmation, generate a new block, supposed to john. '''
# print(john_api.generatetoaddress(1, john_addr))

## Then check john and jack balances.
# balances()

## reset_regtest.bat