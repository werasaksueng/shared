bitcoin-cli -regtest -rpcuser=john -rpcpassword=hello %1
