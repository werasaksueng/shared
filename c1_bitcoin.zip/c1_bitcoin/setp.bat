set PYTHON_HOME=C:\python\Python311;C:\python\Python311\Scripts
set BITCOIN_HOME=C:\mycrypto\etc\Bitcoin;C:\mycrypto\etc\Bitcoin\daemon
set PATH=%PYTHON_HOME%;%BITCOIN_HOME%