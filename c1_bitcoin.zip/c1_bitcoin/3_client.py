''' The bitcoind options may be in Bitcoin\bitcoin.conf:
		server=1
		regtest=1
		rpcuser=john
		rpcpassword=hello
		rpcport=18443

Using bitcoind 'regtest' with HTTP server and user/password.
start_regtest.bat

'regtest' opens port 18443 Json-rpc over HTTP.
   	main: 8332, testnet: 18332
'''
## Define url:
URL = 'http://john:hello@127.0.0.1:18443' 
##    'http://{USER}:{PWD}@{HOST}:{PORT}'

## 'requests' is a python lib to communicate with HTTP server.
import requests			## pip install requests
## For simplicity, accept only methods with no parameters.
def json_rpc(url, method='getblockchaininfo'):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   HEADERS = {"Content-type": "application/json", "Accept": "text/plain"}
   return requests.post(url, data=DATA, headers=HEADERS).json()

## 'pprint' is a python lib for pretty print JSON (or python code).
from pprint import pprint
# pprint(json_rpc(URL))  	## Try: method='getblockcount'
#------------------------------------------------

''' There are public Bitcoin Providers that offers free access.
Ex. 'getblock.io' is a Bitcoin provider that support JSON RPC.
   		https://getblock.io/
Register to get a free endpont: (using Authen with Google). 
   Protocol: Bitcoin
   Network: Testnet
   API interrface: Json-rpc
'''
URL = "https://go.getblock.io/baddeb10abff4800b37b0919908e7745"
# pprint(json_rpc(URL))
#------------------------------------------------

'''   		  Restful 
'Restful' is a web framework to perform RPC using URL (no JSON nor XML).
Ex. 'tatum.io' is a provider that supports Restful request.
It allows access to 60+ blockchains,
  e.g., Bitcoin, Ethereum, Solana, Binance, Polygon.

Register: https://co.tatum.io/signup	
Create a Testnet API key:
'''
API_KEY = 't-64f72e240c34f3d88dec9efe-f911f20459a04eb6a13695d8'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }
import json
def restful(url):
   return requests.get(url, headers=HEADERS).json()
# pprint(restful('https://api.tatum.io/v3/bitcoin/info'))
## Check the document to define the restful paths. 
#---------------------------------------------------------

'''			Web Api
'python-bitcoinrpc' is a Pythin lib that allows sending 
  JSON RCP but using function calls (in Python).  '''
import bitcoinrpc	## pip install python-bitcoinrpc
from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException
from pprint import pprint

## Using local bitcoind 'regtest' with HTTP and user/password.
## start_regtest.bat
URL = 'http://john:hello@127.0.0.1:18443'
def api_test():
    try:
        api = AuthServiceProxy(URL)
        pprint(api.getblockchaininfo())
        # print(api.getblockcount())
    except JSONRPCException as e:
        print(e)
# api_test()
