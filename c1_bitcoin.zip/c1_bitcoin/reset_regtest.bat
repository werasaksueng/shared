set USER=THAIMART
set APPDATA=C:\Users\%USER%\AppData
rmdir /S /Q "%APPDATA%\Roaming\Bitcoin\regtest"