''' Python 'int' (data type) may represent any big values
 (as memory is avialable). But few other languages can do. '''
# print(2**1234)

## str(<int>):  int -> str
## Alternatively: bin(), oct(), hex(), format() and f-string.
i = 12345
s = str(i)
# print(s, type(s))	 ## 12345 <class 'str'>

## ‘str’ allows accessing one character at a time.
# print([x for x in s])  ## ['1', '2', '3', '4', '5']

## int(<str>): str -> int
i = int(s)
# print(i, type(i))	 ## 12345 <class 'int'>
#-----------------------------------------------------------

## <str>.encode(): str -> bytes
## <bytes>.decose(): bytes -> str
## 'bytes' literal has 'b' prefixed.
s = '12345'		 ## Try: 'Hello'
b = s.encode()
# print(b, b.decode())     ## b'12345' 12345

## ‘bytes’ allows accessing one byte at a time.
## Some bytes may not printable.
print([x for x in b])  ## [49, 50, 51, 52, 53]  
#---------------------------------------------------------

## ASCII
s = 'Hello'
b = s.encode('ascii')           ## -> bytes
# print(b, b.decode())          ## b'Hello' Hello

## Fails with non-ASCII symbols.
# print('กขค'.encode('ascii'))  ## Error
#--------------------------------------------------

## Python supports UTF directly.
s = '😀'                
# print(s, hex(ord(s)))       ## 😀 0x1f600

## UTF str -> bytes
b = s.encode('utf-8')
# print(b, b.hex(), b.decode())
        ## b'\xf0\x9f\x98\x80' f09f9880 😀

## Unicode liyteral (hex str) has '\U' prefix.
# print('\U0001F600')                    ## 😀

## Created UTF-8 from hex code point.
# print(chr(0x1F600))                    ## 😀

## Created from \N{...} Unicode name.
# print('\N{GRINNING FACE}')             ## 😀    

## UTF-8: 1–4 bytes per character. (Default in Python)
b = '😀'.encode('utf-8')
# print(b)                    ## b'\xf0\x9f\x98\x80'
# print(b.hex())              ## f09f9880

## UTF=16: 2 or 4 bytes per character (Used by Windows/Java)
b = '😀'.encode('utf-16')
# print(b)                    ## b'\xff\xfe=\xd8\x00\xde'
# print(b.hex())              ## fffe3dd800de

## UTF-32: 4 bytes per character (Simple but wasteful)
b = '😀'.encode('utf-32')
# print(b)                    ## b'\xff\xfe\x00\x00\x00\xf6\x01\x00'
# print(b.hex())              ## fffe000000f60100
#-----------------------------------------------------------

## Bases Encoding
data = 'Hello'

## Binary
b = [bin(x)[2:] for x in data.encode()]  ## Exclude '0b' prefix
# print(b)          ## ['1001000', '1100101', '1101100', '1101100', '1101111']
# print(''.join(b)) ## 10010001100101110110011011001101111

## Decimal
d = [str(ord(x)) for x in data]
# print(d)		## ['72', '101', '108', '108', '111']
# print(''.join(d))	## 72101108108111

## Hexadecimal
h = [hex(ord(x))[2:] for x in data]   ## To exclude '0x' prefix
# print(h)		## ['48', '65', '6c', '6c', '6f']
# print(''.join(h))	## 48656c6c6f

## Base64
import base64           ## A standard Python lib.
d = base64.b64encode(data.encode())     ## Input must be 'bytes'.
# print(d.decode())                     ## SGVsbG8=
# print(base64.b64decode(d).decode())   ## Hello

## Base58
import base58		 ## pip install base58 
d = base58.b58encode(data)
# print(d.decode())                         ## 9Ajdvzr
# print(base58.b58decode(d).decode())       ## Hello

## Base58Check
d = base58.b58encode_check(data)
#cprint(d.decode())                         ## vSxRbq6XzDhP
# print(base58.b58decode_check(d).decode()) ## Hello
