''' 'pybitcoin' is a Python lib for working with Bitcoin keys.   '''
import bitcoin as byc		## pip install pybitcoin

''' Bitcoin Private Keys:
'pybitcoin' provides a constant N for the maximum value of private key. '''
# print(byc.N)        ## a decimal int.
  ## 115792089237316195423570985008687907852837564279074904382605163141518161494337

## Converse byc.N to hex.
n_hex = hex(byc.N)[2:]    ## exclude prefix '0x'.
# print(len(n_hex), n_hex)   ## 64 fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
#----------------------------------------------------------------------

''' Generating Bitcoin private keys:

1. Create random integer within 1 and byc.N range.  '''
import random
def rand_prik():
    return hex(random.randint(1, byc.N))[2:]
# [print(rand_prik()) for _ in range(3)]

''' 2. Using sha256()
sha256(<seed>) returns a 32 bytes hash of the <seed>.
A slim chance of overflow, but allows repeatedly generated from a seed.
During development, debging, generating the same key is required. '''
import hashlib
def hash_prik(seed):
    return hashlib.sha256(seed).hexdigest()
# [print(hash_prik('Hello'.encode())) for _ in range(3)]

''' 3. Using Bitcoin lib that returns valid private key. '''
# [print(byc.random_key()) for _ in range(3)]
#--------------------------------------------------------------------

''' An account consists of a 'key suit'.
A 'key suit' consists of private key, public key and address.
Starting with create a private key then the rests can be computed, '''
def keys_suit():
    ## Create a private key using sha256() with fixed 'Hello' seed.
    prik = hash_prik('Hello'.encode())
    print('private:', prik)

    ## Create public key from the private key.
    pubk = byc.privkey_to_pubkey(prik)
    print('public:', pubk)

    ## Create address from publice key (or private key).
    addr = byc.pubkey_to_address(pubk)
    # addr = byc.privkey_to_address(prik)
    print('address:', addr)
# keys_suit()    ## Try: Compare to results with bitaddress.org
#----------------------------------------------------------

''' Let create my private keys to be used later. '''
my_prik = hash_prik('Hello'.encode())
# print(my_prik)
    ## '185f8db32271fe25f561a6fc938b2e264306ec304eda518007d1764826381969'
#-----------------------------------------------------------------------

''' WIF is human friendly to be used by human in Wallets.
  Read: Mastering Bitcoin Programming: ch4, Base58Check Encoding.
WIF adds prefix (0x80), but base58.b58encode_check() does not.

To convert <private key> -> <private key wif>
  - Start with private key encoded as 'bytes'.
  - Add prefix 0x80 (one byte) to the private key to be a payload.
  - Double sha256() the payload and take only 4 bytes as checksum.
  - Append payload with checksum and apply base58 encoding.
WIF and non-WIF represent the same value.
It is possible to convert forth and back.  

Compute private key wif from non-wif manualy. '''
import base58
def to_wif(prik_hex):
    prik_bytes = bytes.fromhex(prik_hex)
    prefix = b'\x80'   # mainnet prefix (0x80)
    payload = prefix + prik_bytes
    checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return base58.b58encode(payload + checksum).decode()
# print(to_wif(my_prik))		## uncompressed
# print(to_wif(my_prik + '01'))		## compressed
                            ## Check: bitaddress.org

## There are many Python lib for handling WIF. e.g. 'pybitcoin'.
# import bitcoin as byc		## Already imported.
def to_wif_(my_prik):
    raw_prik = byc.decode_privkey(my_prik, 'hex')
    return byc.encode_privkey(raw_prik, 'wif')    

# print(to_wif_(my_prik))
my_prik_wif = '5J12ASfjmVAX7efMjvvr4h4Q19xd4wZPPEf9dqiLda8QtWAT93b'

# print(to_wif_(my_prik + '01'))
my_cprik_wif = 'Kx368gHymMK1vMEJYV2fZHozXgYWCPowo9HP7c1TeRDiSCsZ8t3A'

## WIF uncompressed private keys always begin with 5.
## WIF compressed private keys always begin with K or L

## The benefit of WIF is allow checking for errors.
def verify(prik_wif):
    ## Verify checksum  
    data = base58.b58decode(prik_wif)  ## Base58Check decode
    check = hashlib.sha256(hashlib.sha256(data[:-4]).digest()).digest()[:4]
    checksum = data[-4:].hex()
    if checksum != check.hex():
        return 'Invalid checksum'

    ## Verify playload
    if len(data[:-4]) == 34: ## Compressed private key is 33 bytes.
        return 'Valid Compressed'
    elif len(data[:-4]) == 33: ## Uncompressed private key is 32 bytes.
        return 'Valid Uncompressed'
    else:
        return 'Invalid payload'
def verify_ex():
    print(verify(my_prik_wif))	## Uncompressed
    print(verify(my_cprik_wif)) ## Compressed

    ## Invalid private key wif (only the last character modified).
    print(verify('5J12ASfjmVAX7efMjvvr4h4Q19xd4wZPPEf9dqiLda8QtWAT93a'))
    print(verify('Kx368gHymMK1vMEJYV2fZHozXgYWCPowo9HP7c1TeRDiSCsZ8t3B'))
# verify_ex()
#--------------------------------------------------------------

'''		    Bitcoin Public Key
'pybitcoin' provides G (EC generator) which is a tuple of point(x, y). '''
# print(byc.G)

''' Bitcoin public key is computed by * a private key with G.
        <public key> = G * <private key>      '''
def to_pubk(prik_hex):
    ## Create raw private key from hex private key.
    raw_prik = byc.decode_privkey(prik_hex, 'hex')
    # print(raw_prik)	## a tuple of x and y.

    ## Fast multiply raw private key with G.
    raw_pubk = byc.fast_multiply(byc.G, raw_prik)
    # print(raw_pubk)

    ## Encode to hex public key.
    return byc.encode_pubkey(raw_pubk, 'hex')
pubk_hex = to_pubk(my_prik)
# print(pubk_hex)      ## prefix with '04'
# print(byc.privkey_to_pubkey(my_prik_hex))	  ## 65 bytes
  ## 0468191146d1581310fb2d11caafcc87acb0fc3ce5ad7f26e17be1c3da08d1d4dabc0528e05e78fec33f6dab4c12e4ef36dd816834630ab1a31b0746762358972f

# print(byc.privkey_to_pubkey(my_prik_hex + '01')) ## 33 bytes
  ## 0368191146d1581310fb2d11caafcc87acb0fc3ce5ad7f26e17be1c3da08d1d4da

''' Public keys are rarely used by human and so WIF version.
'public key hash' is a hash of public key and much smaller.
'public key hash' is computed from public key, the reverse is not feasible.
Both can be computed from a private key, so 'public key hash' can be use
  as the witness of the target public key.
The most popular type of tx is 'sending BTC to a 'public key hash'.

To compute public key hash from private key:  '''
def to_pubk_hash(prik):
    pubk = byc.privkey_to_pubkey(prik)
    pubk_bytes = bytes.fromhex(pubk)
    ## ripemd160
    pubk_sha = hashlib.sha256(pubk_bytes).digest()
    return hashlib.new('ripemd160', pubk_sha).hexdigest()
# print(to_pubk_hash(my_prik_hex))
 ## 6566aae8629f41a98153b258eea69211eadb027d
###################################################################

''' Bitcoin Address
To compute address from private key:  '''
def to_addr(prik_hex):
    ## private key hex -> public key bytes
    pubk_hex = byc.privkey_to_pubkey(prik_hex)
    pubk_bytes = bytes.fromhex(pubk_hex)

    ## ripemd160
    pubk_sha = hashlib.sha256(pubk_bytes).digest()
    pubk_hash = hashlib.new('ripemd160', pubk_sha).digest()

    ## base58check uses double SHA-256
    prefix = b'\x00'          ## Prefix for mainnet
    playload = prefix + pubk_hash
    checksum = hashlib.sha256(hashlib.sha256(playload).digest()).digest()[:4]
    return base58.b58encode(playload + checksum).decode()
# print(to_addr(my_prik_hex))
addr = '1AFAEr2oY7HQp7L7sxyHCfXBFf7zo935sv'

# print(to_addr(my_prik_hex+'01'))
caddr = '1P8txSS7i5CieqAgMXBBCXyDtFu5NgUwMX'

''' Bitcoin address allows verification for validity.
Any typo certainly fails validation.
Only 1 in 2³² random modifications would accidentally pass. '''
import base58
def is_valid(addr):
    try:
        base58.b58decode_check(addr)
        return True
    except Exception:
        return False
# print(is_valid(addr))       ## True
# print(is_valid(caddr))      ## True
addrX = '1AFAEr2oY7HQp7L7sxyHCfXBFf7zo935sx' ## modified last char
# print(is_valid(addrX))      ## False
##########################################################

''' 		Ethereum Account
Mostly ethereum accounts are created by Python libs or wallets.
There are two choices for creating accounts:
  - Off Wallet Account(owa): No wallets, users manage private key.
  - In Wallet Account(iwa): Accounts are maintained within the wallet.

'eth-keys' is a Python lib for owa.   '''
from eth_keys import keys	## pip install eth-keys

## Create a seed for randomness.
seed = ('1234'*8).encode()      ## must be 32 bytes.

def gen_owa():
    prik = keys.PrivateKey(seed)    ## Private Key
    print(prik)
    pubk = prik.public_key	    ## Public key
    print(pubk)
    print(pubk.to_address())	    ## Address.
# gen_owa()

## Let save for used later.
my_prik = '0x3132333431323334313233343132333431323334313233343132333431323334'
my_pubk = '0x16df1cff74fd0cb490130945e50e76dd0b3a102c5dcd3357adf5d97d4cc26564239a8fa0865bd9816fe98ac9291563bf76a092f9039e6bd98cdff659595ce205'
my_addr = '0xd099286b68f17da0e15b7ba86bad6be3b7dc673a'

''' Ethereum keys are normally represented as 'str' with '0x' prefix.
Most users need only private keys and addresses.

Ethereum supports two types of addresses:
1. Normal Address: 20 bytes (40 hex chars), can be all lowercase or all uppercase.
2. Checksum Address (EIP-55): mix of uppercase and lowercase, encode checksum in cases.
Both formats have the same size and refer to the same account.
But Checksum Address allows error checking.
They cannot be used as the other because some libs and 
  Blockchains are case-sensitive.
Wallets, like MetaMask can handle both formats.
Checksum address is more popular.

To converse normal address to checksum address.  '''
from web3 import Web3           	## pip install web3
def cs_addr():
    ## normal -> checksum
    my_csaddr = Web3.to_checksum_address(my_addr)
    print(my_csaddr)

    ## checksum -> normal
    print(my_csaddr.lower())
# cs_addr()
my_csaddr = '0xd099286B68F17Da0E15B7ba86bAD6be3B7Dc673A'

## To verify if an address is a valid checksum address.
def verify_cs():
    print(Web3.is_checksum_address(my_addr))	## False
    print(Web3.is_checksum_address(my_csaddr))	## True

    my_csaddrX = '0xd099286B68F17Da0E15B7ba86bAD6be3B7Dc673B'
    print(Web3.is_checksum_address(my_csaddrX))	## False
# verify_cs()
#----------------------------------------------------

''' 'eth-account' is a Python lib that supports wallet 
  so allows generating 'iwa. '''
from eth_account import Account	   ## pip install eth_account
def gen_iwa():
    # ac = Account.create()        ## randomly create
    ac = Account.from_key(my_prik) ## create from a private key
    print(ac.key.hex())            ## private key hex
    print(ac.address)              ## checksum address
# gen_iwa()

## 'eth_account' supports account encryption. 
def encrypt_account():
    ## Create 'john' account.
    john_acc = Account.create('john')
    print(john_acc.key.hex())
    print(john_acc.address)

    ## Encrypt an account to a json(dict) which can be pickled. 
    enc_john_acc = john_acc.encrypt('hello')   ## 'hello' is the password.

    ## Decrypt an encrypted account to private key
    john_priv = Account.decrypt(enc_john_acc, 'hello')
    print(john_priv.hex())

    ## Retrieve account from private key.
    ja = Account.from_key(john_priv)
    print(ja.address)
# encrypt_account()

