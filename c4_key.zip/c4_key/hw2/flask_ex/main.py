## 'flask' is a web framework that supports restful.
## pip install flask
from flask import Flask, render_template, request  
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
## http://127.0.0.1:8080

@app.route('/doHello/<name>')
def do_hello(name):
    return 'Link: %s' % name
## http://127.0.0.1:8080/doHello/john

@app.route('/doGet')
def do_get():
    return 'Get: args \"name\" %s.' % request.args['name']
## http://127.0.0.1:8080/doGet?name=jack

@app.route('/doPost', methods=['POST'])
def do_post():
    return 'Post: form \"name\" %s.' % request.form['name']

#--------------------------------------------------

if __name__ == '__main__':
    app.run(port=8080, debug=True)


