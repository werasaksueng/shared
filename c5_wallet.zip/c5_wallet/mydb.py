## To simplify code, we will use file pickle to store dict permanently.
import pickle
from pathlib import Path
class myDb:
    def __init__(self, filename='my.pck'):
        self.file = Path(filename)
        self.data = self._load()

    def _load(self):
        if self.file.exists():
            with self.file.open("rb") as f:
                return pickle.load(f)
        else:
            with self.file.open("wb") as f:
                pickle.dump({}, f)
                return {}

    def _save(self):
        with self.file.open("wb") as f:
            pickle.dump(self.data, f)

    def set(self, key, value):
        self.data[key] = value
        self._save()

    def get(self, key, default=None):
        return self.data.get(key, default)

def test_db():
    db = myDb()
    db.set("key1", "john")
    db.set("key2", "jack")
    # db.set("key3", "jim")

    print(db.get("key1"))
    print(db.get("key2"))
    # print(db.get("key3"))
# test_db()
