''' Prepare:
pip install mnemonic
pip install bip32utils
pip install cryptography
'''
#-----------------------------------------------------

## Nondeterministic Wallet (ND-Wallet):
''' Good practice: private keys must not stored explicitly.
Let's 'name' be the key, so user names must be unique.
'db1':  <name>: hash(<prik>+<pwd>)   '''
from mydb import myDb
db = myDb('db1')

import hashlib
def md5(msg):
    return hashlib.md5(msg.encode()).hexdigest()

import bitcoin as pbc
def create_prik():
    return pbc.random_key()

## A private key is created and returned from register().
def register(name, pwd):
    prik = create_prik()
    db.set(name, md5(prik+pwd))
    print('Success:', prik)
    return prik

## Users must show name, pwd and private key.
def verify(name, pwd, prik):
    pkpw = db.get(name)
    return True if pkpw == md5(prik + pwd) else False

# pk = register('john', 'hello')
# print(verify('john', 'hello', pk))

''' Users must create (by register) and protect their own private keys.
This technique allows only verification of name, pwd and private key
 without storing explicit private keys. '''
#--------------------------------------------------------------

''' Alternatively: 
Private keys are reproducible with name and pwd, no explicit storage. '''
def gen_prik(name: str, pwd: str):
    return md5(name + pwd)
def gen_prik_test():
    print(gen_prik('john', 'hello1'))
    print(gen_prik('jack', 'hello2'))
    print(gen_prik('jack', 'hello1'))
    print(gen_prik('jack', 'hello2'))
# gen_prik_test()
#----------------------------------------------------------

''' Deterministic Wallet (D Wallet):
All private keys are generated from a single seed with its index and password. '''
def gen_seed(mnm):
    return md5(mnm)
mnm = 'john rambo is the world greatest freedom fighter.'  ## A poor mnemonic.
seed = gen_seed(mnm)
# print(seed)    ## 6d39b2ae0754e792740af4b95c78813b

def gen_dprik(index, pwd):
    seed = gen_seed(mnm)
    return md5(str(index) + pwd + seed)

def gen_dprik_test():
    print(gen_dprik(1, 'hello1'))
    print(gen_dprik(2, 'hello2'))
    print(gen_dprik(2, 'hello1'))
    print(gen_dprik(2, 'hello2'))
# gen_dprik_test()
#--------------------------------------------------------

''' Hierarchical Deterministic Wallets (HD Wallet): BIP32
The root node (category or account) is created from a seed. '''
from bip32utils import BIP32Key          ## pip install bip32utils
def gen_root():
    return BIP32Key.fromEntropy(gen_seed(mnm).encode(), public=False)

def root_test():
    root = gen_root()
    print('prik:', root.PrivateKey().hex())
    print('pubk:', root.PublicKey().hex())
    print('addr:', root.Address())
# root_test()

def hd_wallet():
    root = gen_root()

    ## Create 3 child account of the root.
    for i in range(3):
        print(i, root.CKDpriv(i).Address())
    print()

    ## Create 2 child account of of the first child account(index 0).
    c0 = root.CKDpriv(0)
    for j in range(2):
        print(f'0, {j}', c0.CKDpriv(j).Address())
# hd_wallet()

## Accessing account of path i, j.
def get_ac(i, j):
    root = gen_root()
    return root.CKDpriv(i).CKDpriv(j).Address()
# print(get_ac(0, 0))
# print(get_ac(0, 1))
#--------------------------------------------------------

## Mnemonic:
from mnemonic import Mnemonic           ## pip install mnemonic

## Supported Languages List:
# print(Mnemonic.list_languages())

## English Words List:
# print(Mnemonic('english').wordlist)

''' Mnemonics are created from an 'entropy'. 
An 'entropy' should be non-reproducible randomness.
BIP-39 defines an entropy is a 'bytes' sampled from 16, 20, 24,
  28, or 32 hex digits. '''
import random
def gen_entropy():
    r = ''
    for i in range(random.choice([16, 20, 24, 28, 32])):
        r += '{:x}'.format(random.randint(0, 15))
    return r.encode()     ## To bytes
# print(gen_entropy())      ## Vary length each time.

## To create mnemonic from entropy.
def gen_mnemonic(en):
     return Mnemonic('english').to_mnemonic(en) ## a str
# my_mnm = gen_mnemonic(gen_entropy())
# print(my_mnm)    ## Random result between 16 to 32 words.
my_mnm = 'damp screen bone hover drop rebel network clutch couple lobster mix sign'

''' Mnemonic is troublesome if exposed in source codes.
A practical approach is using mnemonic with password to create
  a 'seed' to be used internally. e.g. generate passwords. '''
def gen_seed(mnm, pwd):
    return Mnemonic.to_seed(mnm, passphrase=pwd).hex()

my_seed = gen_seed(my_mnm, 'hello123')
# print(my_seed)    

''' Occasionally we need to save mnemonic to file.
But at least it should be encrypted.
'cryptography.fernet' offers a simple encryption.
'''
from cryptography.fernet import Fernet  ## pip install cryptography

## Create and pickle a 'fernet'.
import pickle   ## To persist an object in file.
def gen_fernet():
    key = Fernet.generate_key()
    fn = Fernet(key) ##  an object for encrypt/decrypt.
    with open('my_fernet', 'wb') as f:
        pickle.dump(fn, f)
# gen_fernet()

def load_fernet():
    with open('my_fernet', 'rb') as f:
         return pickle.load(f)

def write_mnm(text, file):
    fn = load_fernet()
    en = fn.encrypt(text.encode())
    with open(file, 'wb') as f:
        f.write(en)
# write_mnm(my_mnm, 'my_mnm')

def read_mnm(file):
    fn = load_fernet()
    with open(file, 'rb') as f:
        en = f.read()
    return fn.decrypt(en).decode()
# print(read_mnm('my_mnm'))
