## There are many Python libs that support wallet services.
## Web3.py allows creating accounts.
from web3 import Web3 
def create_account():
    ac = Web3().eth.account.create()
    print("Private Key:", ac.key.hex())
    print("Address:", ac.address)
# create_account()

## 'eth_account' is a Python lib that supports wallet service.
## Ex. Creating an account with mnemonic. 
from eth_account import Account
def  account_mnm():
    ## Enable HD wallet
    Account.enable_unaudited_hdwallet_features()

    ## Return a tuple of (account, mnemonic).
    acc, mnm = Account.create_with_mnemonic()
    print(acc.address)
    print(mnm)
# account_mnm()

## An account may be created from a mnemonic.
def gen_account(mnm):
    Account.enable_unaudited_hdwallet_features()
    ac = Account.from_mnemonic(my_mnm)
    print(ac.address)
my_mnm = 'damp screen bone hover drop rebel network clutch couple lobster mix sign'
# gen_account(my_mnm)

''' 'eth_account' supports hd-wallet service.
Ex. Create n accounts by account paths.
Account Path:  m / 44' / 60' / 0' / 0 / index
        44' → BIP44
        60' → Ethereum coin type
        index → account number (0,1,2,…) '''
def gen_acc(n, mnm):
    Account.enable_unaudited_hdwallet_features()
    for i in range(n):
        ac = Account.from_mnemonic(mnm,
            account_path=f"m/44'/60'/0'/0/{i}" )
        print(i, ac.address)
# gen_acc(5, my_mnm)

''' An account (identified by 'index') can be computed from the mnemonic.
Ex. To get the account of index 'i'.   '''
def ac_access(i, mnm):
    Account.enable_unaudited_hdwallet_features()
    ac = Account.from_mnemonic(mnm,
            account_path="m/44'/60'/0'/0/" + str(i)
        )
    print(ac.address)
# ac_access(3, my_mnm)
#------------------------------------------------------------

''' Ethereum nodes/providers support wallet service.
      e.g. Geth, Infura, Ganache, and geth/dev   '''

URL = 'http://127.0.0.1:8545'
from web3 import Web3
def w3_test(): ## Starts Ganache or start_dev.bat
    w3 = Web3(Web3.HTTPProvider(URL))
    ac = w3.eth.account.create()
    print(ac.key.hex())
    print(ac.address)
    print(w3.eth.accounts)
    print(w3.eth.get_balance(w3.eth.accounts[0]))
# w3_test()

## Sepolia provider URL: 
URLsp = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
def w3sp_test():
    w3sp = Web3(Web3.HTTPProvider(URLsp))
    print(w3sp.eth.accounts)
# w3sp_test()  ## Sepolia does not create pre-accounts.
#---------------------------------------------------------

''' Alternatively:
Ex. tatum.io  is a provider that supports wallet service.
	https://co.tatum.io/signup
'''
API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673' ## expire
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

## Create Ethereum Wallet using restful to tatum.io.
import requests
from pprint import pprint
def create_wallet():
   URL = "https://api.tatum.io/v3/ethereum/wallet"
   pprint(requests.get(URL, headers=HEADERS).json())
# create_wallet()
