rpcuser = 'multichainrpc'
rpcpasswd = '52TH6uU5onYPrwGoZzMittjoEjg9iZS6rDi8i3aVQjNi'
rpchost = '127.0.0.1'
rpcport = '1234'
chainname = 'chain1'
#--------------------------------------

## 'Savoir' is a Python lib that supports rpc using api.
from Savoir import Savoir	## pip install savoir
api = Savoir(rpcuser, rpcpasswd, rpchost, rpcport, chainname)
#--------------------------------------

## Create 4 addresses.
import os, pickle
def prepare_addrs(num=4):
    addrs = api.getaddresses() ## Include what already have.
    for _ in range(num):
        addrs.append(api.getnewaddress())
    with open('addrs.bin', 'wb') as f:
        pickle.dump(addrs, f)

    fn = 'set_addrs.bat'
    if os.path.exists(fn):
        os.remove(fn)
    with open(fn, 'w') as f:
        for i, a in enumerate(addrs):
            f.write('set addr{}={}\n'.format(i, a))
    print('Prepare addresses success.')

def load_addrs():
    with open('addrs.bin', 'rb') as f:
        return pickle.load(f)
#-------------------------------------------------

import json
def print_js(js):
    print(json.dumps(js, indent=4))

def str_hex(s):
    return s.encode().hex()

def hex_str(h):
    return bytes.fromhex(h).decode()