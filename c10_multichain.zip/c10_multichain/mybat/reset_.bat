call C:\mycrypto\c10_multichain\setp
call stop_.bat
call remove_.bat
call create_.bat
call copy_cf.bat
