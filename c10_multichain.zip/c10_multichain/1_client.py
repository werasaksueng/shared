from myutil import *

## Client using JSON-RPC:
import requests			## pip install request
def rpc(method):
	url = 'http://' + rpchost + ':' + rpcport
	data = '{"method": "%s",  \
                 "params": [],    \
		 "id": 1, 	  \
		 "chain_name": "chain1"}' % method 
	# print(data)
	headers = { 'Content-type': 'application/json', 'Accept': 'text/plain'}
	return requests.post(url, data=data, headers=headers,
		auth=(rpcuser,rpcpasswd)).json()  ## Return a dict.
# pprint(rpc('getinfo'))
#----------------------------------------------------------------

## Client using API (Savoir lib is imported in myutil):
# pprint(api.getinfo())