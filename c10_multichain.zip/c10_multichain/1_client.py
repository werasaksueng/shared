## Client using JSON-RPC:
from myutil import *
import requests			## pip install requests
def rpc(method):
	url = 'http://' + rpchost + ':' + rpcport
	data = '{"method": "%s",  \
                 "params": [],    \
		 "id": 1, 	  \
		 "chain_name": "chain1"}' % method 
	# print(data)
	headers = { 'Content-type': 'application/json', 'Accept': 'text/plain'}
	return requests.post(url, data=data, headers=headers,
		auth=(rpcuser,rpcpasswd)).json()  ## Return a dict.
# print_js(rpc('getinfo'))
#----------------------------------------------------------------

## Client using API (Savoir lib is imported in myutil):
# print_js(api.getinfo())
print(api.help('getinfo'))