set PYTHON_HOME=C:\python\Python311;C:\python\Python311\Scripts
set MC_HOME=C:\mycrypto\etc\Multichain23
set MC_DIR=C:\Users\THAIMART\AppData\Roaming\MultiChain
set MY_BAT=C:\mycrypto\c10_multichain\mybat
set PATH=%PYTHON_HOME%;%PYTHON_SC%;%MC_HOME%;%MY_BAT%
