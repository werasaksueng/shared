''' A multichain node supports wallet.
There are three kinds of addresses:
  - In wallet addresses(iwa): created and managed in wallets.
  - Off wallet addresses(owa): created outside wallets.
  - Imported addresses(ia): created outside and imported into wallet.
'''

## Reset multichain:
## reset_.bat && start_.bat

''' Get Addresses: 
multichain-cli chain1 getaddresses
## mc getaddresses
Returns a list iwa and ia in the node.
Initially there is only 'root' address, always the first address.
Addresses are reperented as str.
'''
from myutil import *
# print_js(api.getaddresses())

''' List Addresses:
multichain-cli chain1 listaddresses
## mc listaddresses
Returns a list of dict of addresses with 'ismine'.
If 'ismine' is 'true' the address is an iwa.
'''
# print_js(api.listaddresses())

''' Create an iwa:  The private key is stored in the node.
multichain-cli chain1 getnewaddress
## mc getnewaddress
Return a newly created iwa as a str.
'''
# print(api.getnewaddress())

''' Create 5 addresses:   The node should be reseted.
Delete set_addrs.bat if exists.
Save to set_addrs.bat to be used in command prompt.
Pickle 'addrs' to 'addrs.bin' to be loaded and used in Python.
'''
# prepare_addrs()      ## defined in myutil.
''' To set addresses in command prompt.
	Run set_addrs.bat 
	echo %addr0%
'''
## Load addresses:
## load_addrs() is defined in myutil.
# print_js(load_addrs())
#-------------------------------------------------

## Root Address:
# print(api.getaddresses()[0])

''' Verify Address: Check if the address is valid.
multichain-cli chain1 validateaddress <address>
## mc validateaddress %addr0%
Return a dict. The result is 'isvalid'.
'''
# print(api.validateaddress(root)['isvalid']) 

## mc validateaddress %addr1%
# a1 = api.getaddresses()[1]   ## Try: + '0'
# print(api.validateaddress(a1)['isvalid']) 

''' Create owa: 
multichain-cli chain1 createkeypairs <count>=1
# mc createkeypairs
# mc createkeypairs 2
<count> is the number of accounts to be generated.
An account contains private key, public key and address.
'''
def owa_test():
    keys = api.createkeypairs()   ## list of keys
    prik = keys[0]['privkey']
    pubk = keys[0]['pubkey']
    addr = keys[0]['address']
    print(len(prik), prik)    ## (56 char) wif private key
    print(len(pubk), pubk)    ## (66 char) compressed hex public key
    print(len(addr), addr)   ## (38 char) wif compressed address
# owa_test()
## The newly created account is not listed in 'getaddresses()'.
## mc listaddresses
#---------------------------------------------------------

''' Import Address:
     multichain-cli chain1 importaddress <addr> <scan>
If the <addr> is an owa.
It is imported in to the node, 'ismine' is 'false'.
<scan> is a boolean to specify tracking the transactions of the <addr>.
'''
## Created owa.
# addr = api.createkeypairs()[0]['address']
# print(addr)
## Show addresses in the node.
# [print(a) for a in api.listaddresses()]

def import_(owa):
    try:
        r = api.importaddress(owa, 'True')   ## 'True' is a str.
        if r == None:           ## If success return None.
            print('Success')
        else:
            print(r['error']['message'])
    except:
        print('Import fails.')
# import_(addr)
# [print(a) for a in api.listaddresses()]  ## 'addr' is shown but 'ismine': False.
