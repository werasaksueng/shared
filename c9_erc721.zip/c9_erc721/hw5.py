1. Prepare image and metadata:
- Capture your face image, save as thumbnail size and name <your name>.png.
- Create <your name metadata>.json.
  Upload the two files to pinata and save the urls.

2. Assume that you have a Sepolia API_KEY, if not register one.

3. Start Metamask and connect to Sepolia.
- Create an account or import one, save address and private key.
- If your account do not have ETH, get some from Ethereum faucet.   

3. Start Remix,  remix.ethereum.org
- Connect to Metamask, your address should appear.
  Check accounts with Metamask, let the account be a0.
- Load MyNft_S.sol and compile.
- Deploy:
  INITIALOWNER: a0
     Check  name, symbol.
- safeMint:
  to:  a0
  tokenid: 1234
  url: https://gateway.pinata.cloud/ipfs/Qma6fUiVfUdSBfELowD2W1iHA9Shxa3v4rhXBftF6X7LcL 
Copy the contract account as a1. 0x0Ec7f126A795F971684927ccebC73cB3447B3dE2

4. Modify 5_view.py to view your nft.
      e.g. API_KEY, a1,  ca, the image and metadata urls.
   Run 5_view.py and capture the image. 
   Save your 5_view.py and image to file.
      hw5_<your_student_id>.docx
Send to:   werasakstw@gmail.com
