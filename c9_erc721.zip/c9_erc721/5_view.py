from PIL import Image	   ## pip install Pillow
import requests
from web3 import Web3
API_KEY = '86bf0e4aba984b6e9da45dc3df569558'
URL = 'https://sepolia.infura.io/v3/' + API_KEY
w3 = Web3(Web3.HTTPProvider(URL))

a1 = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
ca = '0xB72e2f2629eDA50887ef03505E40868509F6fE11'
# ca = '0xD0b320ab3700F3cef6DF219272CdcFEd3d03F763'
# print(w3.eth.get_balance(a1))
# print(w3.eth.get_balance(ca))

## Copy abi to contracts\MyNft_S.abi
def read_file(fname):
    with open(fname, 'r') as f:
        return f.read()

abi = read_file('contracts/MyNft_S.abi')
# print(abi)

cr = w3.eth.contract(address=ca, abi=abi)
# [ print(f.fn_name) for f in cr.all_functions()]

im_url = cr.functions.tokenURI(1234).call()
print(im_url)
# im_url = 'https://gateway.pinata.cloud/ipfs/Qma6fUiVfUdSBfELowD2W1iHA9Shxa3v4rhXBftF6X7LcL'

def get_img():
    img = requests.get(im_url).content

    ## Save to file
    with open("b.png", "wb") as file:
        file.write(img)
    print('Sucess')

    b = Image.open('b.png')
    b.show()
# get_img()

