from myutil import *
from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

## The Blockchain must be newly created.
## 'prepare' must be performed only once.
MAX_MYTOKEN = 1000
@app.route('/prepare')
def prepare():
   ## Create 'mystream' stream, error if already exists.
   r = api.create('stream', 'mystream', True)
   try:
      if r['error']:
         return 'The Blockchain has already been prepared'
   except:
      pass

   ## Generate admin address and password 
   addr = admin_addr()           ## defined in myutil.py
   pwd = gen_pwd()
   
   ## Create json that contain addr and encoded of address with pwd.
   ## publish to 'mystream' with key is 'root' and subscribe.
   js = {"json": {"addr" : addr, "pwd": md5(pwd)}}
   api.publish('mystream', 'root', js)
   api.subscribe('mystream')

   ## Issues 1000 of 'mytoken' to the admin.
   r = api.issue(addr, "mytoken", float(MAX_MYTOKEN), 1.0)
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      pass

   ## Return admin address and pwd.
   return "{'address': %s, 'pwd': %s}" % (addr, pwd)
## The admin addr and pwd should be securely saved.

@app.route('/listaddr')
def list_addr():
   s = ''
   for r in api.getaddresses():
      s += r + '<br/>'
   return s if s != '' else 'None'

@app.route('/liststream')
def list_streams():
    s = ''
    for r in api.liststreams():
        s += r['name'] + '<br/>'
    return s if s != '' else 'None'

@app.route('/listperm')
def list_perm():
   s = ''
   for r in api.listpermissions():
      s += (r['address'] + ' ' + r['type']) + '<br/>'
   return s if s != '' else 'None'

@app.route('/getaddr', methods=['POST'])
def get_addr_():
    return get_addr(request.form['name'])

@app.route('/namepwd', methods=['POST'])
def name_pwd_():
    name = request.form['name']
    pwd = request.form['pwd']
    return str(is_valid_name_pwd(name, pwd))

################################################

## Register:
@app.route('/regacc', methods=['POST'])
def reg_acc():
   ## Verify user name
   uname = request.form['uname']
   uaddr = get_addr(uname)
   if uaddr != 'None':
      return 'The name had already been used.'

   ## Verify admin pwd
   if not is_valid_name_pwd('root', request.form['apwd']):
      return 'Invalid admin password'

   ## Create user address and password.
   ## Encode and publish to 'mystream' stream.
   addr = api.getnewaddress()
   pwd = gen_pwd()
   js = {"json": {"addr" : addr, "pwd": md5(pwd)}}
   api.publish('mystream', uname, js)

   ## Grant 'send,receive' permission to the address.
   api.grant(addr, 'send,receive')
   return "{'name': %s, 'pwd': %s}" % (uname, pwd)
## The addr and pwd should be saved for the newly created user.

#################################################

## Deposit:
@app.route('/deposit', methods=['POST'])
def deposit():
   uname = request.form['uname']
   upwd = request.form['upwd']
   if not is_valid_name_pwd(uname, upwd):
      return 'Invalid user address or password'

   amount = request.form['amount']
   if not is_valid_amount(amount):
      return 'Invalid amount'

   apwd = request.form['apwd']
   if not is_valid_name_pwd('root', apwd):
      return 'Invalid user address or password'

   aaddr = admin_addr()
   uaddr = get_addr(uname)
   r = api.sendassetfrom(aaddr, uaddr, "mytoken", float(amount))
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      pass
   return 'Success'

## Withdraw:
@app.route('/withdraw', methods=['POST'])
def withdraw():
   uname = request.form['uname']
   upwd = request.form['upwd']
   if not is_valid_name_pwd(uname, upwd):
      return 'Invalid user name or password'

   amount = request.form['amount']
   if not is_valid_amount(amount):
      return 'Invalid amount'

   apwd = request.form['apwd']
   if not is_valid_name_pwd('root', apwd):
      return 'Invalid admin password'

   aaddr = admin_addr()
   uaddr = get_addr(uname)
   r = api.sendassetfrom(uaddr, aaddr, "mytoken", float(amount))
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      pass
   return 'Success'

#################################################

@app.route('/userbal', methods=['POST'])
def user_bal():
   name = request.form['name']
   if not is_valid_name_pwd(name, request.form['pwd']):
      return 'Invalid address'
   b = api.getaddressbalances(get_addr(name))
   if b == []:
       return 'None'
   else:
      return b[0]['name'] + '  ' + str(b[0]['qty'])

@app.route('/coopbal', methods=['POST'])
def coop_bal():
   apwd = request.form['apwd']
   if not is_valid_name_pwd('root', apwd):
      return 'Invalid admin password'

   aaddr = admin_addr()
   b = api.getaddressbalances(aaddr)
   return str(MAX_MYTOKEN - b[0]['qty'])

#################################################

if __name__ == '__main__':
    app.run(port=8080, debug=True)


