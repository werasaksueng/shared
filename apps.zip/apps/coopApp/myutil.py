from Savoir import Savoir
import random

rpcuser = 'multichainrpc'
rpcpasswd = '52TH6uU5onYPrwGoZzMittjoEjg9iZS6rDi8i3aVQjNi'
rpchost = '127.0.0.1'
rpcport = '1234'
chainname = 'chain1'
api = Savoir(rpcuser, rpcpasswd, rpchost, rpcport, chainname)

import hashlib
def md5(msg):
    return hashlib.md5(msg.encode()).hexdigest()

## To handle password:
SYM = ['2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b',
'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n',
'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
def gen_pwd():
   p = ''
   for _ in range(random.randint(4, 6)):
      p += random.choice(SYM)
   return p

def is_valid_pwd(pwd):
   if pwd.__class__.__name__ == 'str':
      if 3 < len(pwd) < 7:
         for c in pwd:
            if c not in SYM:
               return False
         return True
   return False

## Get address of the name:
def get_addr(name):
    r = api.liststreamkeyitems('mystream', name)
    if r == []:
        return 'None'
    else:
        return str(r[0]['data']['json']['addr'])

## The admin address is first with all permissions.
def admin_addr():
   return api.getaddresses()[0]

def is_valid_addr(addr):
   return api.validateaddress(addr)['isvalid']

def is_valid_name_pwd(name, pwd):
   if not is_valid_pwd(pwd):
      return False
   r = api.liststreamkeyitems('mystream', name)
   if r == []:
      return False
   pwd_hash = r[0]['data']['json']['pwd']
   return md5(pwd) == pwd_hash

def is_valid_asset(asset):
   try:
      return api.getassetinfo(asset, False)['name'] == asset
   except:
      return False

def is_valid_amount(amount):
   if (not amount.isdecimal()) or float(amount) <= 0:
      return False
   return True

