from Savoir import Savoir
import random

rpcuser = 'multichainrpc'
rpcpasswd = '52TH6uU5onYPrwGoZzMittjoEjg9iZS6rDi8i3aVQjNi'
rpchost = '127.0.0.1'
rpcport = '1234'
chainname = 'chain1'
api = Savoir(rpcuser, rpcpasswd, rpchost, rpcport, chainname)

MAX_S = 20	## Max Number of Seat

import string
SYM = list(string.digits + string.ascii_letters)

def gen_pwd():
   p = ''
   for _ in range(random.randint(4, 6)):
      p += random.choice(SYM)
   return p

def is_valid_pwd(pwd):
   if pwd.__class__.__name__ == 'str':
      if 4 <= len(pwd) <= 8:
         for c in pwd:
            if c not in SYM:
               return False
         return True
   return False

def get_num_seat():
   return api.liststreamkeyitems('mystream', 'nos', False, 1)[0]['data']['text']

def get_seat_state(seat_num):
    dat = api.liststreamkeyitems('mystream', seat_num, False, 1)[0]['data']
    try:
        if dat.get('text') != None:
            return dat['text']
        if dat.get('json') != None:
            return dat['json']['state']
    except:
        return 'Error'

def encode(text, pwd):
   def encrypt(text, s): 
      result = "" 
      for i in range(len(text)): 
         char = text[i] 
         if (char.isdigit()):
            result += chr((ord(char) + s-48) % 10 + 48) 
         elif (char.isupper()): 
            result += chr((ord(char) + s-65) % 26 + 65) 
         else: 
            result += chr((ord(char) + s-97) % 26 + 97) 
      return result
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   for c in pwd:
      text = encrypt(text, ord(c) - 48)
   return text

def decode(text, pwd):
   def decrypt(text, s): 
      result = "" 
      for i in range(len(text)): 
         char = text[i] 
         if (char.isdigit()):
            result += chr((ord(char) - s-48) % 10 + 48) 
         elif (char.isupper()): 
            result += chr((ord(char) - s-65) % 26 + 65) 
         else: 
            result += chr((ord(char) - s-97) % 26 + 97) 
      return result
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   for c in reversed(pwd):
      text = decrypt(text, ord(c) - 48)
   return text 