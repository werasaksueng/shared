from myutil import *
from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/prepare', methods=['POST'])
def perpare():
   ## Verify number of seats
   try:
      nos = int(request.form['nos'])
      if 3 <= int(nos) <= MAX_S:
         pass
   except:
      return 'Invalid number of seat'

   ## Create 'mystream'
   r = api.create('stream', 'mystream', {'restrict': 'write'})
   try:
      if r['error']:
         return r['error']['message']
   except:
      api.subscribe('mystream')

   ## Initialized all seats to available state.
   try:
      for s in range(nos):
         api.publish('mystream', str(s), {"json":  {"state": "avai", "name": "none"}})
   except:
      return 'Error creating seat ... please reset the Blockchain'

   ## Save nos (number of seats).
   r = api.publish('mystream', 'nos', {"text": str(nos)})
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      pass
   return 'Success'

@app.route('/getnumseat')
def get_num_seat_():
   return api.liststreamkeyitems('mystream', 'nos', False, 1)[0]['data']['text']

@app.route('/getseatstate', methods=['POST'])
def get_seat_state_():
    seat_num = request.form['seat_num']
    
    return get_seat_state(seat_num)

@app.route('/listseats')
def list_seats():
   s = []
   for i in range(int(get_num_seat_())):
      s.append((i, get_seat_state(str(i))))
   return str(s)
#############################################################################

@app.route('/books', methods=['POST'])
def books():
   name = request.form['name']
   bsn = request.form['book_seat_num']
   if int(bsn) < 1 or int(bsn) > MAX_S:
      return 'Invalid seat number'

   s = get_seat_state(bsn)
   if s == 'booked' or s == 'seated':
      return 'The seat is not available'

   ## ['seat', <seat_num>] {'json': {'state': <state>, 'name': <name>}}
   r = api.publish('mystream', str(bsn), {"json":  {"state": "booked", "name": name}})
   try:
      if r['error']:
         return 'Error updating seat: ' + str(r['error']['message'])
   except:
      pass

   pwd = gen_pwd()
   enp = encode(name, pwd)
   ## "name": {"json": {"enp": enp, "seat": bsn}}
   r = api.publish('mystream', name, {"json": {"enp": enp, "seat": bsn}})
   try:
      if r['error']:
         return 'Error saving name: ' + str(r['error']['message'])
   except:
      pass

   return "{'name': %s, 'seat': %s, 'pwd': %s}" % (name, bsn, pwd)

@app.route('/verifybooks', methods=['POST'])
def verify_books():
   name = request.form['name']
   pwd = request.form['pwd']
   if not is_valid_pwd(pwd):
      return 'Invalid pwd'

   r = api.liststreamkeyitems('mystream', name, False, 1)
   if len(r) == 0:
      return 'The name is not in the booked list'
   namex = decode(r[0]['data']['json']['enp'], pwd)
   if namex != name:
      return 'The password is not belong to the name'
   seat = r[0]['data']['json']['seat']
   return str({'seat': seat})

@app.route('/getseatowner', methods=['POST'])
def get_seat_owner():
   nos = int(get_num_seat())
   seat_num = request.form['seat_num']
   if nos < 1 or MAX_S < nos:
      return 'Invalid seat number'

   r = api.liststreamkeyitems('mystream', seat_num, False, 1)[0]
   try:
      if r['data']['json']['state'] == '00':
         return 'None'
      return str(r['data']['json']['name'])
   except:
      return 'Error'

@app.route('/unbooks', methods=['POST'])
def unbooks():
   name = request.form['name']
   pwd = request.form['pwd']
   if not is_valid_pwd(pwd):
      return 'Invalid pwd'

   nos = int(get_num_seat())
   seat_num = request.form['seat_num']
   state = get_seat_state(seat_num)
   if state == 'avai':
      return 'The seat is not booked.'
   if state == 'seated':
      return 'The seat is already seated.'

   r = api.liststreamkeyitems('mystream', name, False, 1)
   if len(r) == 0:
      return 'The name is not in the booked list'
   namex = decode(r[0]['data']['json']['enp'], pwd)
   if namex != name:
      return 'The password is not belong to the name'
   seatx = r[0]['data']['json']['seat']
   if seat_num != seatx:
      return 'The seat is not belonged to the name.'

   ## Reset the seat state
   r = api.publish('mystream', seat_num, {'json': {'state': 'avai'}})
   try:
      if r['error']:
         return 'Error updating seat: ' + str(r['error']['message'])
   except:
      pass

   ## Nullify the name
   r = api.publish('mystream', name, {'json': {'enp': 'none', 'seat': 'none'}})
   try:
      if r['error']:
         return 'Error nullify name: ' + str(r['error']['message'])
   except:
      pass
   return 'Success: The seat has been reseted and the name is nullified.'

###############################################################

@app.route('/seats', methods=['POST'])
def seat():
   name = request.form['name']
   pwd = request.form['pwd']
   if not is_valid_pwd(pwd):
      return 'Invalid pwd'

   nos = int(get_num_seat())
   seat_num = request.form['seat_num']
   state = get_seat_state(seat_num)
   if state == 'avai':
      return 'The seat is not booked.'
   if state == 'seated':
      return 'The seat is already seated.'

   r = api.liststreamkeyitems('mystream', name, False, 1)
   if len(r) == 0:
      return 'The name is not in the booked list'
   namex = decode(r[0]['data']['json']['enp'], pwd)
   if namex != name:
      return 'The password is invalid'
   seatx = r[0]['data']['json']['seat']
   if seat_num != seatx:
      return 'The seat is not booked by the name.'

   ## Update seat state
   r = api.publish('mystream', seat_num, {'json': {'state': 'seated', 'name': name}})
   try:
      if r['error']:
         return 'Error updating seat: ' + str(r['error']['message'])
   except:
      pass
   return 'Success.'

if __name__ == '__main__':
    app.run(port=8080, debug=True)


