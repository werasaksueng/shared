from myutil import *
from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
## http://127.0.0.1:8080

## List addresses, exclude root address.
@app.route('/listaddr')
def list_addr():
   s = ''
   for r in api.getaddresses():
      s += r + '<br/>'
   return s if s != '' else 'None'

## List permissions, exclude root address.
@app.route('/listperm')
def list_perm():
   # root_addr = api.getaddresses()[0]
   s = ''
   for r in api.listpermissions():
      # if r['address'] != root_addr:
      s += (r['address'] + '   ' + r['type']) + '<br/>'
   return s

## Create a new address and grant 'send,receive' permissions.
@app.route('/newaddr')
def new_addr():
   addr = api.getnewaddress()
   api.grant(addr, 'send,receive')
   return addr

## Verify if an address is valid.
@app.route('/verifyaddr', methods=['POST'])
def verify_addr():
   if not is_valid_addr(request.form['addr']):
       return 'Invalid.'
   return 'Valid.'
#################################################

## Issue token to an address.
@app.route('/issue', methods=['POST'])
def issue():
    addr = request.form['addr']
    if not is_valid_addr(addr):
        return 'Invalid receiver address.'

    ## 'root' is not allowed to own token.
    if root_addr() == addr:
        return 'Root cannot own token.'

    ## The token must not already exist.
    token = request.form['token']
    if is_valid_token(token):
        return 'The token already exist.'

    ## The amount must be valid.
    amount = request.form['amount']
    if not is_valid_amount(amount):
        return 'Invalid amount.'

    ## The token subdivide is 1.0.
    r = api.issue(addr, token, float(amount), 1.0)
    try:
        if r['error']:
            return str(r['error']['message'])
    except:
        pass
    return 'Success.'

## Send from 'add1' to 'add2' an amount of tokens.
@app.route('/sendfrom', methods=['POST'])
def send_from():
    ## 'add1' and 'addr2' must be valid.
    add1 = request.form['add1']
    if not is_valid_addr(add1):
        return 'Invalid sender address.'
    add2 = request.form['add2']
    if not is_valid_addr(add2):
        return 'Invalid receiver address.'

    ## 'root' cannot receive tokens.
    if add2 == root_addr():
        return 'Root cannot receive tokens.'

    ## The token must valid.
    token = request.form['token']
    if not is_valid_token(token):
        return 'Invalid token.'

    ## The amount must valid.
    amount = request.form['amount']
    if not is_valid_amount(amount):
        return 'Invalid amount.'

    r = api.sendassetfrom(add1, add2, token, float(amount))
    try:
        if r['error']:
            return str(r['error']['message'])
    except:
        pass
    return 'Success.'

#################################################

## Check address balance.
@app.route('/addrbal', methods=['POST'])
def addr_bal():
    ## The address must be valid.
    addr = request.form['addr']
    if not is_valid_addr(addr):
        return 'Invalid address.'
    s = ''
    for b in api.getaddressbalances(addr):
        s += b['name'] + '  ' + str(b['qty']) + '<br/>'
    return s

if __name__ == '__main__':
    app.run(port=8080, debug=True)
