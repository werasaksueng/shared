1. Prepare:
- Register to Sepolia
  Get your API_KEY, create an account and save address and private key.

2. Prepare image and metadata:
- Capture your face image and save into <your name>.png.
  Create <your name metadata>.json.
  Upload the two files to pinata and save the urls.

2. Start Metamask and connect to Sepolia.
- Import your account, using your private key.
- Get some ETH from Ethereum faucet to your account.   

3. Start Remix,  remix.ethereum.org
- Connect to Metamask, your address should appear.
  Check accounts with Metamask, let the account be a0.
- Load MyNft_S.sol and compile.
- Deploy:
  INITIALOWNER: a0
     Check  name, symbol.
- safeMint:
  to:  a0
  tokenid: 1234
  url: https://gateway.pinata.cloud/ipfs/Qma6fUiVfUdSBfELowD2W1iHA9Shxa3v4rhXBftF6X7LcL 
Copy the contract account as a1.

4. Modify 5_view.py to view your nft.
      e.g. API_KEY, a1, the image and metadata urls.
   Run 5_view.py and capture the image. 
   Save your 5_view.py and image to file.
      hw3_<your_student_id>.docx
Send to:   werasakstw@gmail.com
Due date:  7 April 2025.

 

