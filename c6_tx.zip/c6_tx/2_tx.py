## Create private key and public key from a fixed seed.
import bitcoin as pbc		## pip install pybitcoin
import hashlib
prik = hashlib.sha256('Hello'.encode()).hexdigest()
pubk = pbc.privkey_to_pubkey(prik)

## Tx Authentication
## 'ecdsa' is an algorithm for Bitcoin key signing.
def sign_verify(tx):  ## Suppose a tx is just a string.
    ## Sign: 'tx' + private key --> signature
    sig = pbc.ecdsa_sign(tx.encode(), prik)

    ## Suppose the tx is modified.
    # tx = tx.replace('?', '.')
    
    ## Verify: 'tx' + signature + public key --> result 
    print(pbc.ecdsa_verify(tx.encode(), sig, pubk))
# sign_verify('Hello how do you do?')
#------------------------------------------------------

## Public provider URLs to get tx:
URL1 = 'https://blockstream.info/api/tx/'
URL2 = 'https://mempool.space/api/tx/'
URL3 = 'https://api.blockcypher.com/v1/btc/main/txs/'

## Get tx by tx_id:
import requests
from pprint import pprint
def get_tx(url):
    return requests.get(url).json()

## Coinbase tx_id of the Genesis Block:
cgtx_id = '4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b'
# gb_tx = get_tx(URL1 + cgtx_id)
# pprint(gb_tx)
## Extract locking/unlocking script.
# pprint(gb_tx['vin'][0]['scriptsig_asm'])
# pprint(gb_tx['vout'][0]['scriptpubkey_asm'])

''' Jan 12, 2009 The first-ever Bitcoin tx (10 BTC) was sent
  from Satoshi to Hal Finney.  '''
ftx_id = 'f4184fc596403b9d638783cf57adfe4c75c605f6356fbc91338530e9831e9e16'
def first_tx():
    tx = get_tx(URL1 + ftx_id)
    pprint(tx)
    print()
    print(tx['vout'][0]['scriptpubkey']) ## Hal public key
    print(tx['vout'][0]['value']) 	    ## 1000000000
    print(tx['vout'][1]['scriptpubkey']) ## The change
    print(tx['vout'][1]['value']) 	    ## 4000000000
# first_tx()

''' May 22, 2010 a programmer paid 10,000 BTC (about $41 at 
  that time) for two pizzas. 
The most expensive food ever eaten by human for today standard.
The crypto community celebrates May 22 as the 'Bitcoin Pizza Day'.  '''
pztx_id = 'a1075db55d416d3ca199f55b6084e2115b9345e16c5cf302fc80e9d5fbf5d48d'
def pz_tx():
    tx = get_tx(URL1 + pztx_id)
    # pprint(tx)
    print(tx['vout'][0]['value'])    ## 1000000000000
# pz_tx()
#------------------------------------------------------

## Sending tx: Using local Ganache port 8545.
URL = 'http://127.0.0.1:8545'   ## Start Ganache

from web3 import Web3
# w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.accounts)

## List pre-created account balances.
def balances():
    for a in w3.eth.accounts:
         print(a, w3.eth.get_balance(a))
# balances()
# john = w3.eth.accounts[0]
# jack = w3.eth.accounts[1]

## Send an auto signed tx:
## Ex. john sends 1 ETH to jack.
def send_tx(sender, btc, receiver):
    ## A tx is created as Python dict.
    tx = { 'from': sender, 'to': receiver, 'value': btc }

    ## Wallets provides automatic sign and send tx.
    return  w3.eth.send_transaction(tx).hex()   ## Return tx_id
# tx_id = send_tx(john, 1, jack)
# print(tx_id)
tx_id = '3e2cc5b560b1bea80216794990e01604b60cf4b946b2c94cd62ec7afe658cce2'

## Check the tx:
from pprint import pprint
# pprint(dict(w3.eth.get_transaction(tx_id)))
## Check: 'from' is sender, 'to' is receiver, 'value' is amount.

## Check: Ganache Logs and Transactions.
# balances()
#----------------------------------------------------

''' Raw tx: (Using Ganache on local Blockchain)
To create a raw tx, we need the following info:
  'chainId' for prevent sending tx acorss chains.
  'nonce' is used for prevent sending a tx more than once,
       mostly it is the number of tx sent by the address.
  'gasPrice' is the price offered by the sender, mostly
      obtained from the last block, but may not be enough in bussy hours.
  'gas' is the max gas allowed to execute this tx, the minimum is 0x21000.
'''
def get_info(acc):
    cid = w3.eth.chain_id
    nonce = w3.eth.get_transaction_count(john)
    block = w3.eth.get_block("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, currGas
# print(get_info(john))

## Ex. Send raw tx from 'john' to 'jack'.
def send_raw_tx(sender_prik, sender, eth:str, receiver):
    cid, nonce, currGas = get_info(sender);
    tx = {
        'to': receiver,
        'value': w3.to_wei(eth, "ether"),     ## from eth to wei
        'nonce': nonce,
        'chainId': cid,   # EIP-155 requires chainId.
        'gas': "0x21000",    # minimum gas
        'gasPrice': currGas, # Sometime currGas is not enough.
    }
    # print(tx)

    ## Sign the tx with sender private key.
    signed_tx = w3.eth.account.sign_transaction(tx, sender_prik) 

    ## Send the tx.
    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
    return tx_hash.hex()
## Get: john private in Ganache.
john_prik = '36957df2835d80db90f5816416acb0cb1b6fe859eef4efb2675466715760c0be'

# tx_id = send_raw_tx(john_prik, john, '1', jack)
# pprint(dict(w3.eth.get_transaction(tx_id)))

## Check Etherscan: wait while waiting the tx to be comfirmed.
## Check Balances:
# balances()

## Most nodes strictly check the offered fees.
## Using raw tx, the success tx rate is depended on the network.
