''' Homework:
Sepolia Blockchain network is accessible through 'infura'.
Infura does not provide wallet service, so we must use raw tx sending.
This is my API_KEY, use your own. '''
API_KEY = '86bf0e4aba984b6e9da45dc3df569558'
URL = 'https://sepolia.infura.io/v3/' + API_KEY

from web3 import Web3
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)
# print(w3.eth.accounts)

## Use web3.py to create account locally.
def create_acc():
    acc = Web3().eth.account.create()
    print('prik:', acc.key.hex())
    print('addr:', acc.address)
create_acc()
## Create 'john' and 'jack' accounts.
john_prik = 'bbf09113b5c36bafd2fe3d6e1e85e6fb63816c9dc7d54ab4872f615da7748fe1'
john_addr = '0x4FebF3aF10e4815e32F9f1427cFDdF9301a196B0'

jack_prik = 'b2594d91a2c32753b17507a62d59d07d8cc5fabb6cd0dcafa3aa8d28305ea6cd'
jack_addr = '0x47293BBb39c2e79A9ad50a24AC4008CE57f2e9eF'

## Use 'Sepolia faucet' to send tETH to john address.
## https://cloud.google.com/application/web3/faucet/ethereum/sepolia
## Check balance:
# print(w3.eth.get_balance(john_addr))

''' Hw3: 
Use web3.py to send some ETH from 'john' to 'jack'.
  Show the source code and results of:
	get_info(john_addr)
        send_raw_tx(john_prik, john_addr, '0.001', jack_addr)

Note: This homework can be done using just Metamask.
But Metamask supports auto-signed tx and harder to use raw tx.
'''
