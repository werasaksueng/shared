''' 'Truffle 'is an Ethereum development framework.
It was very popular, but it was built around JavaScript.
Brownie is a Python-based framework similar to Truffle. 

'trufflesuite.com' also introduced 'Ganache' a Python-based
local Ethereum blockchain for development and testing, so we
do not need the local Geth or online providers like infura.

## Download and Install:
	https://trufflesuite.com/ganache/
    		Ganache-x.y.z-win-x64.appx

## Start Ganache(GUI).
     	Quickstart Ethereum
   10 addresses with 100 Eth balance are automatic generated.	
	Change port 7545 -> 8545 (Setting -> Server)
-----------------------------------

## Using Geth console to connect to Ganache.
## attach_geth.bat 
       geth attach http://127.0.0.1:8545
web3.version
eth.accounts     ## Try: Check with Ganache.
addr = "0x50f118fa92fE19501F1d0F78471dCAcfc2a2c18f"
eth.getBalance(addr)
exit
'''
#-------------------------------------------------------   

## Ganache supports both json_rpc and web3.py.
from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.client_version)

## List all addresses.
def list_accounts():
    for a in w3.eth.accounts:
         print(a, w3.eth.get_balance(a))
# list_accounts()

## Save john and jack addresses.
john_addr = w3.eth.accounts[0]
jack_addr = w3.eth.accounts[1]

## By default, Ganache creates new accounts and resets balances when started.
## To avoid resetting, try saving workspace and reload .

#----------------------------------------------------------

## Using web3.py to send tx with Ganache.
from web3 import Web3
ga_URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(ga_URL))

''' Sending Auto-signed TX:
All txs must be signed with the sender private keys.
Ganache Wallets maintains private keys of all its iwas,
 so it can automatic create and sign tx.  '''
def send_tx(sender, btc, receiver):
    ## A tx can be created as a Python dict.
    tx = { 'from': sender, 'to': receiver, 'value': btc }
    return  w3.eth.send_transaction(tx).hex()    ## tx_id

## john sends 1 ETH to jack.
# tx_id = send_tx(john_addr, 1, jack_addr) 

''' Ganache provides instant tx committing.
Try: Look up the Ganache Logs or Transactions.
If Ganache doesn't update account balances immediately.
Try: saving workspace and restart Ganache then reload.  '''
# list_accounts()
## Note: An amount of fee for sending tx is deducted form john balance.

#-----------------------------------------------------

## Sending Raw TX to infura:
## Infura is a gateway, not provides wallet services.

if_URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3i = Web3(Web3.HTTPProvider(if_URL))

## Using john address/private key and jack address from 3_provider.py.
john_addr = '0x315ABeBe78c6Fadbc3C410D44D1c8ac0811245E0'
john_prik = '375198db5d3db7272747a93311cee8db16096ff8414b015487bb5313751f2495'
jack_addr = '0x4eAdAa00eA1e95A75635f1AB96e26aEbf78bc92a'

## Check addresses balance:
def get_balance(addr):
   wei = w3i.eth.get_balance(addr)
   return w3i.from_wei(wei, 'ether')
# print(get_balance(john_addr))
# print(get_balance(jack_addr))

''' For raw tx, the sender must create and sign the tx.
A raw tx needs the following extra information:
 - 'chainId' for prevent sending tx acorss chains.
 - 'nonce' is used for prevent sending a tx more than once,
      mostly it is the number of tx sent by the address.
 - 'gasPrice' is the price offered by the sender, mostly
   obtained from the last block, but may not be enough in bussy hours.
 - 'gas' is the max gas allowed to execute this tx, the minimum is 0x21000.
The 'nonce' and 'gasPrice' are vary during operations, 
 so they should be obtained just before creating the tx.
'''
def get_info(api, sender_addr):
    cid = api.eth.chain_id
    nonce = api.eth.get_transaction_count(sender_addr)
    block = api.eth.get_block("latest")
    gasPrice = '0x' + str(block.gasLimit)[:16]
    return cid, nonce, gasPrice
# print(get_info(w3i, john_addr))  ## (11155111, 0, '0x36000000')

## Create, sign and send raw tx.
def send_raw_tx(sender_prik, wei, receiver_addr):
    cid, nonce, gasPrice = get_info(w3i, john_addr);
    tx = {
        'to': receiver_addr,       ## receiver address
        'value': wei,
        'nonce': nonce,
        'chainId': cid,       ## EIP-155 requires chainId.
        'gasPrice': gasPrice, ## offered gasPrice.
        'gas': "0x30000",     ## minimum gas
    }
    # print(tx)

    ## Sign the tx with sender private key, resulting a raw tx.
    signed_tx = w3i.eth.account.sign_transaction(tx, sender_prik) 

    ## Send the raw tx.
    tx_hash = w3i.eth.send_raw_transaction(signed_tx.raw_transaction)
    return tx_hash.hex()

## John send 0.001 eth to jack.
wei = w3i.to_wei(0.001, 'ether')  ## Converts eth to wei.
# tx_id = raw_tx(john_prik, wei, jack_addr)
# print(tx_id)
tx_id = '4e7bccf4e62ade70cbbd36d9767c3cde5ad4ad38bf133db8b2b8c61ef99c6b31'

## Check the tx.
from pprint import pprint
# pprint(dict(w3i.eth.get_transaction(tx_id)))
## Wait until the 'transactionIndex' is not None.
## Then check the balances.
# print(get_balance(john_addr))
# print(get_balance(jack_addr))

## The success rate and confirm time depended on the Blockchain.
## Check https://sepolia.etherscan.io and search for the tx_id.

#########################################################

''' Homework 1: Ganache also support sending raw tx.
Create john and jack accounts in Ganache. e.g. Number 1 and 2.
Look up john private key in Ganache.
Write a python program (allow copying from the above with some modification),
 to send raw tx  for 'john send 2 ETH to jack'.
Include all your source codes in a single file, named:
         hw1_<your_student_id>.zip
Your source code should be executable ready, which contains:
- The line to defind john/jack addresses and john private key.
- get_balance()
- get_info()
- send_raw_tx()
- The lines to send the raw tx and show the balances.
Since Ganache alraedy works with eth you do not need the conversion
 between wei and eth.

Send to:   werasakstw@gmail.com
Due date:  17 Feb 2025.
'''