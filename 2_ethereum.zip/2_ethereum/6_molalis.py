# https://moralis.io
# https://admin.moralis.io/register
# Moralis dashboard: https://admin.moralis.io/
# Register: username, pwd

API_KEY = 'ootMViq0HW9AUAnCdSnkKTl2PvXZsINteNm8DTWNctZOZPWqWaVNS1hEGWpOIlIj'

# https://moralisweb3.github.io/Moralis-Python-SDK/

## pip install moralis
from moralis import utils
# print(utils.web3_api_version(api_key=API_KEY))

## Get Balance:  of an address via the EVM API
from moralis import evm_api
def get_balance():
    print(evm_api.balance.get_native_balance(
        api_key=API_KEY,
        params={      # Copy from Metamask
            "address": "0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5",
            "chain": "sepolia",
        },
    ))
# get_balance()





