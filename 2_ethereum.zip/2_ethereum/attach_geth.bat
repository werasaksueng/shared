set PATH=%PATH%;C:\mycrypto\etc\Geth
geth attach http://127.0.0.1:8545