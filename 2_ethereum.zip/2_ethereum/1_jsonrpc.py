import requests

URL = 'http://127.0.0.1:8545'
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def json_rpc(method):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   # print(DATA)
   return requests.post(URL, data=DATA, headers=HEADERS).text

print(json_rpc('web3_clientVersion'))
# print(json_rpc('eth_accounts'))

