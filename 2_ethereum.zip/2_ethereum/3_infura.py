# Register: https://infura.io
#       Api Key:    86bf0e4aba984b6e9da45dc3df569558
# https://mainnet.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558
# https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558
# Infura does not support rinkeby anymore.

from web3 import Web3
URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
# URL = "https://eth.getblock.io/a3ac0ff5-7c75-417e-ac5d-143b256568d2/sepolia/"

w3 = Web3(Web3.HTTPProvider(URL))

# Infura we3 methods still Camel Case.
print(w3.clientVersion)
print(w3.eth.chainId)
print(w3.eth.accounts)      # []            # Infura is not a wallet.
print(w3.eth.mining)        # False         # Infura does not perform mining.
print(w3.eth.gasPrice)                      # wei.
print(w3.eth.blockNumber)                   # Get most recent block number
b = w3.eth.get_block('latest')
print(w3.toHex(b.hash))

## Copy Account1 address from Metamask.
a = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
print(w3.eth.get_balance(a))
