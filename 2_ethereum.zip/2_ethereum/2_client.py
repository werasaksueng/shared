## A function for sending json rpc command(with no parameters).
import requests
def json_rpc(url, method='web3_clientVersion'):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   HEADERS = {'Content-type': 'application/json'}
   return requests.post(url, data=DATA,  headers=HEADERS).json()

## Sending Json-rpc to Geth.
## start_geth.bat
ge_URL = 'http://127.0.0.1:8545'
from pprint import pprint
# pprint(json_rpc(ge_URL))  

''' Try: these methods.
    admin_nodeInfo  Node information
    net_version  Network ID (e.g., 1 for mainnet, 5 for goerli). 
    net_peerCount  Number of peers currently connected.
    net_listening  If listening for network connections.
    eth_syncing    Items being synced.
    eth_blockNumber  Number of the most recent block.
    eth_gasPrice  Current price per gas in wei.
    eth_mining   If the node is actively mining.
'''
## It takes too long to download the entire blockchain.
## There are public gateways that offer free connection to Ethereum nodes.

#--------------------------------------------------------

''' Sepolia provides https://rpc.sepolia.org for rcp to
  the Sepolia testnet Ethereum blockchain.
It accepts json-rpc and supports libraries such as:
  ethers.py, web3.py and also .js.

The end point https://rpc.sepolia.org is seem to malfunctions.
Check if the endpoint is up and running.
	curl -i https://rpc.sepolia.org
Try: an alternative.
	curl -i https://rpc2.sepolia.org
'''
## Sending Json-rpc to Sepolia.
## The url to Sepolia testnet through sepolia.org.
sp_URL = 'https://rpc2.sepolia.org'
# pprint(json_rpc(sp_URL))    ## Try: method='eth_blockNumber'
#-----------------------------------------------------------

## Using Jsn-rpc to infura.io.
## Register: https://infura.io
## API_KEY: 86bf0e4aba984b6e9da45dc3df569558

## The url to Sepolia testnet through infura.to.
if_URL = 'https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558'
# pprint(json_rpc(if_URL)) 

## Sending Jsn-rpc to tatum.io.
## Register: https://co.tatum.io/signup
## These are my apis, an old and a new, that seem to work both.
API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
# API_KEY = 't-64f72e240c34f3d88dec9efe-f911f20459a04eb6a13695d8'

## The url to Sepolia testnet through tatum.to.
tt_URL = 'https://api.tatum.io/v3/blockchain/node/ethereum-sepolia/' + API_KEY
# pprint(json_rpc(tt_URL)) 
 
#############################################################

''' 'web3.py' is a python lib that supports apis to ethereum nodes.
That allows clients to call functions which generate json-rpc and
  send to ethereum nodes.
pip install --upgrade setuptools
pip install web3

Web3.py documents:
   https://web3py.readthedocs.io/en/stable/
   https://blog.logrocket.com/web3-py-tutorial-guide-ethereum-blockchain-development-with-python/
'''
## Using web3.py with Geth.
## start_geth.bat
from web3 import Web3
def geth_web3():
   w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))
   print(w3.client_version)
   print(w3.eth.chain_id)        ## 11155111 (sepolia chain id). 
   print(w3.eth.block_number)    ## Get most recent block number.
   print(w3.eth.get_block(0))    ## Get block by number Try: 'latest'.
   print(w3.eth.gas_price)       ## in wei.
# geth_web3()

#######################################################################

## Using web3.py with infura.io.
w3 = Web3(Web3.HTTPProvider(if_URL))
# print(w3.client_version)
# print(w3.eth.chain_id)        ## 11155111

## Using web3.py with tatum.io.
w3 = Web3(Web3.HTTPProvider(tt_URL))
# print(w3.client_version)
