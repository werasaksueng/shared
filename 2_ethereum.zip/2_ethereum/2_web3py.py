# Microsoft Visual C++ 14.0 or greater is requuired.
# https://learn.microsoft.com/en-us/visualstudio/install/use-command-line-parameters-to-install-visual-studio?view=vs-2019
        # vs_buildtools.exe

# pip install --upgrade setuptools
# pip install web3

# Try: Geth, Openethereum, Ganache and Anvil.
from web3 import Web3
URL = 'http://127.0.0.1:8545'

w3 = Web3(Web3.HTTPProvider(URL))
# print(w3.isConnected())

def get_info():
    print(w3.clientVersion)
    print(w3.eth.chain_id)
    print(w3.eth.gas_price)
    print(w3.eth.block_number)
# get_info()

def get_balances():
    for a in w3.eth.accounts:
        print(a, w3.eth.get_balance(a))
# get_balances()

###############################################################

# https://web3py.readthedocs.io/en/stable/
# https://blog.logrocket.com/web3-py-tutorial-guide-ethereum-blockchain-development-with-python/

def get_block():
# Get block by number
    b = w3.eth.get_block(0)
    print(b)

# Get the last block
    b = w3.eth.get_block('latest')
    h = b['hash'].hex()
    # print(h)

# Get block by hash
    b = w3.eth.get_block(h) 
    # print(b) 
# get_block()

# The first block hash
h1 = w3.eth.get_block(0)['hash'].hex()
# print(h1)

def block_tx_count():
# Get block number tx count
    print(w3.eth.get_block_transaction_count(0))

# Get last block tx count
    print(w3.eth.get_block_transaction_count('latest'))

# Get block by hash tx count
    print(w3.eth.get_block_transaction_count(h1))
# block_tx_count()
