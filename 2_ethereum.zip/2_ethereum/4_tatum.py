API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
CHAIN = 'ethereum-sepolia'
HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }

import requests, json
def print_json(res):
   print(json.dumps(res.json(), indent=4, sort_keys=True))

def clientVersion():
## API_KEY may be in path params.
   # URL = 'https://api.tatum.io/v3/blockchain/node/%s/%s?type=testnet' % (CHAIN, API_KEY)
   # HEADERS = {'Content-type': 'application/json' }

## API_KEY may be in headers.
   URL = 'https://api.tatum.io/v3/blockchain/node/%s?type=testnet' % CHAIN

   DATA = '{"jsonrpc":"2.0", "method": "web3_clientVersion","params": [], "id": 1}'
   print_json(requests.post(URL, data=DATA, headers=HEADERS))
# clientVersion()

## Get Balance:  From Metamask.
account1 = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
me = '0x5E98B03695d98eD2A6563cCE88693b494aA2df64'
def get_balance(addr):
   URL = "https://api.tatum.io/v3/ethereum/account/balance/" + addr
   print_json(requests.get(URL, headers=HEADERS))  ## Using GET (no DATA)
# get_balance(address)
# get_balance(me)
# get_balance(account1)

##############################################################

def get_block():
## Get Current (latest) block hash.
   URL = "https://api.tatum.io/v3/ethereum/block/current"

## Get latest block
   # URL = 'https://api.tatum.io/v3/data/blocks/latest?chain='+ CHAIN

## Get block by hash
   hash = '0xea3a9bb493182b500ba3e23cac80a8b3004cccce6136e904f5d8d25307e3cfa6'
   # URL = "https://api.tatum.io/v3/ethereum/block/" + hash

## Get block by block id.
   # URL = 'https://api.tatum.io/v3/data/blocks?chain='+ CHAIN + '&blockIds=0'

## Get block by range.
   # URL = 'https://api.tatum.io/v3/data/blocks?chain='+ CHAIN + '&blockFrom=1&blockTo=3' 

   print_json(requests.get(URL, headers=HEADERS))
# get_block()

def get_tx():
## Get tx in latest block.
   # URL = 'https://api.tatum.io/v3/data/transactions?chain='+ CHAIN

## Get tx by hash
   hash = '0x2ede065a6fcde60717608aa3b0e9f9bc63100b6492f4c8793eb8b34c90704f5b'
   # URL = 'https://api.tatum.io/v3/data/transactions/hash?chain='+ CHAIN +'&hash=' + hash

## Get tx by addresses
   addresses = '0xa6f85eE31499b8CB45EE77049AC201d5dccbf8D5'
   URL = 'https://api.tatum.io/v3/data/transactions?chain='+ CHAIN +'&addresses=' + addresses

   print_json(requests.get(URL, headers=HEADERS))
# get_tx()
