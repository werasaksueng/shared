 # https://getblock.io 

from web3 import Web3
URL = "https://eth.getblock.io/a3ac0ff5-7c75-417e-ac5d-143b256568d2/sepolia/"
w3 = Web3(Web3.HTTPProvider(URL))
print(w3.clientVersion)
print(w3.eth.chainId)
print(w3.eth.accounts)