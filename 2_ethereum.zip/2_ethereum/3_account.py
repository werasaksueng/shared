## Create web3 api to https://rpc2.sepolia.org
from web3 import Web3
from pprint import pprint
w3 = Web3(Web3.HTTPProvider("https://rpc2.sepolia.org"))
# print(w3.is_connected())

## To selecting a propovider, the most concerned criteria is:
# print(w3.eth.gas_price)       ## in wei
#---------------------------------------------------------

## Some Ethereum providers support wallet services. e.g. sepolia.org.
## Create an account.
## An account has a private key and an address is computed form the key.
def get_account(): 
   ac = w3.eth.account.create()
   print("Address:", ac.address)
   print("Private Key:", ac.key.hex())
# get_account()   
## John Address: 0x315ABeBe78c6Fadbc3C410D44D1c8ac0811245E0
## John Private Key: 375198db5d3db7272747a93311cee8db16096ff8414b015487bb5313751f2495
## Jack Address: 0x4eAdAa00eA1e95A75635f1AB96e26aEbf78bc92a
## Jack Private Key: 7c7e7285dde2f9982b11a809368c3d0bd01e2a3e52fd9805851a4410b6feca8d
john_addr = '0x315ABeBe78c6Fadbc3C410D44D1c8ac0811245E0'
jack_addr = '0x4eAdAa00eA1e95A75635f1AB96e26aEbf78bc92a'

''' Requesting tETH from Sepolia Testnet Faucet:
     https://cloud.google.com/application/web3/faucet/ethereum/sepolia

We can only get free 0.05 tETH at a time.
Send to john_addr:
Recipient:   0x315ABeBe78c6Fadbc3C410D44D1c8ac0811245E0
'''
## 'rpc2.sepolia.org' is seem to has problem accessing sepolia testnet Blockchain. 
# print(w3.eth.get_balance(john_addr))

## So we access the sepolia Blockchain through infura.
if_URL = "https://sepolia.infura.io/v3/86bf0e4aba984b6e9da45dc3df569558"
w3 = Web3(Web3.HTTPProvider(if_URL))
# print(w3.eth.get_balance(john_addr))
# print(w3.eth.get_balance(jack_addr))

## Just for checking.
john_bal = 50000000000000000   
## Convert wei to eth.                 ## 1 eth = 10**18 wei 
# print(w3.from_wei(john_bal, 'ether'))  ## 0.05
#-----------------------------------------------------

## Alternatively we can access to ethereum Blockchain through tatum.io using restful.
import requests
def tt_balance(addr):
   URL = "https://api.tatum.io/v3/ethereum/account/balance/" + addr
   # API_KEY = 'c5f29e5b-8ee1-4111-8717-6e797fa56673'
   API_KEY = 't-64f72e240c34f3d88dec9efe-f911f20459a04eb6a13695d8'
   HEADERS = {'Content-type': 'application/json', 'x-api-key': API_KEY }
   res =  requests.get(URL, headers=HEADERS).json()
   print(res['balance'])
# tt_balance(john_addr)   ## in eth

#------------------------------------------------------------

''' 'moralis.io; also support accessing to ethereum Blockchain.
https://moralis.io
Moralis dashboard: https://admin.moralis.io/
Register: https://admin.moralis.io/register
'''
API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub25jZSI6IjVjYmFmMGJiLTkxM2QtNGU4MS1hYmIyLTdjZTNmOWE1ZjNhMSIsIm9yZ0lkIjoiMTE2MjYyIiwidXNlcklkIjoiMTE1OTA4IiwidHlwZUlkIjoiNTIyODQwM2EtNzBkYy00ZTkwLTlkOGItY2Q1OGVmYmU0OTc5IiwidHlwZSI6IlBST0pFQ1QiLCJpYXQiOjE2ODQzMDU0NzgsImV4cCI6NDg0MDA2NTQ3OH0.-EHM2YWgKswhzhPaJiQmE-0DuxWYQP3mW5JaxdFTo_Y'

## Using 'moralis.io' with python.
## https://moralisweb3.github.io/Moralis-Python-SDK/
## pip install moralis
from moralis import utils

## Version Check:
# print(utils.web3_api_version(api_key=API_KEY))

## Moralis offers service via the EVM API.
from moralis import evm_api
def mr_balance(addr):
    print(evm_api.balance.get_native_balance(
        api_key=API_KEY,
        params={ "address": addr, "chain": "sepolia"},
    ))
# mr_balance(john_addr)  		## wei





