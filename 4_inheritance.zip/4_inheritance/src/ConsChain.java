// ConsChain,java
class A { A() { System.out.print("A"); } }
class B extends A { B() { System.out.print("B"); } }
class C extends A { C() { super(); System.out.print("C"); } }
class ConsChain {
	public static void main(String args[]) {
		new B();
		// new C();
	}
}