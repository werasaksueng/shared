class A { 
	int x = 1;
        String f() { return "A"; }
}
class B extends A {
	int x = 2;
	String f() { return "B"; }
	void print() {
		System.out.println(super.x + "," + super.f());
	}
}
class C extends B {
	int x = 3;
	void print() {
		System.out.println(super.x + "," + this.x);
	}
}
class SuperRef {
	public static void main(String args[]) {
		// new B().print();
		new C().print();
	}
}
