// DesConChain.java
class A {
   int x;
   A() { this.x  =0; }
   A(int x) { this.x = x; }
}
class B extends A {
   int y;
   B() { this.x = 0; 
      this.y = 0;
   }
   B(int x, int y) { 
      super.x = x;
      this.y = y;
   }
}
class N {
   int x;
   N() { this(0); }
   N(int x) { this.x = x; }
}
class M extends N {
   int y;
   M() { this(0, 0); }
   M(int x, int y) { 
      super(x);
      this.y = y;
   }
}
class DesConChain {
    public static void main(String args[]) {
	B b = new B(1,2);
	System.out.println(b.x + ", " + b.y);
	M m = new M(1,2);
	System.out.println(m.x + ", " + m.y);
    }
}
