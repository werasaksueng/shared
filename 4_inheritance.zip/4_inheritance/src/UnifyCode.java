class Shape {
	public String getName() { return "unknow"; }
	public double getArea() { return 0.0; }
}
class Rectangle extends Shape {
	private double width, height;
	Rectangle(double width, double height) {
		this.width = width; this.height = height;
	}
	public String getName() { return "rectangle"; }
	public double getArea() { return width * height; }
}
class Triangle extends Shape {
	private double base, height;
	Triangle(double base, double height) {
		this.base = base; this.height = height;
	}
	public String getName() { return "triangle"; }
	public double getArea() { return 0.5 * base * height; }
}
class UnifyCode {
	static void test(Shape s) {
		System.out.println(s.getName() + ": " + s.getArea());
	}
	public static void main(String[] args) {
		test(new Rectangle(2,3));
		test(new Triangle(2,3));
	}
}