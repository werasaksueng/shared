// HashObj.java
class HashObj {
	public static void main(String args[]) {
		Object x = new Object();
		Object y = new Object();
		System.out.println(x.hashCode()); // 366712642
		System.out.println(y.hashCode()); // 1829164700		
	}
}
