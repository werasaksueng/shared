// Override.java
class A {
    String f() { return "Hello"; }
}
class B extends A {
    String f() { return "Hi"; } // override
    int f(int x) { return x; }  // overload
}
class Override {
    public static void main(String args[]) {
	B b = new B();
	System.out.println(b.f());   // Hi
        System.out.println(b.f(1));  // 1
    }
}