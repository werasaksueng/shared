// virDiamond.cpp
#include <iostream>

class A {
	protected:int x;
	public: A() { x = 1; }
};
class B : virtual public A {
	public: B() { x = 2; }
};
class C : virtual public A {
	public: C() { x = 3; }
};
class D : public B, public C {
// class D : public C, public B {
	public: void f() { 
		cout << x << '\n';
	}
};
main() {
	D d;
	d.f();
}
