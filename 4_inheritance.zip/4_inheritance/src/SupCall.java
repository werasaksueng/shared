class A {
    A(int x) { System.out.println(x); }
    A(String s) { System.out.println(s); }
}
class B extends A {
    B(int x) { super(x); }
    B(String s) { super(s); }
}
class SupCall {
    public static void main(String args[]) {
        new B(1);        // 1
        new B("Hello");  // Hello
    }
}