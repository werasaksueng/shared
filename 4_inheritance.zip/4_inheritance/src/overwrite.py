def f():
    print('Hello')
f()			## Hello
def f():
    print('Hello!')
f()			## Hello
def f(x) :
    print('Hi')
# f()			## Error
f(1)			## Hi