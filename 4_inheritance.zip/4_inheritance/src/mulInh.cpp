// mulInh.cpp		Multiple Inheritance
#include <iostream>
class A {
	public: void f() { cout << "A\n"; }
};
class B {
	public: void f() { cout << "B\n"; }
};
class C : public A, public B {
	public: void g() { A::f(); B::f(); }
};
main() {
	C c;
	c.g();
	c.A::f();
	c.B::f();
	// c.f();
}
