// BadExt.java
class A {
    void f() { System.out.print("f"); }
    int g() { return 1; }
}
class B extends A {
    void g() { System.out.println("g"); }
}

class C {
    A a = new A();
    void f() { a.f(); }
    void g() { System.out.println("g"); }
}

class BadExt {
    public static void main(String args[]) {
	B b = new B(); b.f(); b.g();
	C c = new C(); c.f(); c.g();
    }
}