class EqObj {
    public static void main(String args[]) {
        Object x = new Object();
        Object y = new Object();
        System.out.println((x == y) + "," + x.equals(y));  // false
    }
}