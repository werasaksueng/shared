// OverLoad.java
class A {
    void f() { }
    void f(int x) { }
    // int f(int x) { return x; }    ## Error
    void f(char x) { }
    void f(char c, int x) { }
    void f(int x, char c) { }
}
class OverLoad {
	public static void main(String args[]) {
		A a = new A();
		a.f();
		a.f(1);
		a.f('a', 1.0);
	}
}