// super_new.py
class A:
    def f(self, name):
       print('Hello', name, end=' ')
class B(A):
    def f(self, name):
        super().f(name)
        print('How are you?')        
B().f('Jack')
