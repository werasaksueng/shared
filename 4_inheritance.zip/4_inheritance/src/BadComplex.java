// BadComplex.java
class Complex {
	private double real, imagine;
	Complex() { real = 0.0; imagine = 0.0; }
	Complex(double r, double i) { real = r; imagine = i; }
	Complex(Complex c) { real = c.real; imagine = c.imagine; }
}