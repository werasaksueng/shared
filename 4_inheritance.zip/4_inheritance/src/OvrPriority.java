// OvrPriority.java
class A {
	void f() { }
}
class B extends A {
	// private void f() { }
	public void f() { }
}