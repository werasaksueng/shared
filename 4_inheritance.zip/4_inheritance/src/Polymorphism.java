class A {
	int x = 1;
	String f() { return "A"; }
}
class B extends A {
	int x = 2;
	String f() { return "B"; }
}
class Polymorphism {
	static void t(A a) {
		System.out.println(a.x + ", " + a.f());
	}
	public static void main(String args[]) {
		t(new A());
		t(new B());

		A a[] = new A[] { new A(), new B() };
		for (A x : a)
			System.out.print(x.f() + ", ");
	}
}