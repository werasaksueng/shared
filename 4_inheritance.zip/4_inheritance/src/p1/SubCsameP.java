// SubCsameP.java
package p1;
class SubCsameP extends A {
	public void print() { System.out.println(pub + pro + def); }
}