// OtherCsameP.java
package p1;
class OtherCsameP {
	public void print() {
		A a = new A();
		System.out.println(a.pub + a.pro + a.def);
	}
}