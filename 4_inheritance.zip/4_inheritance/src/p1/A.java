// A.java
package p1;
public class A {
	public int pub = 1;
	protected int pro = 2;
	int def = 3;
	private int pri = 4;
	public void print() { System.out.println(pub+pro+def+pri);}
}