// Composition.java
class A {
	public void f() { System.out.println("Hello"); }
}
class B {
	private A a = new A();
	public void f() { a.f(); }	// forwarding
	public void g() { System.out.println("Hi"); }
}
class Composition {
	public static void main(String args[]) {
		B b = new B();
		b.f();    // Hello
		b.g();    // Hi
	}
}