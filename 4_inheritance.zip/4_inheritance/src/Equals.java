class Student {
	private int id;
	private String name;
	Student(int id, String name) {
		this.id = id; this.name = name;
	}
	public boolean equals(Object o) {
		if (o != null && o instanceof Student) {
			Student s = (Student) o;
			if (id == s.id)
				return true;
		}
		return false;
	}

}
class Equals {
	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		Student b = new Student(123, "John Rambo");
		System.out.println(a == b);
		System.out.println(a.equals(b));

		String x = new String("Hello");
		String y = new String("Hello");
		System.out.println(x.equals(y));
	}
}
