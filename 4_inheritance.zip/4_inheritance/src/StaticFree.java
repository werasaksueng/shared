// StaticFree.java
class A {
    static { System.out.println("A static block"); }
    { System.out.println("A free block"); }
    A() { System.out.println("A()"); }
}
class FreeBlock {
    public static void main(String args[]) {
        System.out.println("main()");
        new A(); new A();
    }
}