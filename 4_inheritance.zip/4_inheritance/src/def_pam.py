def f(x = 0, y = 1):
    print(x, y)
f()			## 0 1
f(1)			## 1 1
f(x=2)			## 2 1
f(y=3)			## 0 3
