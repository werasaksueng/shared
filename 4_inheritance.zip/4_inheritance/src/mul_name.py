class A:
    def f(self):
        print('A')
class B:
    def f(self):
         print('B')
class C(A, B):
    pass
C().f()     ## A
