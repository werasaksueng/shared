class A:
    a = 1			## class data
    def __init__(self, x):
        self.x = x		## object data
    @classmethod
    def f(cls):
        print("class method")
    def g(self):
        print("object method")
    @staticmethod
    def s(n):
        print("static method")
class B(A): 
    pass
print(B.a)		## 1
B.f()		## class method
B.s(1)			## Static method
b = B(2)
print(b.x)		## 2
b.g()		## object method 
