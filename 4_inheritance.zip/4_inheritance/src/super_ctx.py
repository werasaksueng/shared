class A:
    def __init__(self):
        self.x = 1
    def f(self):
        print(self.x)
class B(A):
    def __init__(self):
        self.x = 2
    def f(self):
        super().f()
        print(self.x)
B().f()		## 2
		## 2
