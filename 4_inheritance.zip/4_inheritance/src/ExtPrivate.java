// ExtPrivate.java
class A {
	public int w = 1;
	protected int x = 2;
	int y = 3;
	private int z = 4;
}
class B extends A { }
class ExtPrivate {
	public static void main(String args[]) {
		B b = new B();
		System.out.println(b.w + "," + b.x + "," + b.y);
		// System.out.println(b.z);
	}
}
