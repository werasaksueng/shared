class A {
	int x = 1;
}
class B extends A {
	int y = 2;
}
class RefAssign {
	public static void main(String args[]) {
		A a = new A();
		B b = new B();
		b.x = 3;
		a = b;
		// b = a;
		System.out.println(a.x);

	}
}
