class Driver {
	public void print() { }
}
class Word {
	private Driver d;
	Word(Driver d) { this.d = d; }
	public void setDriver(Driver d) { this.d = d; }
	public void print() { d.print(); }
}
class Epson extends Driver{
	public void print() { System.out.println("Epson"); }
}
class Hp extends Driver{
	public void print() { System.out.println("Hp"); }
}
class PlugIn {
	public static void main(String[] args) {
		Word w = new Word(new Epson());
		w.print();
		w.setDriver(new Hp());
		w.print();
	}
}
