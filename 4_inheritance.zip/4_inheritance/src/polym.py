class A:
    def f(self):
        print('A')
class B:
    def f(self):
        print('B')
def test(x): ## x can be objects of any class that has f().
    x.f()
test(A())			## A
test(B())			## B
