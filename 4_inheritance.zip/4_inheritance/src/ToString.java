class Student {
	private int id;
	private String name;
	Student(int id, String name) {
		this.id = id; this.name = name;
	}
	public String toString() { return id + "," + name; }
}
class ToString {
	public static void main(String args[]) {
		Student a = new Student(123, "John Rambo");
		System.out.println(a);
	}
}
