// diamond.cpp 	   Problem of Multiple Inheritance
#include <iostream>

class A {
	protected:int x;
	public: A() { x = 1; }
};
class B : public A {
	public: B() { x = 2; }
};
class C : public A {
	public: C() { x = 3; }
};
class D : public B, public C {
	public: 
	void f() { 
		// cout << x << endl;
		// cout << A::x << endl;
	}
};
main() {
	D d; 
	d.f();
}

