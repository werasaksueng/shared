// Override.java
class A {
    void f() { System.out.println("Hello"); }
}
class B extends A {
    void f() { System.out.println("Hi"); }
    void f(int x) { System.out.println(x); }
}
class Override {
    public static void main(String args[]) {
	B b = new B();
	b.f();
        b.f(1);
    }
}