// BadCons.java
class A {
	A() { f(); }
	void f() { System.out.print("A"); }
}
class B extends A {
	B() { f(); }
	void f() { System.out.print("B"); }
}
class BadCons {
	public static void main(String args[]) {
		new B();   // BB
	}
}

