## cla_ovr.py
class A:
    x = 1
    y = 2
    def f():
        return 'A.f'
    def g():
        return 'A.g'
class B(A):
    x = 3
    def f():
        return 'B.f'
print(A.x, A.f(), B.x, B.f()) ## 1 A.f 2 B.f
print(B.y, B.g())   ## 2 A.g