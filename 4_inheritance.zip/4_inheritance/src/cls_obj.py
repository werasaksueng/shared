class A: pass
class B(A): pass

b = B()
print(type(b))
print(A.__base__)
print(B.__base__)