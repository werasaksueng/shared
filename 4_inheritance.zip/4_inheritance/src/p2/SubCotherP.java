// SubCotherP.java
package p2;
class SubCotherP extends p1.A {
	public void print() { System.out.println(pub+pro); }
}