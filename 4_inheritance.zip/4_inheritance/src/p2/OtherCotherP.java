// OtherCotherP.java
package p2;
class OtherCotherP {
	public void print() {
		p1.A o = new p1.A();
		System.out.println(o.pub);
	}
}