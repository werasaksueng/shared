class A {
   A() {  }
} 
