class A {
	String f() { return "A"; }
}
class E extends A { 	// extending
	String f() {
		return super.f() + " E";
	}
}
class Extend {
	public static void main(String args[]) {
		System.out.print(new E().f());
	}
}
