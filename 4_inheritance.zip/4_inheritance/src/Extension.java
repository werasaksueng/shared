// Extension.java
class A {
	public void f() { System.out.println("Hello"); }
}
class B extends A {
	public void g() { System.out.println("Hi"); }
}
class Extension {
	public static void main(String args[]) {
		B b = new B();
		b.f();    // Hello
		b.g();    // Hi
	}
}