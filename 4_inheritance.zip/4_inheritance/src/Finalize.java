// Finalize.java
class A {
	A() { System.out.println("Hello"); }
	protected void finalize() throws Throwable {
		System.out.println("Bye");
	}
}  // finalize() is deprecated.
class Finalize {
	public static void main(String args[]) {
		new A();
		System.gc();
	}
}
