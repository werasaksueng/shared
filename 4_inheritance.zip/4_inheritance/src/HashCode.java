import java.util.*;
class Student {
	private int id;
	private String name;
	Student(int id, String name) { this.id = id; this.name = name; }
	public boolean equals(Object o) {
		if (o != null && o instanceof Student) {
	 		Student s = (Student) o;
	 		if (id == s.id)
	 			return true;
	 	}
	 	return false;
	}
	public int hashCode() { return id; }
}
class HashCode {
	public static void main(String args[]) {
		Map<Student, String> h = new HashMap<Student, String>();
		h.put(new Student(123, "John Rambo"), "BadGuy");
		System.out.println(h.get(new Student(123, "John Rambo")));
	}
}
