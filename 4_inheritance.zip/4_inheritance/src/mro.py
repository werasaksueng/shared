class A:
    def f(self):
        print('A')
class B(A):
    def f(self):
        print('B')
class C(A):
    def f(self):
        print('C')
class D(B, C):
    pass
print([x.__name__ for x in D.mro()])
	## ['D', 'B', 'C', 'A', 'object']
D().f()				## B
