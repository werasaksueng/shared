// Binding.java
class A {
	int x;
        A() { x = 0; }
	A(int x) { this.x = x; }
	char f() { return 'A'; }
}
class B extends A {
	int x;
	B(int x) { this.x = x; }
	char f() { return 'B'; }
}
class Binding {
	public static void main(String args[]) {
		A a = new A(1);
		System.out.println(a.x + "," + a.f());
		a = new B(2);
		System.out.println(a.x + "," + a.f());
	}
}