// ConsOvr.java
class A {
    String msg;
    A() { msg = "Hello"; } 
    A(String msg) { this.msg = msg; } 
    void print() { System.out.println(msg); }   
}
class ConsOvr {
    public static void main(String args[]) {
	new A().print();	// Hello
	new A("Hi").print();	// Hi
    }
}