// ShaPriority.java
class A {
     int x;
     public int y;
}    
class B extends A {
     protected int x;
     private int y;
}
