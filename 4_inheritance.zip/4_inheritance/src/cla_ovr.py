class A:
    x = 1
    def __init__(self, x):
        self.x = x
    def x(self):
        return 2
    def x():
        return 3

print(A.x)    ## <function A.x at ...>
print(A.x())  ## 3
a = A(4)
print(a.x)    ## 4
# print(a.x())    ## Error
