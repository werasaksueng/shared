class A:
    def f():
       print('Hello')
class B(A):
    @classmethod
    def f(cls):
        super().f()
B.f()