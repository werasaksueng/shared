// GoodComplex.java
class Complex {
	double real, imagine;
	Complex() { this(0, 0); }
	Complex(double r, double i) { real = r; imagine = i; }
	Complex(Complex c) { this(c.real, c.imagine); }
        void print(){
		System.out.println(real + " + " + imagine + "i");
	}
}
class GoodComplex {
	public static void main(String args[]) {
		new Complex(1.0, 2.0).print();
	}
}