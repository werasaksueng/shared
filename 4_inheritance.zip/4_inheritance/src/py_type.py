## py_type.py
class A: pass
class B(A): pass
a = A()
b = B()
print(type(a).__base__) ## <class 'object'> 
print(A.__base__)       ## <class 'object'> 
print(B.__base__)       ## <class '__main__.A'>
