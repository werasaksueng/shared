class A:
    def f(self):
        print("f")
class B:
    def g(self):
        print("g")
class C(A, B):
    pass

c = C()
c.f()			## f
c.g()		s	## g
print(isinstance(c, A), isinstance(c, B))
		## True True
