// TosObj.java
import java.util.Date;
class TosObj {
	public static void main(String args[]) {
		Object o = new Object();
		System.out.println(o);

		System.out.println(new String("Hello"));
		System.out.println(new Date("2000/01/01"));
	}
}
