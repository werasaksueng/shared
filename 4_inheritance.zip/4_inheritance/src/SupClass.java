class A { }
class B extends A { }
class SupClass {
	public static void main(String args[]) {
		B b = new B();
		Class bc = b.getClass();
		System.out.println(bc.getName());
		System.out.println(bc.getSuperclass().getName());

		A a = new A();
		System.out.println(a.getClass().getSuperclass().getName());
		System.out.println(Object.class.getSuperclass());

	}
}