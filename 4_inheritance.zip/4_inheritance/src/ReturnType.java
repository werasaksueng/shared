class A {
	int f() { return 1; }
}
class B extends A {
	// double f() { return 1.0; } // Error
}
class X {
	A f() { return new A(); }
}
class Y extends X {
	B f() { return new B(); }
}
