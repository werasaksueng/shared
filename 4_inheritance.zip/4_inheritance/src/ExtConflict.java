// ExtConflict.java
class A {
	double x = 1;
}
class B extends A {
	void f(int x) { }
	void g() { f(x); }
}