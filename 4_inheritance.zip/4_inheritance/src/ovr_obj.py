class A:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def f(self):
        return 'A().f'
    def g(self):
        return 'A().g'
class B(A):
    def __init__(self, x):
        self.x = x;
    def f(self):
        return 'B().f'
b = B(3)
print(b.x, b.f(), b.g())   ## 3 B().f A().g
# print(b.y)     ## Error
