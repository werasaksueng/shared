class A:
    def f(self, name):
       print('Hello', name, end=' ')
class B(A):
    def f(self, name):
        super(B, self).f(name)
        print('How are you?')        
B().f('John')		## Hello John How are you?
