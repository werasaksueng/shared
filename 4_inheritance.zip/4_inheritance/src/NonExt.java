// NonExt.java
class A { private A() { } }
// class B extends A { }  // Error
final class C { }
// class D extends C { }  // Error
