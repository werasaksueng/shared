// Inherit.java
class A {
    static int w = 1;
    int x = 2;
    static int fa() { return 3; }
    int ga() { return 4; }
}
class B extends A {
    static int y = 10;
    int z = 20;
    static int fb() { return 30; }
    int gb() { return 40; }
}
class Inherit {
    public static void main(String args[]) {
        B b = new B();
        System.out.print(
		b.w + "," + b.x + "," + 
		b.y + "," + b.z + "," +
		b.fa() + "," + b.ga() + "," +
		b.fb() + "," + b.gb());
	}
}
